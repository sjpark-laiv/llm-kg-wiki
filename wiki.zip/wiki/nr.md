---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
---

# NR (Nicotinamide Riboside, 니코틴아마이드 리보사이드)

**NR**(Nicotinamide Riboside)는 세포 대사와 에너지 생성에 관여하는 **NAD+**(Nicotinamide Adenine Dinucleotide) 수치를 높이는 데 쓰이는 **비타민 B3** 계열 성분으로 소개됩니다. 건강 수명·항노화(Anti-aging) 관심과 함께 주목받는 주제입니다.

동일 축의 다른 전구체인 **[NMN](nmn.md)**과 자주 비교되며, 저서 맥락은 [《노화의 종말》 §4](lifespan.md#longevity-supplements)를 참고할 수 있습니다.

---

<a id="precursor"></a>

## 1. NAD+의 전구체(Precursor)

- 체내 **NAD+**는 나이가 들며 자연 감소하고, 세포 기능 저하·노화와 연결된다는 서술이 흔합니다.
- **NR**은 섭취 후 **NAD+**로 전환되는 경로가 제품·리뷰 자료에서 강조됩니다.
- **에너지 대사**: **미토콘드리아** 기능을 활성화해 음식물을 에너지로 바꾸는 과정을 돕는다는 설명.
- **DNA 복구**: **PARPs** 등 손상 DNA 수리 효소 활동을 지원한다는 주장.
- **노화 억제**: **시르투인(Sirtuins)** 활성화와 연결해 소개되는 경우가 많습니다. (이론·맥락: [Lifespan §2](lifespan.md#sirtuins), [NMN 문서](nmn.md))

---

<a id="benefits"></a>

## 2. 주요 기대 효능

- **항노화·세포 재생**: 노화에 따른 세포 손상 지연·인지 기능 저하 예방에 도움이 될 수 있다는 **연구**가 자료에서 인용되곤 합니다.
- **근육 건강**: 미토콘드리아 기능 개선을 통한 **지구력·회복** 기대.
- **신진대사**: **인슐린 민감도**·**체중 관리**에 긍정적일 수 있다는 서술.

---

<a id="nmn-comparison"></a>

## 3. NMN과의 차이점

비슷한 효능으로 **[NMN](nmn.md)**과 자주 비교됩니다.

- **NR**: 분자 크기가 상대적으로 작아 **세포막 통과**에 유리하다는 설명, **상업적 연구** 이력이 길다는 점이 강조됩니다.
- **NMN**: NR보다 **한 단계 더 전환된** 형태로 설명되며, **흡수 경로**에 대한 연구가 활발하다는 점이 언급됩니다.

---

<a id="safety"></a>

## 4. 주의사항 및 부작용

- 다수에게 **안전**하다는 자료가 있으나, **과다 섭취** 시 **메스꺼움·피로·두통·설사** 등 가벼운 소화기 증상이 보고될 수 있다는 서술.
- **임신**·**기저질환**이 있으면 전문가와 상의 후 섭취가 권장됩니다.

---

## 요약

NR은 세포 에너지와 노화 지연 맥락에서 **NAD+를 효율적으로 올리는 ‘세포 연료’** 축으로 이해하는 설명이 흔합니다. **브랜드·복용량**은 제품·의료 지도에 따릅니다.

---

## Named entity 링크 (문서 간)

| 개체 | 유형 | 연결 |
|------|------|------|
| NR, Nicotinamide Riboside | Compound | 이 문서 |
| NAD+ | Compound | 이 문서 [§1](#precursor), [nmn.md](nmn.md) |
| NMN | Compound | [nmn.md](nmn.md), [§3](#nmn-comparison) |
| 시르투인, Sirtuins | Protein | [lifespan §2](lifespan.md#sirtuins), [nmn.md](nmn.md) |
| PARPs | Enzyme family | [§1](#precursor) |
| Coffee Fruit Extract | Supplement | [coffee-fruit-extract.md#nr-combo](coffee-fruit-extract.md#nr-combo) |

---

## 관련 문서 (Named entity)

- [NMN (니코틴아미드 모노뉴클레오타이드)](nmn.md): NAD+ 전구체·시르투인·복용 참고.
- [《노화의 종말》(Lifespan)](lifespan.md#longevity-supplements): NMN/NR·NAD+ 서술.
- [Coffee Fruit Extract](coffee-fruit-extract.md#nr-combo): NR·NAD+와의 복합 제형 맥락.

---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
---

# 한국 스태그플레이션 리스크 — 영상 근거 인과 (RCA·Impact)

**목적:** 영상 **「유가에 물가까지 '직격탄'...앞으로 한국에 벌어질 상황」**에서 제시한 **근거·인과**를 에이전트의 **root cause analysis(RCA)**·**impact analysis** 근거 데이터로 쓸 수 있게 구조화함. 본문은 영상 요지의 **재구성**이며, 수치·전망은 **영상 내 주장**으로 한정됨.

일반 **`Oil_Price` → `Price_Level`** 전달 틀은 [유가-물가 인과 구조](oil-price-inflation-causality.md)와 함께 읽는다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Geo_Risk_MiddleEast`** | 중동 지정학 리스크 | 미국–이란 갈등 심화, **호르무즈 해협** 봉쇄 가능성 등 **원유 공급망 차단** 시나리오. |
| **`Oil_Supply_Shock`** | 유가·공급 충격 | 위 리스크가 현실화될 때의 **유가 급등·공급 제약** 축. `Oil_Price`와 연동해 [유가-물가 인과](oil-price-inflation-causality.md#entities) 참고. |
| **`US_Fed_Stance_Tight`** | 미 연준 긴축 스탠스 | **FOMC** 이후 인플레 우려로 **금리 인하 기대 약화**, **연말 금리 인상 가능성** 언급 등 **고금리 유지·인상** 국면. |
| **`US_Tariff_Shock`** | 미국 관세·무역 정책 | 행정부 **관세**가 재화 가격에 미치는 **구조적 물가 상승 압력**. |
| **`Korea_Energy_Import_Dependence`** | 한국 에너지 수입 의존 | **중동 원유** 수입 비중이 높다는 전제 하, 유가 충격 시 **미국보다 물가 타격이 크고 즉각적**이라는 주장. |
| **`US_Consumption`** | 미국 소비 | 고금리로 **소비 위축** 시 한국 수출에 파급. |
| **`USD_Preference`** | 달러 선호 | 안전자산·금리차 맥락의 **달러 강세 선호**. |
| **`Korea_Export_Demand`** | 한국 수출 수요 | **반도체** 등 주력 품목 수요 감소 → 성장 동력 약화 주장. |
| **`FX_KRW_per_USD`** | 원/달러 환율 | **달러 선호**·금리차·불안 심리로 **환율 상승**(원화 약세 표현). |
| **`Korea_CPI_Path`** | 한국 물가 경로 | 영상: **한은 전망 2.2% 상회**, **3%대** 진입 가능성. |
| **`Korea_GDP_Growth`** | 한국 성장률 | 영상: **2% 초반** 체류 또는 **하락**과 결합한 **저성장–고물가** 국면. |
| **`Stagflation_Risk_Korea`** | 스태그플레이션 리스크 | **경기 둔화 속 물가 상승** 시나리오의 **국면 라벨**. |
| **`Korea_Rate_Dilemma`** | 통화정책 딜레마 | 물가를 위해 **금리 인상** 필요성 vs **가계·정부 부채** 부담으로 인상 어려움. |

**추론 태그:** `RCA` · `Impact` · `Evidence`(영상 타임스탬프).

---

<a id="causality-map"></a>

## 2. Causality Map — 대외 변수 → 한국 국면

| 경로 구분 | 인과 기제 | 세부 내용 | 분석 태그 |
|-----------|-----------|-----------|-----------|
| **공급·원가 (Cost-push)** | 에너지 수입 → 물가 직격 | `Korea_Energy_Import_Dependence` → 유가 상승 시 **미국보다 크고 빠른** 물가 타격 | `RCA`+`Impact` |
| **수요·실물 (Growth down)** | 미국 소비 → 한국 수출 | `US_Fed_Stance_Tight` → `US_Consumption` ↓ → `Korea_Export_Demand` ↓ | `Impact` |
| **금융·환율 (Currency risk)** | 금리차·위험선호 → 환율 → 수입물가 | `US_Fed_Stance_Tight` → **달러 선호** → `FX_KRW_per_USD` ↑ → 수입 물가 상승 **악순환** | `RCA`+`Impact` |
| **무역정책 (Structural price)** | 관세 → 재화 가격 | `US_Tariff_Shock` → **구조적** 물가 압력 | `RCA`+`Impact` |
| **국면 합성** | 복합 충격 → 스태그플레이션 | 외생 충격 맞물림 → `Korea_CPI_Path`↑ & `Korea_GDP_Growth` 둔화 → `Stagflation_Risk_Korea` | `Impact` |
| **정책 반응** | 물가 vs 부채 | `Korea_Rate_Dilemma` | `RCA`+`Impact` |

### 2.1 그래프 엣지 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Geo_Risk_MiddleEast` | `raises_probability` | `Oil_Supply_Shock` | `geopolitical_oil` |
| `Oil_Supply_Shock` | `amplifies` | `Oil_Price` | `supply_disruption` |
| `Korea_Energy_Import_Dependence` | `amplifies_vs_benchmark` | `Korea_CPI_Path` | `cost_push_korea` |
| `US_Fed_Stance_Tight` | `reduces` | `US_Consumption` | `demand_channel` |
| `US_Consumption` | `reduces` | `Korea_Export_Demand` | `export_channel` |
| `US_Fed_Stance_Tight` | `strengthens` | `USD_Preference` | `fx_channel` |
| `USD_Preference` | `increases` | `FX_KRW_per_USD` | `fx_channel` |
| `FX_KRW_per_USD` | `feeds_back` | `Korea_CPI_Path` | `import_inflation_loop` |
| `US_Tariff_Shock` | `pushes` | `Korea_CPI_Path` | `tariff_cost_push` |
| `Korea_CPI_Path` | `combines_with` | `Korea_GDP_Growth` | `stagflation_compose` |
| `Stagflation_Risk_Korea` | `manifests_as` | `Korea_CPI_Path` | `scenario` |
| `Stagflation_Risk_Korea` | `manifests_as` | `Korea_GDP_Growth` | `scenario` |
| `Korea_CPI_Path` | `creates` | `Korea_Rate_Dilemma` | `policy_bind` |

`Oil_Price`·`Price_Level` 일반 틀은 [oil-price-inflation-causality.md](oil-price-inflation-causality.md)의 엣지 표와 **합성**해 사용한다.

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`) — “왜 한국이 취약한가?”

- **에너지·공급망:** 중동 분쟁·**호르무즈** 봉쇄 가능성 등 → **원유 공급 차단** 리스크 → 유가 급등 시나리오 *(02:18)*.
- **대외 금리:** **3월 FOMC** 이후 인플레 우려로 **금리 인하 확률 감소**, **연말 인상 가능성** 언급 → 지속적 **긴축 금리** *(07:45)*.
- **무역·가격:** **관세 정책**이 재화 가격에 **구조적** 상방 압력 *(14:12)*.
- **한국 구조:** **중동 원유** 의존도·**수출** 중심 구조 → 외부 **유가**·**미 긴축**이 겹칠 때 **스태그플레이션**에 상대적으로 취약하다는 **영상 결론**.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`) — “무엇이 변하는가?”

### A. 물가·원가

- **에너지 수입 의존** → 유가 상승 시 **미국 대비** 물가 타격 **크고 즉각** *(22:23)*.
- **환율:** 금리차·**달러 선호** → **원/달러 상승** → **수입 물가** 재상승 **악순환** *(23:29)*.
- **관세** → 재화 **비용** 상방 *(14:12)*.

### B. 성장·수출

- **미국 소비 위축**(고금리) → **반도체** 등 **수출 수요** 감소 → 성장 동력 약화 *(21:48)*.

### C. 국면·정책

- **스태그플레이션 현실화 시나리오:** 물가 **한은 전망 2.2% 상회·3%대**, 성장률 **2% 초반** 또는 **하락** → **저성장–고물가** *(22:50)*.
- **통화정책 딜레마:** 물가를 위해 **금리 인상** 필요 vs **가계·정부 부채**로 인상 어려움 *(12:01)*.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF (Geo_Risk_MiddleEast escalates) THEN risk_of(Oil_Supply_Shock) AND Oil_Price pressure END
IF (Oil_Price up) AND Korea_Energy_Import_Dependence high THEN Korea_CPI_Path pressure (stronger vs US) END
IF US_Fed_Stance_Tight persists THEN US_Consumption down -> Korea_Export_Demand down END
IF US_Fed_Stance_Tight AND risk_off THEN FX_KRW_per_USD up -> import inflation loop -> Korea_CPI_Path END
IF US_Tariff_Shock THEN structural upward pressure on prices END
COMBINE channels -> Stagflation_Risk_Korea (high CPI path + weak growth)
Korea_Rate_Dilemma follows from (Korea_CPI_Path vs debt constraints)
```

```mermaid
flowchart TB
  G[Geo_Risk_MiddleEast] --> O[Oil_Supply_Shock]
  O --> P[Oil_Price pressure]
  K[Korea_Energy_Import_Dependence] --> C[Korea_CPI_Path]
  P --> C
  F[US_Fed_Stance_Tight] --> U[US_Consumption down]
  U --> X[Korea_Export_Demand down]
  F --> D[USD preference]
  D --> FX[FX_KRW_per_USD up]
  FX --> C
  T[US_Tariff_Shock] --> C
  C --> S[Stagflation_Risk_Korea]
  GR[Korea_GDP_Growth weak] --> S
  X --> GR
  C --> R[Korea_Rate_Dilemma]
```

---

<a id="evidence-data"></a>

## 6. Evidence — 영상 타임스탬프

| 시각 | 주제(영상 근거) |
|------|-----------------|
| 02:18 | 중동 분쟁·호르무즈 봉쇄 가능성·원유 공급망 |
| 07:45 | FOMC 이후 금리 인하 기대 약화·연말 인상 가능성 |
| 12:01 | 통화정책 딜레마(물가 vs 부채) |
| 14:12 | 관세·구조적 물가 압력 |
| 21:48 | 미국 소비 위축 → 한국 수출·성장 |
| 22:23 | 한국 에너지 수입·물가 직격(미국 대비) |
| 22:50 | 물가 3%대·성장 둔화 스태그플레이션 시나리오 |
| 23:29 | 금리차·달러·환율·수입물가 악순환 |

---

<a id="summary"></a>

## 7. 결론(메타)

영상은 **외부 유가 충격**과 **미국 긴축·정책**이 맞물릴 때, **에너지 의존·수출 구조** 때문에 한국이 **스태그플레이션 위험**에 특히 노출될 수 있다는 **경고형 전망**으로 요약된다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| FOMC | Event / policy | [§3](#root-cause), [§6](#evidence-data) |
| 호르무즈 | Geography | [§3](#root-cause) |
| 한국은행 전망치 2.2% | Reference number | [§4.C](#impact) |
| Oil_Price, Price_Level | Macro (일반 틀) | [oil-price-inflation-causality.md](oil-price-inflation-causality.md) |
| KOSPI, 선행지수, 섹터 (참고) | Equity / graph | [korea-kospi-leading-indicator-causality.md](korea-kospi-leading-indicator-causality.md) |
| 주택·정책 하방 (이현철 영상) | Real estate / graph | [korea-housing-policy-bear-causality-lee-video.md](korea-housing-policy-bear-causality-lee-video.md) |
| 글로벌 거시·반등 (홍춘욱 영상) | Macro / graph | [hong-chunwook-macro-rebound-causality-video.md](hong-chunwook-macro-rebound-causality-video.md) |
| 반도체 수출·환율 완충 vs 구리 실물 (홍춘욱 영상) | Macro / equity | [hong-chunwook-semiconductor-copper-kospi-causality.md](hong-chunwook-semiconductor-copper-kospi-causality.md) |
| 순대외금융자산·외환위기 서사 완화 (홍춘욱 영상) | Macro / balance sheet | [hong-chunwook-net-foreign-assets-fx-defense-causality.md](hong-chunwook-net-foreign-assets-fx-defense-causality.md) |
| 미국 ODM·AI 증시 낙관 (채상욱 영상) | Macro / equity | [chae-sangwook-korea-us-odm-ai-kospi-causality.md](chae-sangwook-korea-us-odm-ai-kospi-causality.md) |

---

## 관련 문서

- [유가·에너지·물가 전망과 투자 시사점](macro-energy-inflation-outlook.md): 3고·한은·투자 시사.
- [유가(Oil_Price) ↔ 물가(Price_Level) 인과 구조](oil-price-inflation-causality.md): 전달 기제·엣지 표.
- [국내 증시·선행지수·섹터 로테이션 (김영익, 영상)](korea-kospi-leading-indicator-causality.md): 선행 지수·코스피 밸류·**섹터·자산배분** 인과.
- [한국 주택·정책 하방 논리 (이현철 영상)](korea-housing-policy-bear-causality-lee-video.md): **주택** 시장·정책 인과(영상 근거).
- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): **스태그플레이션 강조** 서술과 **대비**할 수 있는 **반등·관리 가능** 서사.
- [반도체 수출·구리·코스피 (홍춘욱 영상)](hong-chunwook-semiconductor-copper-kospi-causality.md): 동일 화자의 **외화·환율 완충** 서사와 **실물(구리)·코스피** 조건 — 본 문서 **유가·환율·저성장** 압력 서술과 **병행**.
- [순대외금융자산·환율 해석 (홍춘욱 영상)](hong-chunwook-net-foreign-assets-fx-defense-causality.md): **`FX_KRW_per_USD`**를 **지정학·안전자산**으로 읽고 **순·총 대외자산**으로 **외환 위기** 서사를 낮게 보는 **대위 RCA** — 본 문서의 **환율·물가 악순환** 경로와 **합성·대비**.
- [한국 증시·미국 제조 ODM·AI (채상욱 영상)](chae-sangwook-korea-us-odm-ai-kospi-causality.md): **유가·금리 바닥**·**미·중 ODM** 기반 **장기 우상향** 서사 — 본 문서 **스태그플레이션·유가 직격**과 **대비**.

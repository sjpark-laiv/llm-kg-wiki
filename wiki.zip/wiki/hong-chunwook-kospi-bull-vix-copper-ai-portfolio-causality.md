---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: "영상 발화 요지 메모 기준"
---

# 코스피 강세·VIX·구리·AI·안전자산 (홍춘욱 박사 영상 인과, RCA·Impact)

**목적:** **홍춘욱** 박사 발화 중 **코스피 강세 지속** 전망, **VIX·숏 커버 랠리**, **구리(Dr. Copper)와 반도체 수요**, **챗GPT 이후 AI 투자·GPU·HBM 연쇄**, **코스피 200 ETF + 달러·금** 병행을 **RCA·Impact**용으로 구조화함.

**병행:** 동일 화자의 **반도체·구리·코스피 조건**은 [반도체 수출·구리·코스피 (홍춘욱)](hong-chunwook-semiconductor-copper-kospi-causality.md), **거시·부동산 반등**은 [글로벌 거시·부동산 일시 조정 후 반등](hong-chunwook-macro-rebound-causality-video.md)과 **합성**한다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Hong_ChunWook`** | 홍춘욱 (발화자) | Person. |
| **`KOSPI_Bull_Market_Continuation`** | 코스피 강세장 지속(전망) | **코스피 6,000포인트 돌파** 등 **긍정적** 시장 국면을 전제로 **강세 지속** 서술(영상 **주장**). |
| **`KOSPI_200_ETF_Strategy`** | 코스피 200 지수 ETF 전략 | **특정 섹터 집중**보다 **지수 ETF**로 **분산**하자는 조언 축. |
| **`Safe_Assets_USD_Gold_Blend`** | 안전자산(달러·금) 혼합 | **달러**와 **금**을 **동시 보유**해 **외부 충격**에 대비하자는 포트폴리오 서술. |
| **`VIX_Index_Sub20_Normalization`** | VIX 20 미만·심리 정상화 | **공포 지수** **VIX**가 **20 미만**으로 **하락** → 변동성 **기대 정상화** *(01:53)*. |
| **`Market_Sentiment_Recovery`** | 투자 심리 회복 | 전쟁 등 **대외 악재 지속**에도 **심리 회복** 서술. |
| **`Short_Cover_Rally`** | 숏 커버 랠리 | 하락 **베팅(숏)** 포지션 청산을 위한 **매수**가 **주가 상방**을 견인 *(02:42)*. |
| **`Copper_Price_Dr_Copper`** | 구리 가격 (Dr. Copper) | **바닥** 후 **상승 추세** 서술 *(04:11)*. [반도체·구리 문서](hong-chunwook-semiconductor-copper-kospi-causality.md#entities)와 동일 라벨. |
| **`Upstream_Industrial_Demand_Copper`** | 구리 수요(전방 산업) | **전기차**, **AI 서버**, **전자기기** 등 **핵심 원자재** 수요 프록시 *(05:23)*. |
| **`Semiconductor_Export_Pricing_Margin`** | 반도체 수출 가격·수익성 | 구리 상승이 **전방 수요 살아남**의 신호 → **반도체 수출 가격·수익성 개선**으로 연결 *(05:23)*. |
| **`AI_Investment_Wave_Post_ChatGPT`** | AI 투자 확대(챗GPT 이후) | **2022년 말** **챗GPT** 등장 이후 **AI 관련 투자 급증** *(06:00)*. |
| **`Nvidia_GPU_Sales_Channel`** | 엔비디아 GPU 판매 | AI 투자 활성화와 함께 **GPU 판매 증가** 서술 *(05:41)*. |
| **`HBM_Memory_Demand_Cascade`** | HBM·메모리 수요(연쇄) | GPU 수요가 **HBM** 등 **메모리 반도체**·**기타 전자** 수요를 **촉발** *(05:41)*. |
| **`Semiconductor_Sector_Rally`** | 반도체 섹터 랠리 | 위 연쇄가 **반도체 강한 랠리**로 수렴 *(05:41)*. |
| **`Safe_Asset_Regime_History_Comparison`** | 안전자산 국면별 수익(사례) | **2025년 상호관세** 시기 vs **2026년 전쟁** 시기 등 **달러 vs 금** **상대 수익**이 **달랐다**는 비교 *(08:33)*. |
| **`Lehman_Liquidity_Gold_Selloff_Narrative`** | 리만 시 금 매도(유동성) | **현금 확보**를 위해 **금 매도** → 금값 **급락** 가능성 등 **“항상 안전” 아님** 반례 *(11:13)*. |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 인과 기제 | 세부 | 태그 |
|------|------------|------|------|
| **심리** | VIX 하락 | **20 미만** → 공포·변동성 기대 **완화** | `RCA`+`Evidence` |
| **가격** | 숏 커버 | 심리 회복 + 숏 청산 **매수** → **지수 상방** | `Impact` |
| **실물** | 구리 상승 | **전방 산업** 수요 회복 신호 | `RCA`+`Evidence` |
| **이익** | 구리→반도체 | **수출 가격·마진** 개선 서사 | `Impact` |
| **AI** | 투자→GPU→HBM | **연쇄 수요** → **반도체 랠리** | `RCA`+`Impact` |
| **운용** | ETF·달러·금 | **리딩 섹터 리스크** 완화·**안전자산 상호보완** | `Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `VIX_Index_Sub20_Normalization` | `signals` | `Market_Sentiment_Recovery` | `fear_gauge` |
| `Market_Sentiment_Recovery` | `triggers` | `Short_Cover_Rally` | `short_squeeze` |
| `Short_Cover_Rally` | `pushes` | `KOSPI_Bull_Market_Continuation` | `buy_to_cover` |
| `Copper_Price_Dr_Copper` | `signals` | `Upstream_Industrial_Demand_Copper` | `dr_copper` |
| `Upstream_Industrial_Demand_Copper` | `supports` | `Semiconductor_Export_Pricing_Margin` | `demand_to_pricing` |
| `Semiconductor_Export_Pricing_Margin` | `feeds` | `Semiconductor_Sector_Rally` | `earnings_revision` |
| `AI_Investment_Wave_Post_ChatGPT` | `raises` | `Nvidia_GPU_Sales_Channel` | `capex_wave` |
| `Nvidia_GPU_Sales_Channel` | `pulls` | `HBM_Memory_Demand_Cascade` | `supply_chain` |
| `HBM_Memory_Demand_Cascade` | `drives` | `Semiconductor_Sector_Rally` | `memory_cycle` |
| `Semiconductor_Sector_Rally` | `reinforces` | `KOSPI_Bull_Market_Continuation` | `index_weight` |
| `KOSPI_Bull_Market_Continuation` | `implies_strategy` | `KOSPI_200_ETF_Strategy` | `diversification` |
| `Safe_Asset_Regime_History_Comparison` | `motivates` | `Safe_Assets_USD_Gold_Blend` | `regime_uncertainty` |
| `Lehman_Liquidity_Gold_Selloff_Narrative` | `motivates` | `Safe_Assets_USD_Gold_Blend` | `not_single_safe_haven` |
| `Semiconductor_Sector_Rally` | `hedged_by` | `Safe_Assets_USD_Gold_Blend` | `tail_risk` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`) — “강세를 뒷받침하는 근원은?”

- **심리·포지션:** **VIX** **20 미만**으로 **변동성 기대 정상화** → 악재에도 **심리 회복** → **숏 커버** 매수로 **주가 견인** *(01:53)*, *(02:42)*.
- **실물 프록시:** **구리** **상승 추세**가 **전기차·AI 서버·전자** 등 **전방 수요** 회복 신호 → **반도체 수출 가격·수익성** 개선으로 연결 *(04:11)*, *(05:23)*.
- **AI 연쇄:** **2022년 말 챗GPT** 이후 **AI 투자 급증** → **엔비디아 GPU** → **HBM·메모리·전자** **연쇄 수요** → **반도체 랠리** *(06:00)*, *(05:41)*.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`) — “전망·운용은?”

- **국면:** **코스피 6,000 돌파** 등을 **긍정**적으로 보고 **반도체 중심 강세** **지속** 서사.
- **자산 선택:** **특정 섹터·종목**보다 **코스피 200 지수 ETF**로 **넓게** 참여.
- **안전자산:** **달러**와 **금**을 **동시** 보유 — **국면(관세 vs 전쟁)**에 따라 **상대 수익이 달랐다**는 사례 *(08:33)*, **리만** 때 **금 매도**로 **“금만이 안전”은 아님** *(11:13)* → **혼합** 강조.
- **메타 논리:** **“구리 상승 + AI 투자 확대 → 반도체 업활 → 심리 개선 → 숏 커버로 주가 상방”**으로 **요약** 가능(영상 재구성).

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF VIX_Index_Sub20_Normalization THEN Market_Sentiment_Recovery END
IF Market_Sentiment_Recovery THEN Short_Cover_Rally END
IF Short_Cover_Rally THEN KOSPI_Bull_Market_Continuation pressure_up END
IF Copper_Price_Dr_Copper up_trend THEN Upstream_Industrial_Demand_Copper alive END
IF Upstream_Industrial_Demand_Copper THEN Semiconductor_Export_Pricing_Margin improves END
IF AI_Investment_Wave_Post_ChatGPT THEN Nvidia_GPU_Sales_Channel up END
IF Nvidia_GPU_Sales_Channel THEN HBM_Memory_Demand_Cascade END
IF HBM_Memory_Demand_Cascade THEN Semiconductor_Sector_Rally END
STRATEGY: KOSPI_200_ETF_Strategy AND Safe_Assets_USD_Gold_Blend END
```

```mermaid
flowchart TB
  VIX[VIX_Index_Sub20_Normalization] --> SENT[Market_Sentiment_Recovery]
  SENT --> SC[Short_Cover_Rally]
  SC --> KOS[KOSPI_Bull_Market_Continuation]
  CP[Copper_Price_Dr_Copper] --> IND[Upstream_Industrial_Demand_Copper]
  IND --> SEM[Semiconductor_Export_Pricing_Margin]
  AI[AI_Investment_Wave_Post_ChatGPT] --> NV[Nvidia_GPU_Sales_Channel]
  NV --> HBM[HBM_Memory_Demand_Cascade]
  HBM --> RALLY[Semiconductor_Sector_Rally]
  SEM --> RALLY
  RALLY --> KOS
  KOS --> ETF[KOSPI_200_ETF_Strategy]
  KOS --> SAFE[Safe_Assets_USD_Gold_Blend]
```

---

<a id="evidence-data"></a>

## 6. Evidence — 타임스탬프(메모)

| 시각 | 주제 |
|------|------|
| 01:53 | VIX 20 미만·변동성 기대 정상화 |
| 02:42 | 심리 회복·숏 커버 랠리 |
| 04:11 | 구리 바닥 후 상승 추세 |
| 05:23 | 구리→전방 수요→반도체 수출 가격·수익성 |
| 05:41 | GPU→HBM·메모리·반도체 랠리 |
| 06:00 | 2022년 말 챗GPT 이후 AI 투자 급증 |
| 08:33 | 2025 관세 vs 2026 전쟁·달러 vs 금 수익 비교 |
| 11:13 | 리만 시 금 매도·항상 안전 아님 |

---

<a id="summary"></a>

## 7. 결론(메타)

이 영상 축은 **심리(VIX·숏 커버)**와 **실물 신호(구리)**·**AI 공급망(GPU→HBM)**이 **반도체·코스피 강세**로 **수렴**한다는 **낙관적 통합 서사**다. **운용**은 **지수 ETF**로 **섹터 집중 리스크**를 줄이고, **달러+금**으로 **안전자산 국면 의존**을 완화한다. [김영익 교수 영상](korea-kospi-leading-indicator-causality.md)의 **선행·밸류 하방** 논의와 **축이 다름**을 유의한다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| Hong_ChunWook | Person | 이 문서, [거시·부동산 반등](hong-chunwook-macro-rebound-causality-video.md) |
| 구리·반도체 | Macro | [hong-chunwook-semiconductor-copper-kospi-causality.md](hong-chunwook-semiconductor-copper-kospi-causality.md) |
| 금·달러 | Asset | [macro-energy-inflation-outlook.md](macro-energy-inflation-outlook.md) (금 시사) |
| 가치·배당·장기 복리 (숙향 영상) | Equity / process | [sukhyang-value-dividend-longterm-investing-causality.md](sukhyang-value-dividend-longterm-investing-causality.md) |

---

## 관련 문서

- [반도체 수출·구리·코스피 (홍춘욱 영상)](hong-chunwook-semiconductor-copper-kospi-causality.md): **구리·반도체·진입 타이밍** 인과.
- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): **CD ETF·자산배분** 상위 서사.
- [국내 증시·선행지수 (김영익, 영상)](korea-kospi-leading-indicator-causality.md): **다른** 증시 **하방** 인과.
- [순대외금융자산·환율 해석 (홍춘욱 영상)](hong-chunwook-net-foreign-assets-fx-defense-causality.md): **달러** 포지션 맥락.
- [유가·에너지·물가 전망 (메모)](macro-energy-inflation-outlook.md): 거시 **허브**.
- [가치·배당·장기 복리 (숙향 영상)](sukhyang-value-dividend-longterm-investing-causality.md): **개별 가치주·배당 재투자** — 본 문서 **지수 ETF** 중심과 **대비**.

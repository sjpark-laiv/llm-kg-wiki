---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: "영상 발화 요지 메모 기준"
---

# 가치·배당·장기 복리 (숙향 전업 투자자 영상 인과, RCA·Impact)

**목적:** **숙향** 님 발화를 **철학·방법론·위기 대응·노후** 축으로 나누어 **장기 복리·재무제표·배당·분산·일기·보유**가 **결과(자산 축적·회복력)**에 어떻게 연결되는지 **RCA·Impact** 추론용으로 구조화함.

**병행:** 단기 **선행·밸류 하방**·섹터 로테이션은 [김영익 교수 영상 인과](korea-kospi-leading-indicator-causality.md), **월배당·액티브 ETF** 제안은 [채상욱 ODM·AI](chae-sangwook-korea-us-odm-ai-kospi-causality.md), **지수 ETF·안전자산**은 [홍춘욱 코스피 강세·VIX](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md)와 **대비·합성**해 읽는다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Sukhyang_Investor`** | 숙향 (전업 투자자) | 본 영상 발언 정리 대상 Person. |
| **`Philosophy_Slow_Wealth_Compound`** | 철학: 천천히 부자 되기 | **복리**·**조급함 배제**·**장기**를 핵심으로 하는 투자 철학. |
| **`Compound_Return_Record_2005_2025`** | 복리 실적(발화 수치) | **2005~2025** 약 **20년**, 연 **복리 약 18%**, **1억 원 → 약 31~32억 원** 서술 *(00:00)*. |
| **`Anti_Speculation_No_HotStock_Chase`** | 단기·상한가 추격 금지 | **6개월 50~100%** 심리·**상한가 종목** 추격은 **지양** *(11:48)*. |
| **`Behavior_Drawdown_Risk`** | 행동 기인 낙폭 리스크 | 스펙·상한가 **추격** 등으로 **손실 확대**될 수 있는 위험(분석용 라벨). |
| **`Safety_Margin_Target_2x_Deposit_Yield`** | 안전 마진(목표 수익률) | **은행 정기예금 금리의 약 2배** 수준을 목표, **배당 + 가치 상승** 병행 *(08:26)*. |
| **`Quality_Earnings_Persistence`** | 이익 지속·증가(질) | 7~10년 재무에서 확인하는 **이익 궤적** 품질(분석용 라벨). |
| **`Idiosyncratic_Risk_SingleStock`** | 개별종목(집중) 리스크 | 소수 종목 집중 시 **특정 사건** 노출(분석용 라벨). |
| **`Emotional_Discipline_Crisis`** | 위기 시 감정·행동 통제 | **일기** 등으로 **패닉 매매**를 줄인다는 서사와 연결. |
| **`Financial_Statement_Analysis_7to10Y`** | 재무제표 분석(7~10년) | 회계 배경 하 **최소 7년~10년** 재무를 보고 **이익의 지속·증가**를 확인 *(04:06)*, *(30:12)*. |
| **`Graham_Value_Framework_Ref`** | 그레이엄식 가치 틀 | **벤저민 그레이엄** 방식을 **준용**한다는 서술 *(04:06)*. |
| **`Value_Screen_Low_PBR_PER`** | 저PBR·저PER 선정 | **PBR**·**PER**이 **낮은** 저평가주 선호 *(29:47)*. |
| **`Dividend_Yield_Priority_Reinvest`** | 배당 우선·재투자 | **배당 수익률** 높은 종목 우선; 배당을 **은행 이자**처럼 쓰고 **재투자로 수량 증가** *(28:05)*. |
| **`Portfolio_Diversification_10to20`** | 분산(10~20종) | **한두 종목 집중** 위험 회피, **10~20개**로 **무지(특정 기업) 리스크** 분산 *(07:05)*, *(23:51)*. |
| **`Investment_Diary_Key_Decisions`** | 투자 일기 | **중요 매매**·**위기 순간**에 기록 *(17:23)*, *(19:47)*. |
| **`Crisis_2008_Drawdown_Recovery_Narrative`** | 2008 위기 경험 | **약 50%** 손실 구간에서도 **일기**로 **마음 다스림**, **시장보다 빠른 회복** 서술 *(17:23)*, *(19:47)*. |
| **`Hold_Monbodang_Intrinsic_Value_Intact`** | 몸빵 보유(가치 유지 시) | 전쟁·정치 이슈로 시장이 흔들려도 **기업 가치 훼손 없으면** **매매 안 함**·**보유** *(13:22)*, *(15:29)*. |
| **`Long_Hold_Example_Shinyoung_20yPlus`** | 장기 보유 사례(신영증권) | **가치·배당** 충족 시 **20년 이상** 보유 사례 언급 *(26:44)*. |
| **`Retirement_Dividend_Lifestyle_Model`** | 노후 배당 생활비 모델 | 은퇴 후 **배당만으로 생활비** 목표; 투자를 **평생 직업**으로 두는 서사 *(33:28)*, *(34:36)*. |
| **`Far_View_Market_Uptrend_Belief`** | 원거리 우상향 믿음 | 가까이 보면 알 수 없으나 **멀리 보면 우상향**—**가치 주식을 싸게 사서 기다림** *(42:17)*. |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 인과 기제 | 세부 | 태그 |
|------|------------|------|------|
| **철학** | 복리·기간 | **18%×20년** 누적 서사 | `Evidence`+`Impact` |
| **철학** | 스펙 배제 | 상한가·단기 고수익 추격 **차단** | `RCA`+`Impact` |
| **선정** | 재무 7~10년 | 품질·지속 이익 **필터** | `RCA` |
| **선정** | 밸류 스크린 | 저PBR·저PER | `RCA` |
| **현금흐름** | 배당 | **이자 대체**·**재투자** | `Impact` |
| **리스크** | 10~20종 | **무지 분산** | `Impact` |
| **행동** | 일기 | **감정·결정** 기록 → 위기 **회복** | `RCA`+`Impact` |
| **행동** | 가치 몸빵 | 외생 쇼크 vs **내재가치** 분리 | `Impact` |
| **노후** | 배당 모델 | **경제적 자유** 목표 | `Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Philosophy_Slow_Wealth_Compound` | `enables` | `Compound_Return_Record_2005_2025` | `long_horizon` |
| `Anti_Speculation_No_HotStock_Chase` | `reduces` | `Behavior_Drawdown_Risk` | `avoid_chase` |
| `Safety_Margin_Target_2x_Deposit_Yield` | `guides` | `Value_Screen_Low_PBR_PER` | `hurdle_rate` |
| `Financial_Statement_Analysis_7to10Y` | `filters` | `Quality_Earnings_Persistence` | `fundamental_screen` |
| `Graham_Value_Framework_Ref` | `structures` | `Financial_Statement_Analysis_7to10Y` | `value_investing` |
| `Quality_Earnings_Persistence` | `supports` | `Hold_Monbodang_Intrinsic_Value_Intact` | `conviction` |
| `Value_Screen_Low_PBR_PER` | `combined_with` | `Dividend_Yield_Priority_Reinvest` | `cheap_cashflow` |
| `Dividend_Yield_Priority_Reinvest` | `compounds` | `Compound_Return_Record_2005_2025` | `drip` |
| `Portfolio_Diversification_10to20` | `reduces` | `Idiosyncratic_Risk_SingleStock` | `diversification` |
| `Investment_Diary_Key_Decisions` | `improves` | `Emotional_Discipline_Crisis` | `journaling` |
| `Emotional_Discipline_Crisis` | `enabled_recovery_in` | `Crisis_2008_Drawdown_Recovery_Narrative` | `process_over_panic` |
| `Hold_Monbodang_Intrinsic_Value_Intact` | `extends` | `Long_Hold_Example_Shinyoung_20yPlus` | `time_arbitrage` |
| `Dividend_Yield_Priority_Reinvest` | `feeds` | `Retirement_Dividend_Lifestyle_Model` | `income_engine` |
| `Far_View_Market_Uptrend_Belief` | `supports` | `Philosophy_Slow_Wealth_Compound` | `macro_patience` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`) — “왜 이 방식이 작동한다고 말하는가?”

- **복리·기간:** **조급한 단기 고수익**을 버리고 **장기**에 **복리**를 얹는 것이 **1억→30억대** 서사의 **축** *(00:00)*.
- **안전 마진:** **예금 금리의 2배**를 **허들**로 삼아 **과도한 기대·고위험 스펙**을 걸러낸다는 논리 *(08:26)*.
- **재무:** **7~10년** 재무로 **이익의 질·지속성**을 본 뒤 **그레이엄식** 저평가와 결합 *(04:06)*, *(30:12)*, *(29:47)*.
- **배당:** 주가 정체 시에도 **현금흐름**이 나와 **버티기·재투자**가 가능하다는 **현금흐름 엔진** *(28:05)*.
- **분산:** **10~20종**으로 **개별 기업 사건** 리스크를 낮춘다는 **무지 대비** *(07:05)*, *(23:51)*.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`) — “무엇이 달라지는가?”

- **위기:** **투자 일기**로 **감정·결정**을 관리; **2008** **대폭 손실**에서도 **시장보다 빠른 회복** 서술 *(17:23)*, *(19:47)*.
- **보유:** 전쟁·정치 **노이즈**에 **거래하지 않고** **가치 유지** 시 **몸빵** *(13:22)*, *(15:29)*.
- **기간:** **신영증권** 예시처럼 **20년+** **장기 보유** 가능 조건(가치·배당) *(26:44)*.
- **노후:** **배당만으로 생활비** 설계, 투자를 **평생 직업**으로 두어 **정신·경제** 양면 서술 *(33:28)*, *(34:36)*.
- **세계관:** **원거리 우상향** 믿음 + **싸게 사서 기다림** = **가장 확실하고 쉬운 길**이라는 **규범적 결론** *(42:17)*.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF Philosophy_Slow_Wealth_Compound AND NOT Anti_Speculation_No_HotStock_Chase violated
THEN pursue Compound_Return_Record_2005_2025 style outcomes END
IF Financial_Statement_Analysis_7to10Y passes Quality_Earnings_Persistence
AND Value_Screen_Low_PBR_PER AND Dividend_Yield_Priority_Reinvest
THEN eligible_for Long_Hold_Example_Shinyoung_20yPlus END
IF Portfolio_Diversification_10to20 THEN reduce Idiosyncratic_Risk_SingleStock END
IF Investment_Diary_Key_Decisions THEN improve Emotional_Discipline_Crisis END
IF intrinsic_value_intact THEN Hold_Monbodang_Intrinsic_Value_Intact ELSE review END
STRATEGY Retirement_Dividend_Lifestyle_Model with Far_View_Market_Uptrend_Belief END
```

```mermaid
flowchart LR
  PH[Philosophy_Slow_Wealth_Compound] --> CR[Compound_Return_Record_2005_2025]
  FS[Financial_Statement_Analysis_7to10Y] --> Q[Quality_Earnings_Persistence]
  VS[Value_Screen_Low_PBR_PER] --> PICK[Stock_selection]
  DV[Dividend_Yield_Priority_Reinvest] --> CR
  DIV[Portfolio_Diversification_10to20] --> RISK[Risk_down]
  DIARY[Investment_Diary_Key_Decisions] --> EM[Emotional_Discipline_Crisis]
  HOLD[Hold_Monbodang_Intrinsic_Value_Intact] --> LONG[Long_Hold_Example_Shinyoung_20yPlus]
```

---

<a id="evidence-data"></a>

## 6. Evidence — 타임스탬프(메모)

| 시각 | 주제 |
|------|------|
| 00:00 | 2005~2025·복리 약 18%·1억→31~32억 |
| 04:06 | 재무제표·그레이엄 |
| 07:05 | 분산 투자 |
| 08:26 | 예금 금리 2배 목표·배당+가치 |
| 11:48 | 단기 고수익·상한가 추격 금지 |
| 13:22 | 전쟁·정치 vs 가치 |
| 15:29 | 몸빵 보유 보강 |
| 17:23 | 투자 일기·위기 |
| 19:47 | 2008 손실·회복 |
| 23:51 | 10~20종 분산 |
| 26:44 | 신영증권 20년+ |
| 28:05 | 배당·재투자 |
| 29:47 | 저PBR·저PER |
| 30:12 | 7~10년 재무 |
| 33:28 | 노후 배당 생활비 |
| 34:36 | 평생 직업·건강 |
| 42:17 | 멀리 보면 우상향·싸게 사서 기다림 |

---

<a id="summary"></a>

## 7. 결론(메타)

이 서사는 **미시(재무)·밸류·배당·분산**으로 **하방과 현금흐름**을 확보하고, **일기·장기 시야**로 **위기 행동**을 통제하며, **노후에는 배당 현금흐름**으로 **전환**하는 **일관된 장기 가치 투자 그래프**다. **단기 매매·ETF 중심** 서사와 **접점은 있으나 초점이 다름**을 유의한다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| Sukhyang_Investor | Person | 이 문서 |
| 벤저민 그레이엄 | Thinker / framework | [§1](#entities) |
| 신영증권 | Organization (사례) | [§4](#impact) |
| 김영익·선행지수 | Cross-ref | [korea-kospi-leading-indicator-causality.md](korea-kospi-leading-indicator-causality.md) |

---

## 관련 문서

- [국내 증시·선행지수·섹터 (김영익, 영상)](korea-kospi-leading-indicator-causality.md): **선행·밸류·방어** 등 **다른** 증시 운용 인과.
- [한국 증시·미국 제조 ODM·AI (채상욱 영상)](chae-sangwook-korea-us-odm-ai-kospi-causality.md): **월배당·액티브 ETF** 등 **현금흐름** 제안.
- [코스피 강세·VIX·구리·AI·안전자산 (홍춘욱 영상)](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md): **코스피200 ETF**·**안전자산** 병행.
- [유가·에너지·물가 전망 (메모)](macro-energy-inflation-outlook.md): **분산·금** 등 거시 **허브**.

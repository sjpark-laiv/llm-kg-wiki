---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: "영상 발화 요지 메모 기준"
---

# 한국 증시·미국 제조 ODM·AI (채상욱 대표 영상 인과, RCA·Impact)

**목적:** **채상욱** 대표 발화 중 **‘중국 수혜 사이클’ → ‘미국 제조업 ODM 사이클’** 전환, **미·중 공급망**, **AI·HBM**, **금리·유가**, **퇴직연금 제도**, **밸류에이션(PBR→PER)** 및 **투자 제안**을 **RCA·Impact** 추론용으로 구조화함.

**대비 서사:** 선행 지수·밸류 **하방** 강조는 [김영익 교수 영상 인과](korea-kospi-leading-indicator-causality.md), **저성장·고물가**·유가 직격은 [한국 스태그플레이션 리스크](korea-stagflation-risk-causality.md), **반도체·외화** 완충은 [홍춘욱 반도체·구리](hong-chunwook-semiconductor-copper-kospi-causality.md)와 **병행**해 읽는다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Chae_SangWook`** | 채상욱 (대표) | 본 영상 발언 정리 대상 Person. |
| **`China_Beneficiary_Cycle_Legacy`** | 중국 수혜 사이클(과거) | 한국 증시가 **과거** 기대던 **중국 성장 연동** 국면. |
| **`US_Manufacturing_ODM_Cycle_Korea`** | 미국 제조업 ODM 사이클(한국) | 한국 증시가 **‘미국 제조업 ODM’** 거대 **퀀텀 점프** 구간에 들어갔다는 **전망 라벨** *(16:41)*. |
| **`US_China_SupplyChain_Decoupling`** | 미·중 공급망 갈등·배제 | 미국이 중국을 **공급망에서 배제**하며 **대체 고품질 제조 거점** 수요가 커졌다는 지정학·산업 서술 *(12:13)*. |
| **`US_Manufacturing_Outsourcing_Demand`** | 미국 제조·아웃소싱 수요 | 한국이 **미국 전방위 ODM 기지**로 기능할 **수요** 축. |
| **`Peer_Competition_DE_JP_Narrative`** | 독·일 경쟁 서사(영상) | 독일: **에너지 비용**·기계·자동차 중심; 일본: **IT·소프트웨어** 약점 — **한국 대비** 프레임 *(12:41)*. |
| **`Korea_Frontier_Manufacturing_Cluster`** | 한국 첨단 제조 클러스터 | **반도체**, **방산**, **원전**, **조선** 등 **첨단 제조** 전반 경쟁력 강조 *(12:41)*, *(18:05)*. |
| **`AI_Bottleneck_Resolution_Narrative`** | AI·산업 병목 해소 서사 | AI를 **일시 유행**이 아니라 산업 **병목 해소**의 **장기 흐름**으로 규정 *(24:59)*. |
| **`Semiconductor_HBM_AI_Infrastructure`** | 반도체·HBM·AI 인프라 | AI 구현을 위한 **HBM** 및 **인프라** 수요 급증 → 반도체 **이익·사이클** 서술과 연결. |
| **`Oil_War_Rates_PricedIn_Bottoming`** | 유가·전쟁 선반영·금리 바닥 서사 | 전쟁 **유가 상승**은 이미 **시장 금리에 선반영**; **경기 둔화** 우려로 금리 **하방** 기대가 **바닥권** 형성 *(01:28)*, *(24:22)*. |
| **`Pension_Fund_Reform_LongCapital`** | 퇴직연금 기금화·위탁 개편 | **기금화**·**위탁 관리** 제도 개편으로 **장기 롱머니** 유입·**하방 경직성** *(06:06)*. |
| **`KOSPI_ReRating_PBR_to_PER`** | 코스피 재평가(PBR→PER) | **PBR 중심**에서 **PER 중심**으로, **자산 가치**보다 **수익 성장** 인정 → **멀티플 상승** 서사. |
| **`Market_Volatility_Mitigation_Institutional`** | 변동성 완화(기관·제도) | **매도 사이드카** 등으로 **변동성 완화**·**지수 우상향** 보조 논리(영상 요지). |
| **`US_Strategic_Partner_Korea_Narrative`** | 미국의 전략적 파트너(한국) | 한국이 **‘대체 불가능한’** 미국 **전략적 파트너**로 격상된다는 서사 *(19:11)*. |
| **`Retail_Strategy_ActiveETF_Dividend`** | 개인 투자 제안(액티브 ETF·월배당) | **병목**을 찾는 **액티브 ETF**, **월 현금흐름**의 **월 배당 성장주** 참여 제안 *(26:10)*, *(38:44)*. |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 인과 기제 | 세부 | 태그 |
|------|------------|------|------|
| **지정학** | 미·중 배제 → 대체 제조 | **고품질 제조** 대체지 필요 → **한국 ODM** 수요 | `RCA`+`Impact` |
| **산업** | AI → HBM·인프라 | **반도체** 이익 **극대화**·사이클 **장기화** | `RCA`+`Impact` |
| **밸류** | 이익 성장 인정 | **PBR→PER** → **멀티플 상승** | `Impact` |
| **수급** | 연금 개편 | **장기 자본** 상시 → **하방 경직**·**변동성 완화** | `RCA`+`Impact` |
| **거시** | 유가·금리 | **선반영**·**둔화 우려 금리** → **바닥권** | `RCA`+`Evidence` |
| **서사** | 전략적 파트너 | **미국 제조 아웃소싱**을 한국이 **구조적으로 수혜** | `Impact` |
| **행동** | 장기 투자 | 전쟁 **변동성**에 **패닉 금지**·**이익·멀티플** 주목 *(14:40)* | `Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `US_China_SupplyChain_Decoupling` | `creates_demand_for` | `US_Manufacturing_Outsourcing_Demand` | `decouple_reshore` |
| `US_Manufacturing_Outsourcing_Demand` | `routes_to` | `US_Manufacturing_ODM_Cycle_Korea` | `korea_odm_hub` |
| `Korea_Frontier_Manufacturing_Cluster` | `enables` | `US_Manufacturing_ODM_Cycle_Korea` | `manufacturing_moat` |
| `Peer_Competition_DE_JP_Narrative` | `weakens_alternatives_to` | `US_Manufacturing_ODM_Cycle_Korea` | `peer_comparison` |
| `AI_Bottleneck_Resolution_Narrative` | `amplifies` | `Semiconductor_HBM_AI_Infrastructure` | `ai_capex` |
| `Semiconductor_HBM_AI_Infrastructure` | `drives` | `KOSPI_ReRating_PBR_to_PER` | `earnings_growth` |
| `KOSPI_ReRating_PBR_to_PER` | `supports` | `US_Manufacturing_ODM_Cycle_Korea` | `multiple_expansion` |
| `Pension_Fund_Reform_LongCapital` | `adds` | `Market_Volatility_Mitigation_Institutional` | `long_only_flow` |
| `Market_Volatility_Mitigation_Institutional` | `supports` | `US_Manufacturing_ODM_Cycle_Korea` | `drawdown_buffer` |
| `Oil_War_Rates_PricedIn_Bottoming` | `limits_downside_narrative` | `US_Manufacturing_ODM_Cycle_Korea` | `macro_floor` |
| `US_Strategic_Partner_Korea_Narrative` | `reinforces` | `US_Manufacturing_ODM_Cycle_Korea` | `geopol_lockin` |
| `Chae_SangWook` | `recommends` | `Retail_Strategy_ActiveETF_Dividend` | `advice` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`) — “왜 한국·코스피가 ODM 국면인가?”

- **공급망:** 미·중 갈등 속 미국의 **중국 배제** → **대체 고품질 제조** 필요 → 한국이 **수요 흡수** 후보로 부상 *(12:13)*.
- **경쟁 구도:** 독·일 **약점** 대비 한국 **첨단 제조** **강점** 서술 *(12:41)*, *(18:05)*.
- **AI:** 산업 **병목** 해소의 **장기 사이클**이며, 한국은 **하드웨어** 공급에서 **핵심** 위치 *(24:59)*.
- **거시 바닥 서사:** **유가(전쟁)**는 **금리에 선반영**; **경기 둔화** 우려가 **금리 하방**·**바닥권** 논리 *(01:28)*, *(24:22)*.
- **수급:** **퇴직연금** **기금화·위탁** 개편 → **장기 롱머니**·**하방 경직** *(06:06)*.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`) — “무엇이 바뀌는가?”

- **국면 전환:** 과거 **중국 수혜**에서 **미국 제조 ODM**으로의 **구조적 변화**·**퀀텀 점프** *(16:41)*.
- **이익·밸류:** **HBM·인프라** 수요 → 반도체 **이익 극대화**·사이클 **장기화**; **PBR→PER**로 **수익 성장**이 멀티플에 반영.
- **지수:** **변동성 완화**(사이드카 등)·**기관 장기 자금** → **지수 우상향** 보조 서사.
- **지정학 서사:** 한국을 **대체 불가능한** 미국 **전략적 파트너**로 격상 *(19:11)*.
- **투자자 행동:** 일시 **전쟁 리스크**에 **패닉** 지양, **이익 체력·멀티플** **장기** 관점 *(14:40)*; 실행은 **액티브 ETF(병목)**·**월 배당 성장주** 제안 *(26:10)*, *(38:44)*.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF US_China_SupplyChain_Decoupling THEN US_Manufacturing_Outsourcing_Demand rises END
IF Korea_Frontier_Manufacturing_Cluster best_fit THEN US_Manufacturing_ODM_Cycle_Korea strengthens END
IF AI_Bottleneck_Resolution_Narrative THEN Semiconductor_HBM_AI_Infrastructure demand_long_cycle END
IF Semiconductor_HBM_AI_Infrastructure strong THEN KOSPI_ReRating_PBR_to_PER END
IF Pension_Fund_Reform_LongCapital THEN Market_Volatility_Mitigation_Institutional AND downside_rigidity END
IF Oil_War_Rates_PricedIn_Bottoming THEN macro_floor_narrative_for_equities END
STRATEGY per Chae_SangWook: Retail_Strategy_ActiveETF_Dividend; avoid panic on war_volatility END
```

```mermaid
flowchart LR
  DC[US_China_SupplyChain_Decoupling] --> UD[US_Manufacturing_Outsourcing_Demand]
  KC[Korea_Frontier_Manufacturing_Cluster] --> ODM[US_Manufacturing_ODM_Cycle_Korea]
  UD --> ODM
  AI[AI_Bottleneck_Resolution_Narrative] --> HBM[Semiconductor_HBM_AI_Infrastructure]
  HBM --> RER[KOSPI_ReRating_PBR_to_PER]
  PEN[Pension_Fund_Reform_LongCapital] --> VOL[Market_Volatility_Mitigation_Institutional]
  RER --> ODM
  VOL --> ODM
```

---

<a id="evidence-data"></a>

## 6. Evidence — 타임스탬프(메모)

| 시각 | 주제 |
|------|------|
| 01:28 | 유가·전쟁 선반영, 금리·바닥권 논의 |
| 06:06 | 퇴직연금 기금화·위탁, 장기 롱머니·하방 |
| 12:13 | 미·중, 중국 배제·대체 제조 거점 |
| 12:41 | 독·일 vs 한국 제조 경쟁력 |
| 14:40 | 전쟁 리스크·패닉 지양, 이익·멀티플 장기 |
| 16:41 | 중국 수혜 → 미국 제조 ODM 퀀텀 점프 |
| 18:05 | 한국 첨단 제조(반도체·방산·원전·조선 등) |
| 19:11 | 대체 불가 전략적 파트너 |
| 24:22 | 금리·거시 바닥(선반영) 보충 |
| 24:59 | AI=병목 해소, 한국 하드웨어 |
| 26:10 | 액티브 ETF(병목) 제안 |
| 38:44 | 월 배당 성장주 제안 |

---

<a id="summary"></a>

## 7. 결론(메타)

영상 핵심은 **지정학(미·중)·AI·제조 클러스터**가 맞물려 한국을 **미국 제조 ODM 허브**로 올리고, **연금 자본**이 **변동성·하방**을 받쳐 **장기 우상향·재평가**를 그리는 **강한 낙관 구조**다. **유가·금리 바닥** 서사는 [유가–물가 인과](oil-price-inflation-causality.md)·[거시 메모](macro-energy-inflation-outlook.md)의 **다른 해석**과 **긴장**할 수 있다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| Chae_SangWook | Person | 이 문서 |
| 코스피·ODM·AI | Macro / equity | 이 문서 |
| 반도체·HBM | Sector | [hong-chunwook-semiconductor-copper-kospi-causality.md](hong-chunwook-semiconductor-copper-kospi-causality.md) |
| 선행·밸류 하방 | Cross-ref | [korea-kospi-leading-indicator-causality.md](korea-kospi-leading-indicator-causality.md) |
| 스태그플레이션·유가 | Cross-ref | [korea-stagflation-risk-causality.md](korea-stagflation-risk-causality.md) |
| 부동산 양극화·관망 (채상욱 영상) | Real estate / graph | [chae-sangwook-housing-polarization-causality.md](chae-sangwook-housing-polarization-causality.md) |
| 가치·배당·장기 복리 (숙향 영상) | Equity / process | [sukhyang-value-dividend-longterm-investing-causality.md](sukhyang-value-dividend-longterm-investing-causality.md) |

---

## 관련 문서

- [국내 증시·선행지수·섹터 (김영익, 영상)](korea-kospi-leading-indicator-causality.md): **다른** 증시 **하방·방어** 인과.
- [반도체 수출·구리·코스피 (홍춘욱 영상)](hong-chunwook-semiconductor-copper-kospi-causality.md): 반도체·**실물·환율** 축.
- [한국 스태그플레이션 리스크 (영상)](korea-stagflation-risk-causality.md): **유가·성장·물가** 스트레스 축.
- [유가(Oil_Price) ↔ 물가 인과](oil-price-inflation-causality.md): 에너지·금리 **일반 틀**.
- [유가·에너지·물가 전망 (메모)](macro-energy-inflation-outlook.md): 거시 **허브**.
- [한국 주택·양극화·관망 (채상욱 영상)](chae-sangwook-housing-polarization-causality.md): **하이닉스권·현금 수요**·**전월세**·**가격대별** 부동산 인과.
- [가치·배당·장기 복리 (숙향 영상)](sukhyang-value-dividend-longterm-investing-causality.md): **월배당·재무 분석** 등 **다른** 장기 **현금흐름** 프레임.

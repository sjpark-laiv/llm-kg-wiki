---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: "영상 발화 요지 메모 기준"
---

# 반도체 수출·구리·코스피 (홍춘욱 박사 영상 인과, RCA·Impact)

**목적:** **홍춘욱** 박사 발화 중 **반도체 수출(외화 수급)**과 **구리(Dr. Copper)**가 **코스피·거시**에 미치는 **근거·인과**를 **RCA·Impact**용으로 구조화함. 상위 서사는 [글로벌 거시·부동산 일시 조정 후 반등 (홍춘욱)](hong-chunwook-macro-rebound-causality-video.md)와 **연결**해 읽는다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Semiconductor_Export_Korea`** | 반도체 금액 수출(지수) | **3월 수출**에서 전년 동기 대비 **약 40%** 성장 등 **기록적 성장** 서술 *(04:02)*. |
| **`Trade_Surplus_Structural`** | 무역 흑자(연간 규모) | 연간 **약 1,000억 불** 흑자 **견인** 언급 *(04:02)*. |
| **`Domestic_Demand_Weak`** | 내수 부진 | **건설·일반 소비** 등 **내수**는 좋지 않다는 전제 *(03:34)*. |
| **`FX_KRW_Resilience_Export_Backstop`** | 원화 방어(수출 외화) | 외국인 **수십 조 원** 주식 매도에도 **환율 1,500원대**에서 **폭주하지 않는** 이유로 **반도체 유입 외화**의 견고함을 듦 *(04:46)*. |
| **`Foreign_Equity_Outflow_Korea`** | 외국인 주식 순매도 | 환율 논의와 결합된 **자본 이탈** 압력 축. |
| **`AI_Cycle_Samsung_Earnings`** | AI 호황·삼성 이익 | 삼성전자 **영업이익 연간 200조 원**에 **육박** 가능성 제기 *(09:49)*. |
| **`KOSPI_Upside_Narrative_6_7k`** | 코스피 상향 시나리오 | **6,000~7,000**선 **상향 가능** 동력 서술 *(09:49)* (영상 **가능성** 언급). |
| **`Copper_Price_Dr_Copper`** | 구리 가격 (Dr. Copper) | **제조·건설** 수요의 **선행 지표**로 소개 *(10:25)*. |
| **`Copper_Adjustment_Q1`** | 구리 단기 조정 | **2~3월** 일시 조정 언급 *(10:25)*. |
| **`Global_RealEconomy_Demand`** | 실물 수요(제조·건설) | 구리 회복이 **살아난다는 증거**로 연결 *(09:49)*. |
| **`Semiconductor_Capex_SupplyGlut_Risk`** | 반도체 투자·공급 과잉 | 투자 **과잉** 시 **구리 등** 원자재로 **실수요**를 모니터링해야 한다는 주장 *(10:17)*. |
| **`Geopol_Freight_Oil_Noise`** | 중동·운임·유가 불확실성 | **호르무즈** 등 불안으로 **구리가 힘을 못 쓰는** 배경 *(10:35)*. |
| **`Rally_Timing_Copper_inflection`** | 랠리 타이밍(구리 반전) | 구리가 **돌아서는 시점**이 **본격 증시 랠리 시작점**이라는 전망 *(10:35)*. |
| **`Samsung_Margin_Semi_Export_Proxy`** | 삼성 마진·반도체 수출(대응 지표) | **하방 경직성** 확인용 지표로 제시 *(10:56)*. |
| **`Hong_ChunWook`** | 홍춘욱 (발화자) | Person. |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 인과 기제 | 세부 | 태그 |
|------|------------|------|------|
| **외화·펀더멘털** | 반도체 수출 → 흑자 | **무역 흑자** 견인·**기초 체력** | `RCA`+`Impact` |
| **내수 상쇄** | 내수 약 → 수출 강 | **달러 유입**이 **펀더멘털** 지탱 | `Impact` |
| **환율** | 주식 매도 vs 수출 외화 | **외화 수급 견고** → **환율 폭주 억제** 서사 | `RCA`+`Impact` |
| **코스피 상방** | AI·삼성 이익 | **지수 상향** 동력 서술 | `Impact` |
| **실물 확인** | 구리 회복 | **전고 돌파**의 **필수 조건**으로 규정 *(09:49)* | `RCA`+`Impact` |
| **과잉 투자** | 반도체 캐펙스 | **구리 등**으로 **실수요** 점검 | `Evidence` |
| **지정학** | 유가·운임 | 구리 **약세/횡보** 배경 → 이후 **반전**이 랠리 트리거 | `Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Semiconductor_Export_Korea` | `drives` | `Trade_Surplus_Structural` | `export_boom` |
| `Semiconductor_Export_Korea` | `offsets` | `Domestic_Demand_Weak` | `external_balance` |
| `Semiconductor_Export_Korea` | `supports` | `FX_KRW_Resilience_Export_Backstop` | `fx_inflows` |
| `Foreign_Equity_Outflow_Korea` | `pressure_on` | `FX_KRW_Resilience_Export_Backstop` | `capital_outflow` |
| `Semiconductor_Export_Korea` | `mitigates` | `Foreign_Equity_Outflow_Korea` | `net_fx_effect` |
| `AI_Cycle_Samsung_Earnings` | `feeds` | `KOSPI_Upside_Narrative_6_7k` | `earnings_revision` |
| `Copper_Price_Dr_Copper` | `signals` | `Global_RealEconomy_Demand` | `dr_copper` |
| `Global_RealEconomy_Demand` | `required_for` | `KOSPI_Upside_Narrative_6_7k` | `breakout_condition` |
| `Semiconductor_Capex_SupplyGlut_Risk` | `monitored_via` | `Copper_Price_Dr_Copper` | `commodity_demand_check` |
| `Geopol_Freight_Oil_Noise` | `suppresses` | `Copper_Price_Dr_Copper` | `risk_off_commodity` |
| `Copper_Price_Dr_Copper` | `inflection_triggers` | `Rally_Timing_Copper_inflection` | `rally_start` |
| `Samsung_Margin_Semi_Export_Proxy` | `confirms` | `FX_KRW_Resilience_Export_Backstop` | `downside_rigidity` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`)

- **외환 위기 가능성 낮음(발화):** **“반도체가 벌어다 주는 돈(외화 수급)”** 덕분에 **한국이 외환 위기를 겪을 가능성은 낮다**는 **단정형 주장** *(요약)*.
- **환율이 크게 안 튀는 이유(서술):** **외국인 주식 대규모 매도**에도 **1,500원대**에서 **폭주하지 않는** 배경으로 **반도체 수출 유입 외화**를 듦 *(04:46)*.
- **내수 부진의 상쇄:** 내수가 약해도 **반도체 달러**가 **펀더멘털**을 받친다는 구조 *(03:34)*.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`)

- **코스피:** **AI·삼성 이익** 시나리오가 **6,000~7,000** 상향 **동력**으로 제시되나, **본격 상승**에는 **구리 회복**(실물 뒷받침)이 **필수**라는 **조건부** 서술 *(09:49)*.
- **투자 대응(발화):** **삼성 마진율·반도체 수출액**으로 **하방 경직성** 확인, **구리 추이**로 **본격 진입 시점**을 정한다는 **2축 전략** *(10:56)*.
- **공급 과잉 모니터:** 반도체 **투자 과열** 시 **구리 등** 원자재로 **실수요**를 보라는 점검 루틴 *(10:17)*.
- **지정학:** **중동·호르무즈·운임·유가** 불안으로 구리가 **당분간 약**할 수 있으나, **지표 반전**이 **랠리 시작점**이라는 **시나리오** *(10:35)*. (지정학 맥락: [한국 스태그플레이션 리스크](korea-stagflation-risk-causality.md)의 `Geo_Risk_MiddleEast`와 **참고용** 병행.)

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF Semiconductor_Export_Korea strong THEN supports Trade_Surplus_Structural AND FX_KRW_Resilience_Export_Backstop END
IF Domestic_Demand_Weak THEN still offset_by Semiconductor_Export_Korea (fundamental backstop narrative) END
IF Foreign_Equity_Outflow_Korea large THEN Semiconductor_Export_Korea mitigates FX shock END
IF AI_Cycle_Samsung_Earnings upgrades THEN KOSPI_Upside_Narrative_6_7k narrative_strengthens END
IF NOT (Copper_Price_Dr_Copper recovery) THEN KOSPI_Upside_Narrative_6_7k breakout_vs_prior_high blocked (Hong necessary condition) END
MONITOR Semiconductor_Capex_SupplyGlut_Risk WITH Copper_Price_Dr_Copper
STRATEGY: watch Samsung_Margin_Semi_Export_Proxy AND Copper_Price_Dr_Copper for timing
```

```mermaid
flowchart LR
  SE[Semiconductor_Export_Korea] --> TS[Trade_Surplus_Structural]
  SE --> FX[FX_KRW_Resilience_Export_Backstop]
  D[Domestic_Demand_Weak] -.->|offset| SE
  FO[Foreign_Equity_Outflow_Korea] --> FX
  SE --> FX
  AI[AI_Cycle_Samsung_Earnings] --> K[KOSPI_Upside_Narrative_6_7k]
  CP[Copper_Price_Dr_Copper] --> G[Global_RealEconomy_Demand]
  G --> K
  GEO[Geopol_Freight_Oil_Noise] --> CP
```

---

<a id="evidence-data"></a>

## 6. Evidence — 타임스탬프(메모)

| 시각 | 주제 |
|------|------|
| 03:34 | 내수 부진 vs 반도체 달러·펀더멘털 |
| 04:02 | 3월 수출 반도체 YoY ~40%, 연간 흑자 ~1,000억 불 |
| 04:46 | 외국인 대규모 매도에도 환율 1,500대, 반도체 외화 수급 |
| 09:49 | 구리 회복=전고 돌파 필수조건, 삼성 이익·코스피 6~7천 동력 |
| 10:17 | 반도체 과투자·공급 과잉 점검에 구리 등 실수요 |
| 10:25 | Dr. Copper, 2~3월 구리 조정 |
| 10:35 | 중동·운임·유가 불안 vs 구리 반전=랠리 시작 |
| 10:56 | 삼성 마진·수출(하방), 구리(진입 시점) 대응 |

---

<a id="summary"></a>

## 7. 결론(메타)

영상 요지는 **반도체 수출=외화·펀더멘털의 버팀목**으로 **외환·환율 리스크를 낮게 본다**는 쪽과, **코스피 본격 상승**에는 **구리가 말해주는 실물 회복**이 **필요**하다는 **조건부 증시론**으로 **양분**된다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| Hong_ChunWook | Person | 이 문서, [홍춘욱 거시·부동산 인과](hong-chunwook-macro-rebound-causality-video.md) |
| 반도체 수출, 구리, 코스피 | Macro / market | 이 문서 |
| 호르무즈·지정학 | Risk | [korea-stagflation-risk-causality.md](korea-stagflation-risk-causality.md) |
| 순대외금융자산·공공 해외운용 | Macro / balance sheet | [hong-chunwook-net-foreign-assets-fx-defense-causality.md](hong-chunwook-net-foreign-assets-fx-defense-causality.md) |
| 미국 ODM·AI·HBM (채상욱 영상) | Macro / equity | [chae-sangwook-korea-us-odm-ai-kospi-causality.md](chae-sangwook-korea-us-odm-ai-kospi-causality.md) |
| 주택 양극화·하이닉스 수요 (채상욱 영상) | Real estate / graph | [chae-sangwook-housing-polarization-causality.md](chae-sangwook-housing-polarization-causality.md) |
| 코스피 강세·VIX·AI·ETF·안전자산 (홍춘욱 영상) | Macro / equity | [hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md) |

---

## 관련 문서

- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): 상위 **거시·부동산** 서사.
- [국내 증시·선행지수·섹터 (김영익 영상)](korea-kospi-leading-indicator-causality.md): **선행 지수·밸류** 중심의 **다른 증시** 인과.
- [유가(Oil_Price) ↔ 물가 인과](oil-price-inflation-causality.md): 유가·**실물** 전달 일반 틀.
- [유가·에너지·물가 전망 (메모)](macro-energy-inflation-outlook.md): 거시 **허브**.
- [순대외금융자산·환율 해석 (홍춘욱 영상)](hong-chunwook-net-foreign-assets-fx-defense-causality.md): **순·총 대외자산**·**공공 해외 AUM**·**디폴트 vs 외환위기** 구분·**외국인 매도 vs 환율** 반증.
- [한국 증시·미국 제조 ODM·AI (채상욱 영상)](chae-sangwook-korea-us-odm-ai-kospi-causality.md): **HBM·AI 인프라**·**PBR→PER** 등 **반도체·밸류** **낙관** 서사.
- [한국 주택·양극화·관망 (채상욱 영상)](chae-sangwook-housing-polarization-causality.md): **하이닉스 인센티브·셔틀권** **주택 수요**.
- [코스피 강세·VIX·구리·AI·안전자산 (홍춘욱 영상)](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md): **VIX·숏커버**·**구리→반도체 수익**·**GPU→HBM**·**코스피200 ETF·달러·금**.

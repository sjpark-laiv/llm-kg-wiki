---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: "영상 발화 요지 메모 기준"
---

# 글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 박사 영상 인과, RCA·Impact)

**목적:** 영상 **「'S&P500 사모을 때 아니다' 1억 제발 이렇게 하세요. 10억 금방인데 왜 안하죠? \| 홍춘욱 박사」**에서 제시한 **근거·인과**를 **RCA·Impact** 추론용으로 구조화함. 핵심 국면: **일시적 불황·조정 후 반등**, **시스템 붕괴형 대공황 가능성은 낮다**는 진단. 본문은 **영상 주장의 재구성**.

**대비 서사:** 스태그플레이션·유가·환율 강조 서술은 [한국 스태그플레이션 리스크 (영상)](korea-stagflation-risk-causality.md), **주택 정책 하방** 서술은 [이현철 영상 인과](korea-housing-policy-bear-causality-lee-video.md)와 **대비·병행**해 읽을 것.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Rates_Higher_Longer_Risk`** | 고금리 지속 리스크 | 금리가 **기대보다 빨리 내려가지 않을** 때의 금융·기업 부담. |
| **`BigTech_BalanceSheet_Stress`** | 빅테크·금융 스트레스 | **8대 빅테크** 중 **한 곳** 무너짐 가능성 등 **자산시장 충격** 서술. |
| **`PrivateDebt_SAMO_Leverage`** | 사모·레버리지 | **변동 금리 레버리지** 사모펀드(프라이빗 디트) **부실화** 가능성. |
| **`AssetMarket_Shock_Temporary`** | 자산시장 일시 충격 | 위 요인으로 **단기 조정·진통** 가능하나 **영상은 ‘시스템 붕괴’와 구분**. |
| **`FX_KRW_Stress_Scenario`** | 원화 약세 시나리오 | 예: **원/달러 1,600원** 가정 등 **환율 급등** 서술. |
| **`Oil_Price_Pressure`** | 유가 상방 압력 | `Oil_Price` 축 — [유가-물가 인과](oil-price-inflation-causality.md#entities)와 연결. |
| **`Domestic_CPI_Path_High`** | 국내 물가 경로 | 환율·유가가 **시차**를 두고 **CPI 4~5%**까지 끌어올릴 **위험** 언급. |
| **`BOK_Rate_Hike_To_Curb_CPI`** | 한은 금리 인상(물가 대응) | 환율·유가 **동반** 상승 시 **물가 잡기 위해 금리 인상** 불가피 서술. |
| **`Temporary_Growth_Slowdown`** | 일시적 경기 위축 | 긴축 대응으로 **단기 위축** 가능. |
| **`Seoul_Apt_Supply_Cliff`** | 서울 아파트 공급 절벽 | **입주 물량**이 **지난 10년보다 감소** 서술. |
| **`NewTown_Third_Phase_Lag`** | 3기 신도시 등 공급 시차 | **추가 공급까지 시간** 소요. |
| **`Semiconductor_AI_Upcycle`** | 반도체·AI 호황 | **부동산 하방 지지** 논리의 수요·소득 축. |
| **`Korea_RE_Long_Term_Up_Thesis`** | 부동산 장기 우상향 전제 | **공급 부족 + 반도체 사이클** → 외부 충격 **일시 조정** 후 **우상향** 서술. |
| **`Crisis_Not_Like_2008_Thesis`** | 2008과 질적 비교 | **GDP 대비 손실 규모** 등으로 **관리 가능**·대공황 **낮음** 진단. |
| **`Five_Way_Portfolio_Split`** | 투자 5분법 | 한국 주식·미국 주식·금·**미국 국채** 등 **기존 배분** 프레임(영상). |
| **`CD_ETF_Cash_Buffer_20pct`** | CD ETF 20% | **양당예금증서(CD) ETF**를 **20%** 추가해 **현금성** 확보. |
| **`Rebalance_Dry_Powder_MDD`** | 리밸런싱·MDD | 폭락 시 **저가 매수 재원**, **MDD(최대 낙폭)** 완화 목적. |
| **`Hong_ChunWook`** | 홍춘욱 (발화자) | Person. |
| **`Thesis_Temporary_Dip_Then_Rebound`** | 일시 불황·조정 후 반등 | 영상의 **상위 전망 라벨**. |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 인과 기제 | 세부 | 태그 |
|------|------------|------|------|
| **금융 스트레스** | 비용 부담·레버리지 | 고금리 지속 → 빅테크/사모 **부실·충격** | `RCA`+`Impact` |
| **물가·통화** | 환율+유가 → CPI | 시차 후 **4~5%** 위험 → **한은 인상** → **일시 위축** | `RCA`+`Impact` |
| **부동산 장기** | 공급+호황 | **공급 절벽**·신도시 **시차** + **AI/반도체** → **하방 지지**·**조정 후 반등** | `Impact` |
| **시스템 위기** | 2008 대비 | **규모·질** 다르다 → **대공황 가능성 낮음** | `Evidence` |
| **포트폴리오** | 현금 버퍼 | **5분법 + CD ETF 20%** → **리밸런싱**·**MDD** 관리 | `Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Rates_Higher_Longer_Risk` | `stresses` | `PrivateDebt_SAMO_Leverage` | `leverage_default` |
| `Rates_Higher_Longer_Risk` | `stresses` | `BigTech_BalanceSheet_Stress` | `mag7_tail` |
| `PrivateDebt_SAMO_Leverage` | `may_trigger` | `AssetMarket_Shock_Temporary` | `pe_shock` |
| `BigTech_BalanceSheet_Stress` | `may_trigger` | `AssetMarket_Shock_Temporary` | `equity_shock` |
| `FX_KRW_Stress_Scenario` | `combines_with` | `Oil_Price_Pressure` | `import_inflation` |
| `FX_KRW_Stress_Scenario` | `feeds_with_lag` | `Domestic_CPI_Path_High` | `cpi_channel` |
| `Oil_Price_Pressure` | `feeds_with_lag` | `Domestic_CPI_Path_High` | `cpi_channel` |
| `Domestic_CPI_Path_High` | `may_force` | `BOK_Rate_Hike_To_Curb_CPI` | `monetary_response` |
| `BOK_Rate_Hike_To_Curb_CPI` | `implies` | `Temporary_Growth_Slowdown` | `short_slowdown` |
| `Seoul_Apt_Supply_Cliff` | `supports` | `Korea_RE_Long_Term_Up_Thesis` | `supply_floor` |
| `NewTown_Third_Phase_Lag` | `extends` | `Seoul_Apt_Supply_Cliff` | `supply_lag` |
| `Semiconductor_AI_Upcycle` | `supports` | `Korea_RE_Long_Term_Up_Thesis` | `income_demand` |
| `AssetMarket_Shock_Temporary` | `does_not_equal` | `Crisis_Not_Like_2008_Thesis` | `severity_compare` |
| `CD_ETF_Cash_Buffer_20pct` | `enables` | `Rebalance_Dry_Powder_MDD` | `buffer_rebalance` |
| `Five_Way_Portfolio_Split` | `extends_with` | `CD_ETF_Cash_Buffer_20pct` | `five_plus_cd` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`)

- **일시 충격의 근원:** **고금리**가 예상보다 길면 **레버리지 사모**·**자금력 약화 빅테크** 등에서 **파산·부실**이 터져 **자산시장 일시 충격** 가능 *(02:47)*, *(05:35)*.
- **물가·금리 딜레마의 근원:** **환율 급등**(예: 1,600원 시나리오) + **유가**가 **시차**로 **`Price_Level`(CPI)**를 끌어올릴 수 있음 *(12:43)* → **한은**이 물가를 위해 **금리 인상** 쪽으로 기울 수 있다는 **인과** *(12:53)*.
- **부동산 ‘반등’ 서사의 근원:** **서울 입주 절벽**·**3기 신도시 시차** = **공급 부족**; **AI/반도체 호황** = **수요·소득** — 외부 충격은 **조정**으로 가지만 **장기 우상향** 요인이 남는다는 구조 *(11:54)*, *(13:30)*.
- **대공황 낮음의 근원:** 사모·중소은행 우려와 **2008**을 **GDP 대비 손실 규모** 등으로 **질적 비교** → **관리 가능**·시스템 붕괴 **가능성 낮음** *(04:29)*.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`)

- **자산가격:** 단기 **조정·변동성** 확대 가능하나, 영상은 **‘대공황’**과 **선**을 긋고 **일시적 진통**으로 수렴.
- **실물·물가:** CPI **4~5%** 구간 위험 + **한은 긴축** → **일시적 경기 위축** 경로.
- **부동산:** **공급·산업 호황**이 **가격 하방**을 받쳐 **조정 후 재상승** 서사.
- **투자자 행동:** **투자 5분법**에 **CD ETF 20%**를 얹어 **현금성**을 확보, 폭락 시 **리밸런싱**으로 **MDD**를 줄이자는 **운용 규칙** *(09:14)*.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF Rates_Higher_Longer_Risk THEN stress PrivateDebt_SAMO_Leverage AND BigTech_BalanceSheet_Stress END
IF (stress materializes) THEN AssetMarket_Shock_Temporary possible END
IF FX_KRW_Stress_Scenario AND Oil_Price_Pressure THEN with_lag Domestic_CPI_Path_High rises END
IF Domestic_CPI_Path_High THEN BOK_Rate_Hike_To_Curb_CPI plausible -> Temporary_Growth_Slowdown END
IF Seoul_Apt_Supply_Cliff AND Semiconductor_AI_Upcycle THEN Korea_RE_Long_Term_Up_Thesis (post-shock rebound narrative) END
ASSERT Crisis_Not_Like_2008_Thesis (not same loss scale as 2008 narrative)
ALLOCATE Five_Way_Portfolio_Split PLUS CD_ETF_Cash_Buffer_20pct FOR Rebalance_Dry_Powder_MDD
```

```mermaid
flowchart TB
  R[Rates_Higher_Longer_Risk] --> P[PrivateDebt_SAMO_Leverage]
  R --> B[BigTech_BalanceSheet_Stress]
  P --> A[AssetMarket_Shock_Temporary]
  B --> A
  F[FX_KRW_Stress_Scenario] --> C[Domestic_CPI_Path_High]
  O[Oil_Price_Pressure] --> C
  C --> H[BOK_Rate_Hike_To_Curb_CPI]
  H --> T[Temporary_Growth_Slowdown]
  S[Seoul_Apt_Supply_Cliff] --> K[Korea_RE_Long_Term_Up_Thesis]
  M[Semiconductor_AI_Upcycle] --> K
  CD[CD_ETF_Cash_Buffer_20pct] --> RD[Rebalance_Dry_Powder_MDD]
```

---

<a id="evidence-data"></a>

## 6. Evidence — 영상 타임스탬프(메모)

| 시각 | 주제 |
|------|------|
| 02:47 | 빅테크·사모(변동금리 레버리지) 리스크 |
| 04:29 | 2008 금융위기와의 질적·규모 비교, 관리 가능 |
| 05:35 | 금리 미인하 시 레버리지·약자금 빅테크 → 시장 일시 충격 |
| 09:14 | 투자 5분법 + CD ETF 20%, 리밸런싱·MDD |
| 11:54 | 서울 아파트 입주 공급 감소(10년 대비) |
| 12:43 | 환율(1,600원 가정)·유가 → 물가 4~5% 시차 |
| 12:53 | 물가 대응 금리 인상 → 일시 경기 위축 |
| 13:30 | 공급 부족 + 반도체·AI → 부동산 조정 후 우상향 서사 |

---

<a id="summary"></a>

## 7. 결론(메타)

영상은 **전쟁·고물가로 인한 단기 진통**은 인정하되, **시스템 붕괴형 대공황**은 **가능성이 낮다**고 줄이고, **부동산·자산**은 **공급·산업 호황**을 근거로 **조정 후 반등** 국면을 그린다. **CD ETF 20%** 등 **현금·리밸런싱**으로 **변동성(MDD)**을 견디자는 **운용 결론**으로 수렴한다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| Hong_ChunWook | Person | 이 문서 |
| Oil_Price, Price_Level | Macro | [oil-price-inflation-causality.md](oil-price-inflation-causality.md) |
| 대비 서사 | Cross-ref | [korea-stagflation-risk-causality.md](korea-stagflation-risk-causality.md), [korea-housing-policy-bear-causality-lee-video.md](korea-housing-policy-bear-causality-lee-video.md) |
| 반도체·구리·코스피 | Cross-ref | [hong-chunwook-semiconductor-copper-kospi-causality.md](hong-chunwook-semiconductor-copper-kospi-causality.md) |
| 순대외금융자산·환율 방어 서사 | Cross-ref | [hong-chunwook-net-foreign-assets-fx-defense-causality.md](hong-chunwook-net-foreign-assets-fx-defense-causality.md) |
| 부동산 양극화·관망 (채상욱 영상) | Real estate / graph | [chae-sangwook-housing-polarization-causality.md](chae-sangwook-housing-polarization-causality.md) |
| 코스피 강세·VIX·AI·안전자산 (홍춘욱 영상) | Macro / equity | [hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md) |

---

## 관련 문서

- [유가(Oil_Price) ↔ 물가(Price_Level) 인과 구조](oil-price-inflation-causality.md): 유가·물가 전달.
- [한국 스태그플레이션 리스크 (영상)](korea-stagflation-risk-causality.md): **저성장·고물가** 강조 서술과 대비.
- [한국 주택·정책 하방 (이현철 영상)](korea-housing-policy-bear-causality-lee-video.md): **정책·하방** 강조 서술과 대비.
- [국내 증시·선행지수 (김영익 영상)](korea-kospi-leading-indicator-causality.md): 국내 주식·방어 배분 맥락.
- [유가·에너지·물가 전망 (메모)](macro-energy-inflation-outlook.md): 거시 **인과 클러스터** 허브.
- [반도체 수출·구리·코스피 (홍춘욱 영상)](hong-chunwook-semiconductor-copper-kospi-causality.md): **외화 수급·실물 확인**과 **증시 조건** 인과.
- [순대외금융자산·환율 해석 (홍춘욱 영상)](hong-chunwook-net-foreign-assets-fx-defense-causality.md): **대외자산 스케일**·**환율 RCA(지정학)**·**외환 위기** 서사 완화.
- [한국 주택·양극화·관망 (채상욱 영상)](chae-sangwook-housing-polarization-causality.md): **반도체 보너스·셔틀권**·**현금 수요** 부동산 인과.
- [코스피 강세·VIX·구리·AI·안전자산 (홍춘욱 영상)](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md): **강세 지속**·**지수 ETF**·**달러·금** 병행 인과.

---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
---

# 유가·에너지·물가 전망과 투자 시사점

중동 사태 등 지정학적 요인과 구조적 원가 상승을 전제로 한 **유가·에너지 안보·물가(인플레이션)·금리·환율** 논의, 그리고 **실물 경제·통화정책·포트폴리오** 시사점을 정리한 메모입니다. 괄호 안 시각 표기(예: 01:42)는 원본 발언·영상 기준 타임스탬프입니다.

---

<a id="oil-energy-outlook"></a>

## 1. 유가 및 에너지 가격 전망

- **저유가 시대의 종언**: 전쟁 이전 배럴당 약 60달러 수준이었던 유가가 중동 사태 등으로 약 **90달러 선**까지 상승했다는 진술이 제시됨 *(01:42)*.
- **구조적 원가**: 전쟁 종료 이후에도 **가스 시설 재건**, **통행료·보험료** 등으로 원가가 상승해 과거 수준의 저유가로 되돌아가기 어렵다는 전망 — **오건영** 단장 발언으로 정리됨 *(13:06)*.
- **에너지 안보**: 사태를 통해 에너지의 중요성이 재확인되었고, 포트폴리오에서 **IT 성장주**뿐 아니라 **에너지·레거시 자산**에 대한 분석·투자가 필요하다는 강조 *(47:32)*.

---

<a id="three-highs"></a>

## 2. 물가와 ‘3고(高)’ 현상

- **고물가·인플레이션 고착화**: 높은 유가는 **수입 물가**를 끌어올리는 요인으로 지적됨 *(03:27)*. 미국 소비자 물가가 **2021년부터** 목표치 **2%**를 상회한 상태가 장기화되면 인플레이션이 **‘고질병’**처럼 고착화될 위험이 있다는 경고 *(19:29)*.
- **3고의 악순환**: **고유가 → 고물가**이고, 물가를 잡기 위해 **고금리**를 유지해야 하며, 에너지 수입으로 **달러 지출**이 늘어 **고환율**이 이어지는 구조가 실물 경제를 압박한다는 설명 *(04:46)*.
- **인과 구조(분석용)**: 엔티티 **`Oil_Price` → `Price_Level`** 전달 기제·RCA·영향 체크리스트는 [유가-물가 인과 구조 (RCA·영향)](oil-price-inflation-causality.md)에 정리됨.

---

<a id="economic-impact"></a>

## 3. 경제적 영향 및 대응

- **K자형 양극화**: 고물가·고금리를 견딜 수 있는 **반도체·AI** 쪽은 호조, **자영업·전통 제조·원자재 의존** 업종은 더 어려워질 수 있다는 구조 *(05:23)*.
- **통화 정책의 제약**: **한국은행**은 성장을 위해 금리 인하를 원해도 **물가 안정**이 우선이라, 당시 유가·물가 압력 하에서는 **기준금리 인하 기대**가 어렵다는 논지 *(14:27)*.
- **한국 스태그플레이션 리스크(영상 인과):** 중동·**미 금리·관세**가 맞물릴 때 **한국 CPI·성장·환율**로 수렴하는 **인과·Evidence**는 [한국 스태그플레이션 리스크 (영상 근거)](korea-stagflation-risk-causality.md)에 정리됨.
- **한국 주택·정책 하방(영상 인과):** 투기시장·**정책 우위**·담합·급매 지표 해석은 [이현철 영상 근거 인과](korea-housing-policy-bear-causality-lee-video.md)에 정리됨.

---

<a id="investment-takeaways"></a>

## 요약 및 투자 시사점

- **분산 투자**: 변동성이 큰 장에서는 **자산별·지역별 분산**이 필수라는 시사점 *(48:17)*.
- **금(Gold)**: 지정학적 리스크가 상시화된 환경에서 금은 포트폴리오 **위험 분산(해지)** 수단으로 유효하다는 평가 *(44:40)*.
- **채권**: 금리 상승기에는 **장기 채권**보다 **만기가 짧은 채권**으로 금리 변동에 대응하는 편이 유리할 수 있다는 주의 *(33:14)*.
- **국내 증시·선행지수(영상 인과):** 선행 지수·코스피 밸류·**주식/채권 비중·섹터 전환** 논리는 [김영익 교수 영상 근거 인과](korea-kospi-leading-indicator-causality.md)에 정리됨.
- **글로벌 거시·부동산 반등 서사(영상 인과):** 홍춘욱 박사 **일시 조정 후 반등**·CD ETF·2008 비교 논리는 [홍춘욱 영상 근거 인과](hong-chunwook-macro-rebound-causality-video.md)에 정리됨.
- **반도체 외화·구리·코스피(영상 인과):** 수출 **외화 수급**·**구리 실물**·**증시 조건**은 [반도체 수출·구리·코스피 (홍춘욱)](hong-chunwook-semiconductor-copper-kospi-causality.md)에 정리됨.
- **순대외금융자산·환율(영상 인과):** **순·총 대외자산**·**공공 해외 AUM**·**환율 해석**·**외환 위기** 서사는 [순대외금융자산·환율 해석 (홍춘욱)](hong-chunwook-net-foreign-assets-fx-defense-causality.md)에 정리됨.
- **한국 증시·미국 ODM·AI(영상 인과):** **유가 선반영·금리 바닥** 등 **거시 바닥**과 **미·중·제조·연금** 서사는 [한국 증시·미국 제조 ODM·AI (채상욱)](chae-sangwook-korea-us-odm-ai-kospi-causality.md)에 정리됨.
- **한국 주택·양극화(영상 인과):** **하이닉스권·현금 수요·전월세·세제 관망**은 [한국 주택·양극화·관망 (채상욱)](chae-sangwook-housing-polarization-causality.md)에 정리됨.
- **코스피 강세·VIX·금·달러(영상 인과):** **숏커버·구리·AI→HBM**과 **코스피200 ETF·안전자산**은 [코스피 강세·VIX·구리·AI·안전자산 (홍춘욱)](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md)에 정리됨.
- **가치·배당·장기 복리(영상 인과):** **그레이엄식 재무·배당·분산·일기**는 [가치·배당·장기 복리 (숙향)](sukhyang-value-dividend-longterm-investing-causality.md)에 정리됨.
- **양도세 장특·부동산 세제(정책 메모):** **장특 폐지 논쟁**·**여야 프레임**은 [양도세 장특 폐지 논쟁](korea-cgt-longterm-holding-deduction-policy-debate.md)에 정리됨.

---

## 타임스탬프 색인 (원문 메모)

| 시각 | 대략 주제 |
|------|-----------|
| 01:42 | 전쟁 전후 유가 구간(약 60→90달러) |
| 03:27 | 유가와 수입 물가 |
| 04:46 | 3고(고유가·고물가·고금리·고환율) 악순환 |
| 05:23 | K자형 양극화 |
| 13:06 | 재건·통행료·보험료 등 구조적 원가, 저유가 복귀 어려움 |
| 14:27 | 한국은행, 물가 우선·금리 인하 제약 |
| 19:29 | 미국 CPI 2% 상회 지속 시 인플레 고착화 위험 |
| 33:14 | 단기 vs 장기 채권 |
| 44:40 | 금의 해지 역할 |
| 47:32 | 에너지·레거시 자산 분석 필요 |
| 48:17 | 분산 투자 |

---

## Named entity 링크 (문서 간)

| 개체 | 유형 | 연결 |
|------|------|------|
| 오건영 | Person | [§1 유가·에너지](#oil-energy-outlook) |
| 한국은행 | Organization | [§3 영향·대응](#economic-impact) |
| 3고(고유가·고물가·고금리·고환율) | Concept | [§2 물가·3고](#three-highs) |
| K자형 양극화 | Concept | [§3 영향·대응](#economic-impact) |
| 금(Gold) | Asset class | [투자 시사점](#investment-takeaways) |
| 미국 소비자 물가(CPI), 2% 목표 | Concept | [§2](#three-highs) |
| Oil_Price → Price_Level 인과 | Concept / graph | [oil-price-inflation-causality.md](oil-price-inflation-causality.md) |
| Stagflation_Risk_Korea (영상) | Scenario / graph | [korea-stagflation-risk-causality.md](korea-stagflation-risk-causality.md) |
| KOSPI·선행지수·섹터 (영상) | Equity / graph | [korea-kospi-leading-indicator-causality.md](korea-kospi-leading-indicator-causality.md) |
| 주택·정책 하방 (이현철 영상) | Real estate / graph | [korea-housing-policy-bear-causality-lee-video.md](korea-housing-policy-bear-causality-lee-video.md) |
| 글로벌 거시·반등 서사 (홍춘욱 영상) | Macro / graph | [hong-chunwook-macro-rebound-causality-video.md](hong-chunwook-macro-rebound-causality-video.md) |
| 반도체 수출·구리·코스피 (홍춘욱 영상) | Macro / equity | [hong-chunwook-semiconductor-copper-kospi-causality.md](hong-chunwook-semiconductor-copper-kospi-causality.md) |
| 순대외금융자산·환율 방어 (홍춘욱 영상) | Macro / NFA | [hong-chunwook-net-foreign-assets-fx-defense-causality.md](hong-chunwook-net-foreign-assets-fx-defense-causality.md) |
| 한국 증시·미국 ODM·AI (채상욱 영상) | Macro / equity | [chae-sangwook-korea-us-odm-ai-kospi-causality.md](chae-sangwook-korea-us-odm-ai-kospi-causality.md) |
| 한국 주택·양극화·관망 (채상욱 영상) | Real estate / graph | [chae-sangwook-housing-polarization-causality.md](chae-sangwook-housing-polarization-causality.md) |
| 코스피 강세·VIX·AI·안전자산 (홍춘욱 영상) | Macro / equity | [hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md) |
| 가치·배당·장기 복리 (숙향 영상) | Equity / process | [sukhyang-value-dividend-longterm-investing-causality.md](sukhyang-value-dividend-longterm-investing-causality.md) |
| 양도세 장특 폐지 논쟁 (정책 메모) | Policy / tax | [korea-cgt-longterm-holding-deduction-policy-debate.md](korea-cgt-longterm-holding-deduction-policy-debate.md) |

## 관련 문서 (인과·거시 클러스터)

- [유가(Oil_Price) ↔ 물가(Price_Level) 인과 구조](oil-price-inflation-causality.md): 전달 기제·엣지 표·`RCA`/`Impact`.
- [한국 스태그플레이션 리스크 (영상 근거)](korea-stagflation-risk-causality.md): 유가·미 정책·환율·한국 CPI·성장.
- [국내 증시·선행지수·섹터 로테이션 (김영익, 영상)](korea-kospi-leading-indicator-causality.md): 선행 지수·코스피 밸류·섹터·채권 비중.
- [한국 주택·정책 하방 논리 (이현철 영상)](korea-housing-policy-bear-causality-lee-video.md): 투기시장·정책 우위·담합·급매 지표 해석.
- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): 빅테크·사모·환율·유가·공급·CD ETF·2008 비교.
- [반도체 수출·구리·코스피 (홍춘욱 영상)](hong-chunwook-semiconductor-copper-kospi-causality.md): **외화 수급**·**실물(구리)**·**코스피 조건** 인과.
- [순대외금융자산·환율 해석 (홍춘욱 영상)](hong-chunwook-net-foreign-assets-fx-defense-causality.md): **대외자산**·**환율 RCA**·**위기 서사** 완화.
- [한국 증시·미국 제조 ODM·AI (채상욱 영상)](chae-sangwook-korea-us-odm-ai-kospi-causality.md): **유가·금리 바닥** 서사와 **증시 구조 낙관**.
- [한국 주택·양극화·관망 (채상욱 영상)](chae-sangwook-housing-polarization-causality.md): **주택 수요·공급·전월세** 인과.
- [코스피 강세·VIX·구리·AI·안전자산 (홍춘욱 영상)](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md): **금·달러**·**증시 강세** 인과.
- [가치·배당·장기 복리 (숙향 영상)](sukhyang-value-dividend-longterm-investing-causality.md): **개별주 가치·배당·장기 보유** 프로세스.
- [양도세 장특 폐지 논쟁 (정책 메모)](korea-cgt-longterm-holding-deduction-policy-debate.md): **부동산 양도세·장특** 정책 논쟁.

이 주제는 현재 동일 `wiki/`의 보건·항노화 문서(`nmn.md`, `lifespan.md`)와 **엔티티 교차가 없어** 상호 링크를 두지 않았다.

---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
---

# 《노화의 종말》(Lifespan)

하버드 의과대학의 **데이비드 싱클레어(David Sinclair)** 교수가 집필한 **《노화의 종말》(Lifespan)**은 현대 의학과 생물학계에 엄청난 파장을 일으킨 책입니다. 이 책의 핵심 주장은 한 문장으로 요약됩니다.

> 노화는 자연스러운 현상이 아니라, 치료 가능한 ‘질병’이다.

---

## 1. 핵심 이론: 정보 이론(Information Theory of Aging)

싱클레어 교수는 노화의 근본 원인을 **‘디지털 정보의 상실’**로 정의합니다.

- **비유**: 우리 몸의 유전 정보(DNA)가 디지털 정보라면, 이를 발현시키는 후성유전체(Epigenome)는 아날로그 판독기입니다.
- **메커니즘**: 시간이 흐르면서 세포가 손상과 복구를 반복하다 보면, 이 판독기에 ‘잡음(Noise)’이 생깁니다. 결국 세포가 자신의 본래 기능을 잊어버리게 되는 것이 바로 노화라는 설명입니다.

---

<a id="sirtuins"></a>

## 2. 노화의 조절자: 시르투인(Sirtuins)

우리 몸에는 노화와 수명을 조절하는 **‘장수 유전자’**가 있는데, 그중 핵심이 **시르투인(Sirtuins)** 단백질입니다.

- 시르투인은 평소에 세포를 복구하고 DNA를 보호하는 역할을 합니다.
- 세포에 스트레스가 가해지면 시르투인이 활성화되어 생존 모드로 전환됩니다. 싱클레어는 이를 인위적으로 자극함으로써 노화를 늦출 수 있다고 주장합니다.

**연결:** [NMN](nmn.md) · [NR](nr.md) 문서에서 시르투인 활성화와 NAD+ 보충 맥락을 다룹니다.

---

## 3. 젊음을 유지하기 위한 생존 회로 자극법

책에서는 시르투인을 활성화하여 몸을 ‘생존 모드’로 만드는 구체적인 방법들을 제시합니다.

- **적게 먹기(소식)**: 단순히 칼로리를 줄이는 것이 아니라, ‘허기’를 느끼게 하여 세포의 방어 기제를 깨우는 것이 핵심입니다. 간헐적 단식이 대표적입니다.
- **간헐적 단백질 제한**: 육류 섭취를 줄이고 식물성 단백질 위주로 섭취하여 **mTOR** 경로를 조절합니다.
- **운동**: 숨이 찰 정도의 고강도 운동은 세포에 유익한 스트레스(Hormesis)를 줍니다.
- **온도 노출**: 몸을 아주 차갑거나(냉수 마찰) 뜨거운(사우나) 환경에 노출시키는 것도 도움이 됩니다.

---

<a id="longevity-supplements"></a>

## 4. 노화 방지 물질(영양제)

싱클레어 교수가 직접 복용한다고 밝혀 유명해진 성분들입니다.

- **[NMN](nmn.md) / [NR](nr.md)**: 시르투인의 연료가 되는 **NAD+** 수치를 높여줍니다. (NR은 NMN과 유사하게 NAD+ 전구체로 논의되며, NR 단독 정리는 [nr.md](nr.md)를 참고.)
- **복합 제형 참고**: 시판에서는 [커피 베리 추출물](coffee-fruit-extract.md)(**BDNF**·항산화)과 NMN/NR(**NAD+**)을 함께 배합하는 구성이 소개되기도 합니다.
- **레스베라트롤(Resveratrol)**: 적포도주에 들어있는 성분으로, 시르투인을 직접 활성화하는 ‘가속 페달’ 역할을 합니다.
- **메트포르민(Metformin)**: 본래 당뇨병 치료제이지만, 세포 대사를 조절하여 노화를 억제하는 효과가 주목받고 있습니다.

---

## Named entity 링크 (문서 간)

| 개체 | 유형 | 연결 |
|------|------|------|
| David Sinclair, 데이비드 싱클레어 | Person | 이 문서(저자), [NMN § 싱클레어](nmn.md#sinclair) |
| 《노화의 종말》, Lifespan | Work | 이 문서 |
| Harvard Medical School, 하버드 의과대학 | Organization | 이 문서 서두 |
| NMN | Compound | [nmn.md](nmn.md) |
| NR (Nicotinamide Riboside) | Compound | [nr.md](nr.md), [nmn.md](nmn.md) |
| Coffee Fruit Extract | Supplement | [coffee-fruit-extract.md](coffee-fruit-extract.md) |
| NAD+ | Compound | [nmn.md](nmn.md) |
| 시르투인, Sirtuins | Protein family | 이 문서 [§2](#sirtuins), [nmn.md](nmn.md) |
| 레스베라트롤, Resveratrol | Compound | 이 문서 §4 |
| 메트포르민, Metformin | Drug | 이 문서 §4 |
| Epigenome, 후성유전체 | Concept | 이 문서 §1 |
| mTOR | Pathway | 이 문서 §3 |
| Information Theory of Aging | Theory | 이 문서 §1 |

---

## 관련 문서 (Named entity)

- [NMN (니코틴아미드 모노뉴클레오타이드)](nmn.md): NAD+ 전구체·싱클레어·복용 참고.
- [NR (Nicotinamide Riboside)](nr.md): NAD+ 전구체·NMN 비교·주의사항.
- [Coffee Fruit Extract](coffee-fruit-extract.md): BDNF·NR/NMN 복합 제형.

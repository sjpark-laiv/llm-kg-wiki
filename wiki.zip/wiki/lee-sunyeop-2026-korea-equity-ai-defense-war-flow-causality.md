---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(이선엽 대표, AI·방산·전쟁·수급 축)
---

# 2026 한국 증시·AI반도체·방산·전쟁·수급 (이선엽 대표 영상 요약, RCA·Impact)

**목적:** **이선엽** 대표 발화 요약에서 **AI·메모리 가격·실적 vs 주가**, **한국 방산의 글로벌 대안화**, **전쟁 리스크와 조정·산업 유발**, **외국인 매도(펀드 비중 규정) vs 장기 유입**을 **RCA·Impact**용으로 구조화한다. 다른 이선엽 메모: [AI·조선·금융·사모대출](lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md).

**발화자:** [이선엽 대표](entity/lee-sunyeop.md)

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) | 개체 문서 |
|-----------|-----------|---------------|-----------|
| **`Lee_SunYeop`** | 이선엽 대표 | Person. | [lee-sunyeop.md](entity/lee-sunyeop.md) |
| **`AI_Driven_Memory_Pricing_Surge_Korea`** | AI 수요·메모리 가격 급등(한국 공급사) | **삼성·SK하이닉스** 제품 **가격(고정가)** 이 **월 50%+** 급등 등 **천문학적 상승** 서술 *(18:09)*. | [ai-driven-memory-pricing-surge-korea.md](entity/ai-driven-memory-pricing-surge-korea.md) |
| **`Korea_Defense_Export_Global_Thesis`** | 한국 방산 글로벌 수출 논리 | **실전 성능·명중률·납기**와 **미 재고 부족·NATO 이슈**로 **유럽 등 수요 이동** 서술 *(22:32)*, *(24:00)*. | [korea-defense-export-global-thesis.md](entity/korea-defense-export-global-thesis.md) |
| **`War_Risk_Market_Correction_Recovery_Pattern`** | 전쟁 리스크·필수 조정·반등 패턴 | 전쟁이 **단기 불안**과 **산업 유발**, 본 분쟁은 **장기화 어려운 구조** 등 *(11:06)*, *(14:14)*, *(13:33)*. | [war-risk-market-correction-recovery-pattern.md](entity/war-risk-market-correction-recovery-pattern.md) |
| **`Foreign_Fund_Weight_Cap_Selling_Korea`** | 펀드 비중 상한에 따른 외국인 매도(한국) | **주가 상승→펀드 내 비중 초과→규정(예: 25%)** 에 따른 **자동 매도** 서술 *(28:10)*. | [foreign-fund-weight-cap-selling-korea.md](entity/foreign-fund-weight-cap-selling-korea.md) |
| **`Samsung_Electronics`** | 삼성전자 | **내년 글로벌 최대 이익 기업** 가능성 등 서술과 연결 *(19:29)*. | [samsung-electronics.md](entity/samsung-electronics.md) |
| **`SK_Hynix`** | SK하이닉스 | 메모리 **수혜** 축. | [sk-hynix.md](entity/sk-hynix.md) |
| **`Korea_Equity_Market`** | 한국 증시 | **구조적 강세** 총평과 연결 *(00:16)*. | [korea-equity-market.md](entity/korea-equity-market.md) |

---

<a id="causality-map"></a>

## 2. Causality map

| 경로 | 인과 기제 | 태그 |
|------|------------|------|
| **AI·메모리** | **수요 기하급수** vs **공급 부족** → **ASP 급등** → **실적 전망이 주가보다 빠름** | `RCA`+`Evidence` |
| **방산** | **실전 검증** + **미 공급 공백** + **NATO·주문 이동** → **한국 대안** | `Impact` |
| **전쟁** | **리스크 조정** = **필수 냉각**; 이후 **산업 수요** → **강한 반등** 서술 | `RCA` |
| **수급** | **비중 규정 매도**는 **노이즈**; **펀더멘털·환차익·업황** **장기 유입** | `Evidence` |

### 2.1 Edge 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `AI_Driven_Memory_Pricing_Surge_Korea` | `pulls` | `Earnings_Forecast_Outruns_Price` | `asp_to_eps_revision` |
| `Earnings_Forecast_Outruns_Price` | `supports` | `Korea_Equity_Market` | `valuation_gap_rally` |
| `Korea_Defense_Export_Global_Thesis` | `feeds` | `Korea_Equity_Market` | `defense_export_cycle` |
| `War_Risk_Market_Correction_Recovery_Pattern` | `temporarily_pressures_then` | `Korea_Equity_Market` | `risk_off_then_risk_on` |
| `Foreign_Fund_Weight_Cap_Selling_Korea` | `noise_vs` | `Long_Term_Foreign_Inflows_Korea` | `weight_rule_vs_fundamentals` |

> 노트: `Earnings_Forecast_Outruns_Price`, `Long_Term_Foreign_Inflows_Korea`는 **관계 문서 내부 요약 노드**.

---

<a id="evidence-data"></a>

## 3. Evidence 표

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| AI 동력 | 시장 강세 **핵심 동력**은 **AI** *(08:05)* |
| 미국 정책 | **AI·로봇 제조** 육성 *(08:05)* |
| 가격 | **월 50%+** 급등 등 **삼성·SK** 제품 *(18:09)* |
| 실적 vs 주가 | **실적 전망이 주가보다 빠름**, **저평가** *(19:29)* |
| 삼성 | **내년 세계 최대 이익 기업** 가능성 *(19:29)* |
| 방산 | **천궁** 등 **96%+ 명중** *(22:32)* |
| 수요 이동 | **미 재고 부족**, **NATO·유럽**이 **한국 주문** *(24:00)* |
| 전쟁·증시 | **역사적 패턴** *(11:06)* |
| 분쟁 구조 | **영토 분쟁 아님**, **미 90일** 등 **장기화 어려움** *(14:14)* |
| 조정 | **필수적 조정** 후 **강한 반등** *(13:33)* |
| 외국인 | **비중 규정(25% 등)** **자동 매도** *(28:10)* |
| 유입 | **장기 성향·환차익·반도체** **유입** *(27:19)* |
| 총평 | **가격 < 실적 전망** *(00:16)* |

---

<a id="related-graph"></a>

## 4. 관련 인과 (`wiki/rel/`)

- [AI·메모리 가격 급등 → 실적 전망이 주가보다 빠름 → 증시 상방](rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md)
- [실전·지정학 → 한국 방산 글로벌 수혜](rel/combat-proven-defense-to-korea-export-demand.md)
- [전쟁 리스크 → 필수 조정·이후 산업·반등](rel/war-risk-to-necessary-correction-and-rebound-korea-equity.md)
- [펀드 비중 규정 매도 vs 장기 유입·하방 경직](rel/foreign-fund-weight-cap-selling-to-flow-noise-and-inflows.md)

---

<a id="related-docs"></a>

## 5. 관련 문서

- [외국인 기계적 매도 (MSCI 맥락)](entity/foreign-investor-mechanical-selling.md) — **메커니즘(지수 vs 펀드 규정)** 이 다르므로 **출처 구분**.
- [한국 주식시장](entity/korea-equity-market.md) · [삼성전자](entity/samsung-electronics.md) · [SK하이닉스](entity/sk-hynix.md)

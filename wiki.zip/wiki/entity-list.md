---
wiki_created: 2026-04-19
wiki_updated: 2026-04-23
content_as_of: 영상 요약 메모 기준(강관우·김장열·이선엽·염승환 등)
content_as_of: 영상 요약 메모 기준(강관우·김장열·이선엽 등)
---

# Named entity 인덱스 (`wiki/entity/`)

**목적:** 영상·발화 요약에서 추출한 **개체(entity)** Markdown 파일을 **유형·파일 경로**로 정렬해 빠르게 찾을 수 있게 한다. 인과관계는 [`wiki/rel/`](rel/)을 본다.

**파일명 규칙:** 저장소 관례에 따라 `wiki/entity/`·`wiki/rel/` 파일명은 **영문 소문자·하이픈 슬러그**를 쓰고, 한글 **표시명은 각 파일 H1**에 둔다.

---

<a id="entity-table"></a>

## 엔티티 목록 (표시명 가나다·주제순)

| 표시명(한글) | 유형 | 파일 |
|-------------|------|------|
| AI 인프라 광범위 투자(GPU·메모리·DC·전력) | Capex / Concept | [entity/ai-infrastructure-capex-cycle.md](entity/ai-infrastructure-capex-cycle.md) |
| AI 패러다임(학습→추론) | Concept | [entity/ai-inference-paradigm-shift.md](entity/ai-inference-paradigm-shift.md) |
| AI 투자 특이점(성능·효율 스케일링) | Concept | [entity/ai-investment-performance-singularity.md](entity/ai-investment-performance-singularity.md) |
| AI 수요·한국 메모리 가격 급등(고정가) | Pricing / Concept | [entity/ai-driven-memory-pricing-surge-korea.md](entity/ai-driven-memory-pricing-surge-korea.md) |
| DRAM 마진(소프트웨어급 ~80%) | Sector / Concept | [entity/dram-margin-software-like-level.md](entity/dram-margin-software-like-level.md) |
| HBM(고대역폭 메모리) | Product | [entity/hbm-memory-product.md](entity/hbm-memory-product.md) |
| IMO 환경 규제·친환경 선박 교체 수요 | Regulation / Demand | [entity/imo-environmental-ship-replacement-demand.md](entity/imo-environmental-ship-replacement-demand.md) |
| KV 캐시 메모리 | Concept / Tech | [entity/kv-cache-memory.md](entity/kv-cache-memory.md) |
| 강관우 대표 | Person | [entity/kang-gwanwoo.md](entity/kang-gwanwoo.md) |
| 개인 투자자 집단지성·수급 | Investor group / Flow | [entity/retail-investor-collective-bid.md](entity/retail-investor-collective-bid.md) |
| 김장열 본부장 | Person | [entity/kim-jangyeol.md](entity/kim-jangyeol.md) |
| 글로벌 빅테크(애플·구글·메타 등) | Organization / Peer group | [entity/global-big-tech-peers.md](entity/global-big-tech-peers.md) |
| 국내 메모리 섹터 이익 전망 급상향 | Market expectation | [entity/korea-memory-sector-earnings-forecast-surge.md](entity/korea-memory-sector-earnings-forecast-surge.md) |
| 국내 소부장(소재·부품·장비) | Sector | [entity/korea-sme-parts-sector.md](entity/korea-sme-parts-sector.md) |
| 머니무브(예금→주식) | Flow / Concept | [entity/money-move-deposits-to-equities.md](entity/money-move-deposits-to-equities.md) |
| 메모리 반도체 이익(뉴 노멀) | Sector / Concept | [entity/memory-semiconductor-earnings-new-normal.md](entity/memory-semiconductor-earnings-new-normal.md) |
| 메모리 할인(밸류 프레임) | Valuation frame | [entity/memory-valuation-discount-frame.md](entity/memory-valuation-discount-frame.md) |
| 메모리 대형주 ROE·PER 괴리 | Valuation / Concept | [entity/memory-equity-high-roe-low-per.md](entity/memory-equity-high-roe-low-per.md) |
| 메모리 증설·가동 시차(2027) | Supply / Timeline | [entity/memory-fab-capacity-lag-2027.md](entity/memory-fab-capacity-lag-2027.md) |
| 마이크론 | Organization | [entity/micron.md](entity/micron.md) |
| 미국 10년 국채 금리(4.5%+ 스트레스) | Macro | [entity/us-treasury-10y-yield-stress-threshold.md](entity/us-treasury-10y-yield-stress-threshold.md) |
| 미국 선박 건조·수리 용량 부족 | Structural | [entity/us-marine-shipbuilding-capacity-constraint.md](entity/us-marine-shipbuilding-capacity-constraint.md) |
| 미국 주식시장 | Market | [entity/us-equity-market.md](entity/us-equity-market.md) |
| 미국 401k·퇴직연금 주식비중 상향(선행) | Precedent / Policy | [entity/us-401k-equity-shift-precedent.md](entity/us-401k-equity-shift-precedent.md) |
| MSCI 이머징 마켓 | Index / Benchmark | [entity/msci-emerging-markets.md](entity/msci-emerging-markets.md) |
| 범용 DDR5 DRAM | Product | [entity/ddr5-general-purpose-dram.md](entity/ddr5-general-purpose-dram.md) |
| 부동산→주식 자금 이동(한국) | Flow | [entity/capital-flow-real-estate-to-equities-korea.md](entity/capital-flow-real-estate-to-equities-korea.md) |
| 사모 대출(Private Credit) 담보 스트레스 | Credit / Risk | [entity/private-credit-collateral-stress.md](entity/private-credit-collateral-stress.md) |
| 삼성전자 | Organization | [entity/samsung-electronics.md](entity/samsung-electronics.md) |
| 삼성전자 파운드리 부문 | Division | [entity/samsung-foundry-division.md](entity/samsung-foundry-division.md) |
| 샌디스크 | Organization | [entity/sandisk.md](entity/sandisk.md) |
| SK하이닉스 | Organization | [entity/sk-hynix.md](entity/sk-hynix.md) |
| ROE(자기자본이익률) | Financial metric | [entity/roe.md](entity/roe.md) |
| TSMC | Organization | [entity/tsmc.md](entity/tsmc.md) |
| 일드 갭(주식-채권) | Macro / Valuation | [entity/yield-gap-equity-bond.md](entity/yield-gap-equity-bond.md) |
| 전쟁 리스크·증시 조정·반등 패턴 | Macro / Narrative | [entity/war-risk-market-correction-recovery-pattern.md](entity/war-risk-market-correction-recovery-pattern.md) |
| 펀드 비중 상한·외국인 매도(한국) | Flow / Rule | [entity/foreign-fund-weight-cap-selling-korea.md](entity/foreign-fund-weight-cap-selling-korea.md) |
| 외국인 기계적 매도(비중 조절) | Flow | [entity/foreign-investor-mechanical-selling.md](entity/foreign-investor-mechanical-selling.md) |
| 이익 컨센서스 상향 | Market expectation | [entity/earnings-consensus-upward-revision.md](entity/earnings-consensus-upward-revision.md) |
| 염승환 이사 | Person | [entity/yeom-seunghwan.md](entity/yeom-seunghwan.md) |
| 이선엽 대표 | Person | [entity/lee-sunyeop.md](entity/lee-sunyeop.md) |
| 데이터센터 전력용 선박 엔진 수요 | Demand / Infrastructure | [entity/marine-engine-for-datacenter-power.md](entity/marine-engine-for-datacenter-power.md) |
| 미국 군함 건조·MRO의 한국 아웃소싱 압력 | Defense / Shipbuilding | [entity/us-naval-shipbuilding-mro-outsourcing-korea.md](entity/us-naval-shipbuilding-mro-outsourcing-korea.md) |
| 조선 수주잔고·마진 정상화 | Sector / Earnings | [entity/shipbuilding-order-backlog-margin-normalization.md](entity/shipbuilding-order-backlog-margin-normalization.md) |
| 증권·자본시장 위상 상승(한국) | Sector / Structure | [entity/korea-securities-capital-markets-ascendance.md](entity/korea-securities-capital-markets-ascendance.md) |
| 지정학·중국 조선소 배제(미·중·안보) | Geopolitics | [entity/geopolitics-china-shipyard-exclusion.md](entity/geopolitics-china-shipyard-exclusion.md) |
| 한국 인구·국민연금 갭 | Demographics | [entity/korea-demographics-pension-gap.md](entity/korea-demographics-pension-gap.md) |
| 한국 조선업 구조적 재도약 | Sector thesis | [entity/korea-shipbuilding-structural-resurgence.md](entity/korea-shipbuilding-structural-resurgence.md) |
| 한국 방산 글로벌 수출 논리 | Sector / Geopolitics | [entity/korea-defense-export-global-thesis.md](entity/korea-defense-export-global-thesis.md) |
| 한국 주식시장 | Market | [entity/korea-equity-market.md](entity/korea-equity-market.md) |
| 퇴직·사적 연금 시장 확대(한국) | Market / Structure | [entity/korea-private-pension-market-growth.md](entity/korea-private-pension-market-growth.md) |
| 코스피 지수 | Index | [entity/kospi-index.md](entity/kospi-index.md) |
| PER·PBR 멀티플 | Valuation | [entity/valuation-multiples-per-pbr.md](entity/valuation-multiples-per-pbr.md) |
| 앤스로픽 (Anthropic) | Organization / AI | [entity/anthropic.md](entity/anthropic.md) |
| 미토스 (Mythos) AI 에이전트 | Product / AI Agent | [entity/mythos-ai-agent.md](entity/mythos-ai-agent.md) |
| 소프트캠프 (Softcamp, 258790) | Organization / Listed Company | [entity/softcamp.md](entity/softcamp.md) |
| 실드게이트 (SHIELD Gate) | Product / Security Solution | [entity/shieldgate.md](entity/shieldgate.md) |
| RBI (원격 브라우저 격리) | Concept / Technology | [entity/rbi-remote-browser-isolation.md](entity/rbi-remote-browser-isolation.md) |
| EDR (Endpoint Detection and Response) | Concept / Technology | [entity/edr-endpoint-security.md](entity/edr-endpoint-security.md) |
| OpenBSD | Product / OS | [entity/openbsd.md](entity/openbsd.md) |
| 망분리 규제 완화 (한국 금융권) | Concept / Policy | [entity/network-separation-deregulation-korea.md](entity/network-separation-deregulation-korea.md) |
| 금융감독원 (FSS) | Organization / Government | [entity/fss-korea.md](entity/fss-korea.md) |
| 과학기술정보통신부 (MSIT) | Organization / Government | [entity/msit-korea.md](entity/msit-korea.md) |
| 이충헌 (밸류파인더 대표) | Person | [entity/lee-chung-hun.md](entity/lee-chung-hun.md) |
| 밸류파인더 (ValueFinder) | Organization / Research | [entity/valuefinder-research.md](entity/valuefinder-research.md) |
| AI 에이전트 패러다임 (학습→추론→에이전트) | Concept / Technology | [entity/ai-agent-paradigm.md](entity/ai-agent-paradigm.md) |
| 오픈AI (OpenAI) | Organization / AI | [entity/openai.md](entity/openai.md) |
| 엔비디아 (NVIDIA) | Organization / Semiconductor | [entity/nvidia.md](entity/nvidia.md) |
| 인텔 (Intel) | Organization / Semiconductor | [entity/intel.md](entity/intel.md) |
| 클로드 (Claude) | Product / AI Model | [entity/claude-ai-model.md](entity/claude-ai-model.md) |
| 아마존 (Amazon) | Organization / Cloud·AI | [entity/amazon-aws.md](entity/amazon-aws.md) |

---

<a id="relations-index"></a>

## 관련 인과 엣지 (`wiki/rel/`)

| 원인(요약) | 결과(요약) | 파일 |
|------------|------------|------|
| AI·메모리 가격 급등 | 실적 전망 vs 주가·증시 | [rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md](rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md) |
| 실전·지정학(방산) | 한국 방산 수요 | [rel/combat-proven-defense-to-korea-export-demand.md](rel/combat-proven-defense-to-korea-export-demand.md) |
| 전쟁 리스크 | 필수 조정·반등 | [rel/war-risk-to-necessary-correction-and-rebound-korea-equity.md](rel/war-risk-to-necessary-correction-and-rebound-korea-equity.md) |
| 펀드 비중 규정 매도 | 노이즈 vs 장기 유입 | [rel/foreign-fund-weight-cap-selling-to-flow-noise-and-inflows.md](rel/foreign-fund-weight-cap-selling-to-flow-noise-and-inflows.md) |
| AI 특이점·인프라 CAPEX | 장기 섹터 우상향 서술 | [rel/ai-singularity-infra-to-productive-long-cycle-sectors.md](rel/ai-singularity-infra-to-productive-long-cycle-sectors.md) |
| 미 해운·IMO·지정학 | 한국 조선 재도약 | [rel/us-maritime-imo-geopolitics-to-korea-shipbuilding-resurgence.md](rel/us-maritime-imo-geopolitics-to-korea-shipbuilding-resurgence.md) |
| AI 전력 병목 | 선박 엔진·조선 이익 | [rel/ai-datacenter-power-gap-to-marine-engine-demand-in-shipbuilders.md](rel/ai-datacenter-power-gap-to-marine-engine-demand-in-shipbuilders.md) |
| 미 군함 인프라 제약·미중 경쟁 | 한국 조선 군함·MRO 발주 | [rel/us-naval-capacity-gap-to-korea-shipbuilding-mro-orders.md](rel/us-naval-capacity-gap-to-korea-shipbuilding-mro-orders.md) |
| 선박 공급 부족·인력 정상화 | 조선 실적·재평가 | [rel/ship-supply-shortage-and-labor-normalization-to-shipbuilder-earnings-rerating.md](rel/ship-supply-shortage-and-labor-normalization-to-shipbuilder-earnings-rerating.md) |
| 코스피 저PER | 8,500 상방 시나리오 | [rel/low-kospi-per-to-kospi-8500-upside-scenario.md](rel/low-kospi-per-to-kospi-8500-upside-scenario.md) |
| 악재 둔감화·실적 집중 | 코스피 하방 경직·우상향 | [rel/risk-noise-desensitization-to-fundamental-led-kospi-rally.md](rel/risk-noise-desensitization-to-fundamental-led-kospi-rally.md) |
| 인구·연금·401k·부동산→주식 | 증권·자본시장 재편 | [rel/korea-demographics-pension-flows-to-securities-industry-shift.md](rel/korea-demographics-pension-flows-to-securities-industry-shift.md) |
| 사모대출·고금리 | 단기 변동·낮은 체계적 전이 | [rel/private-credit-yields-to-near-term-volatility-low-crisis-transmission.md](rel/private-credit-yields-to-near-term-volatility-low-crisis-transmission.md) |
| 사모대출 조정 | 은행 중심 대출 재편 | [rel/private-credit-workout-to-bank-centric-loan-market.md](rel/private-credit-workout-to-bank-centric-loan-market.md) |
| DRAM 고마진·가격 | 이익 전망 급상향 | [rel/dram-margin-and-prices-to-earnings-forecast-surge.md](rel/dram-margin-and-prices-to-earnings-forecast-surge.md) |
| AI 추론 패러다임 | KV 캐시 수요 | [rel/ai-inference-paradigm-to-kv-cache-demand.md](rel/ai-inference-paradigm-to-kv-cache-demand.md) |
| 증설·가동 시차 | 2027까지 공급 부족 | [rel/memory-fab-lag-to-under-supply-through-2027.md](rel/memory-fab-lag-to-under-supply-through-2027.md) |
| KV·추론 부하 | DDR5 혼용·긴장 | [rel/kv-cache-inference-to-ddr5-mix-and-tightening.md](rel/kv-cache-inference-to-ddr5-mix-and-tightening.md) |
| 고ROE·저PER·사이클틀 | 성장 리레이팅 | [rel/high-roe-low-per-cycle-frame-to-growth-rerating.md](rel/high-roe-low-per-cycle-frame-to-growth-rerating.md) |
| 이익 전망 vs 주가 | 목표가·선호·리스크 | [rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md](rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md) |
| 삼성 파운드리 흑자·수주 | 시총 업사이드 | [rel/samsung-foundry-profit-orders-to-mcap-upside.md](rel/samsung-foundry-profit-orders-to-mcap-upside.md) |
| ROE 상승 | 멀티플 재평가 근거 | [rel/roe-to-valuation-multiples-per-pbr.md](rel/roe-to-valuation-multiples-per-pbr.md) |
| 메모리 이익 뉴 노멀 vs 구식 멀티플 | 주가 업사이드 | [rel/memory-earnings-new-normal-to-equity-valuation-upside.md](rel/memory-earnings-new-normal-to-equity-valuation-upside.md) |
| 외국인 기계적 매도 | 국내 수급·머니무브 | [rel/foreign-mechanical-selling-to-domestic-bid-strength.md](rel/foreign-mechanical-selling-to-domestic-bid-strength.md) |
| 한·미 일드 갭 차이 | 한국 상대 매력 | [rel/korea-yield-gap-to-relative-equity-attractiveness.md](rel/korea-yield-gap-to-relative-equity-attractiveness.md) |
| 이익 강화 vs 저평가 괴리 | 한국 비중 확대 논리 | [rel/earnings-valuation-gap-to-korea-overweight-thesis.md](rel/earnings-valuation-gap-to-korea-overweight-thesis.md) |
| 미토스(Mythos) 등장 | 기존 보안체계(EDR 등) 위기 | [rel/mythos-to-legacy-security-crisis.md](rel/mythos-to-legacy-security-crisis.md) |
| 미토스(Mythos) 등장 | 실드게이트(SHIELD Gate) 수요 급증 | [rel/mythos-to-shieldgate-demand.md](rel/mythos-to-shieldgate-demand.md) |
| 미토스(Mythos) 등장 | 금융당국(금감원·과기정통부) 규제 대응 | [rel/mythos-to-regulatory-response.md](rel/mythos-to-regulatory-response.md) |
| 실드게이트 RBI 기술 + 규제 적합성 | 금융·공공·민간 보안시장 확대 | [rel/shieldgate-rbi-to-security-market-expansion.md](rel/shieldgate-rbi-to-security-market-expansion.md) |
| 망분리 규제 완화 | 소프트캠프 실적 성장 (턴어라운드) | [rel/network-separation-deregulation-to-softcamp-growth.md](rel/network-separation-deregulation-to-softcamp-growth.md) |
| 빅테크 CAPEX 자사주→AI 전환 | 한국 반도체(삼성·하이닉스) 매출 직결 | [rel/bigtech-capex-to-korea-semiconductor-revenue.md](rel/bigtech-capex-to-korea-semiconductor-revenue.md) |
| AI 에이전트·CPU 수요 확대 | DDR5 범용 메모리 수요 폭증 | [rel/ai-agent-cpu-to-general-dram-demand.md](rel/ai-agent-cpu-to-general-dram-demand.md) |
| AI 기업 효용 체감 (클로드 등) | 한국 반도체 400조 실적 확신 | [rel/ai-enterprise-efficacy-to-korea-400t-earnings-conviction.md](rel/ai-enterprise-efficacy-to-korea-400t-earnings-conviction.md) |

---

<a id="topic-pages"></a>

## 주제 통합 문서 (`wiki/` 루트)

| 주제 | 파일 |
|------|------|
| 김장열 본부장 · 추론·DRAM·공급·밸류 (RCA·Impact) | [kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md](kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md) |
| 이선엽 대표 · 2026 증시·AI·조선·금융·사모대출 (RCA·Impact) | [lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md](lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md) |
| 이선엽 대표 · AI·방산·전쟁·수급·한국 증시 (RCA·Impact) | [lee-sunyeop-2026-korea-equity-ai-defense-war-flow-causality.md](lee-sunyeop-2026-korea-equity-ai-defense-war-flow-causality.md) |
| 염승환 이사 · 2026 코스피 8,500·조선 주도주 (RCA·Impact) | [yeom-seunghwan-2026-kospi-8500-shipbuilding-thesis-causality.md](yeom-seunghwan-2026-kospi-8500-shipbuilding-thesis-causality.md) |
| 이충헌·밸류파인더 · 소프트캠프·실드게이트 AI 보안 전망 (RCA·Impact) | [softcamp-shieldgate-ai-security-outlook.md](softcamp-shieldgate-ai-security-outlook.md) |
| 염승환 이사 · 코스피 '대운' AI·반도체 구조적 상승 (RCA·Impact) | [yeom-seunghwan-kospi-great-fortune-ai-semiconductor-causality.md](yeom-seunghwan-kospi-great-fortune-ai-semiconductor-causality.md) |

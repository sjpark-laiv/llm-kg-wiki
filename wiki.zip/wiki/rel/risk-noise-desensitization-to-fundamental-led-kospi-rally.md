---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 인과: 전쟁·금리 악재 둔감화 → 실적 중심 장세 전환 → 코스피 하방 경직·우상향

**목적:** 동일한 외부 악재에 대한 시장 반응이 약해지는 구간에서 실적 중심 장세로 전환되는 메커니즘을 정리한다.

**관련 개체:** [코스피 지수](../entity/kospi-index.md) · [한국 주식시장](../entity/korea-equity-market.md) · [전쟁 리스크·증시 조정·반등 패턴](../entity/war-risk-market-correction-recovery-pattern.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`War_Risk_Market_Correction_Recovery_Pattern`** | 전쟁 리스크 패턴 | [war-risk-market-correction-recovery-pattern.md](../entity/war-risk-market-correction-recovery-pattern.md) |
| **`Korea_Equity_Market`** | 한국 증시 | [korea-equity-market.md](../entity/korea-equity-market.md) |
| **`KOSPI_Index`** | 코스피 지수 | [kospi-index.md](../entity/kospi-index.md) |
| **`Corporate_Earnings_Outlook`** | 실적 중심 장세 | [earnings-consensus-upward-revision.md](../entity/earnings-consensus-upward-revision.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **악재 반응 약화:** 전쟁 이슈에 대한 가격 민감도가 시간이 지나며 낮아졌다는 관찰 *(09:44)*.
- **초점 이동:** 거시 뉴스보다 기업 실적·펀더멘털로 시장 해석 축이 이동했다는 주장 *(09:07)*.

---

<a id="impact"></a>

## 3. 결과·영향

- **하방 경직:** 동일 악재 반복 시 낙폭이 축소되는 구조.
- **랠리 지속:** 실적 모멘텀이 유지될 경우 지수 우상향이 이어질 수 있다는 시나리오.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 | 분석 태그 |
|------|------|-----------|
| 뉴스 피로 누적 | 반복 악재의 충격 흡수 | `RCA` |
| 펀더멘털 회귀 | 실적 변수의 가격 결정력 상승 | `Impact` |
| 하방 완충 | 매도 압력 둔화로 지수 탄성 강화 | `Evidence` |

---

<a id="causality-map"></a>

## 5. Causality map (엣지 표)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `War_Risk_Market_Correction_Recovery_Pattern` | `loses_marginal_shock_power_on` | `Korea_Equity_Market` | `risk_desensitization` |
| `Corporate_Earnings_Outlook` | `dominates_pricing_for` | `Korea_Equity_Market` | `fundamental_focus` |
| `Korea_Equity_Market` | `stabilizes_and_supports` | `KOSPI_Index` | `downside_rigidity` |

---

<a id="logic-framework"></a>

## 6. 논리 프레임워크

```text
IF repeated macro risks are priced in
THEN incremental downside from same news declines.
IF Corporate_Earnings_Outlook remains constructive
THEN Korea_Equity_Market pricing shifts to fundamentals.
IF pricing shifts to fundamentals
THEN KOSPI_Index downside is sticky and trend can remain up.
```

---

<a id="evidence-data"></a>

## 7. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 반응 변화 | 전쟁 뉴스 반복에도 시장 충격 둔화 | *(09:44)* |
| 장세 전환 | 실적 중심 해석으로 이동 | *(09:07)* |

---

<a id="backlinks"></a>

## 8. 역링크

- [염승환 이사](../entity/yeom-seunghwan.md)
- [주제 통합: 염승환 2026 코스피·조선](../yeom-seunghwan-2026-kospi-8500-shipbuilding-thesis-causality.md)

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: DRAM 고마진·가격 → 국내 메모리 이익 전망 급상향

**목적:** **DRAM 마진**이 **과거와 다른 수준**에 오르고 **가격**이 강세일 때, **시장 이익 전망**이 **단기간에 급격히 상향**된다는 주장을 구조화한다.

**관련 개체:** [DRAM 마진(소프트웨어급)](../entity/dram-margin-software-like-level.md) · [국내 메모리 이익 전망 급상향](../entity/korea-memory-sector-earnings-forecast-surge.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`DRAM_Margin_SoftwareLike`** | DRAM 고마진 | [dram-margin-software-like-level.md](../entity/dram-margin-software-like-level.md) |
| **`Korea_Memory_Earnings_Forecast_Surge`** | 이익 전망 급상향 | [korea-memory-sector-earnings-forecast-surge.md](../entity/korea-memory-sector-earnings-forecast-surge.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **마진 레짐:** **DRAM 마진 ~80%** — 일반 **하드웨어 제조**가 아닌 **고수익 소프트웨어 기업급** 이익률로 비유 *(02:10)*.
- **가격:** **반도체 가격 폭등**과 결합해 **이익 경로**가 **급격히 상향**된다는 서술 *(03:13)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **전망치 스케일:** **6개월** 만에 **5배 이상** 상향.
- **금액 스케일:** **기존 60~70조 원** → **현재 300조 원 이상** 수준으로 거론 *(03:13)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **마진 레버리지** | 동일 **출하**라도 **스프레드 확대**가 **이익**에 비선형 기여 |
| **가격·믹스** | **ASP** 상승이 **매출·이익**에 직접 반영 |
| **기대 경로** | 애널리스트·시장이 **EPS/이익 총액** 추정을 **상향 조정** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**구조적 고마진**과 **가격 강세**가 맞물리면, **단기간**에 **이익 전망 곡선**이 **상향 이동**한다는 **인과 주장**이다. 이는 이후 **밸류·목표가** 논의의 **입력 변수**가 된다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 마진 | **~80%** | *(02:10)* |
| 상향 폭 | **6개월** **5배+** | *(03:13)* |
| 규모 | **60~70조 → 300조+** | *(03:13)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `DRAM_Margin_SoftwareLike` | `with_memory_price_rally_drives` | `Korea_Memory_Earnings_Forecast_Surge` | `margin_times_price_to_revision` |

---

<a id="backlinks"></a>

## 8. 역링크

- [김장열 본부장](../entity/kim-jangyeol.md) · [통합 메모](../kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md) · [증설 시차 → 공급 부족](memory-fab-lag-to-under-supply-through-2027.md)

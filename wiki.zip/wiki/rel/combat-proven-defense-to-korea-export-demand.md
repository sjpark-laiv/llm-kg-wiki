---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(이선엽 대표)
---

# 인과: 실전 성능·미 공급 공백·NATO 이슈 → 한국 방산 글로벌 수요

**목적:** **실전 검증**과 **미 재고 부족**, **유럽의 주문 이동**이 **한국 방산**의 **장기 수혜**로 이어진다는 주장을 구조화한다.

**관련 개체:** [한국 방산 글로벌 논리](../entity/korea-defense-export-global-thesis.md) · [한국 주식시장](../entity/korea-equity-market.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Korea_Defense_Export_Global_Thesis`** | 방산 수출 | [korea-defense-export-global-thesis.md](../entity/korea-defense-export-global-thesis.md) |
| **`Korea_Equity_Market`** | 한국 증시 | [korea-equity-market.md](../entity/korea-equity-market.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **실전:** **천궁** 등 **명중률 96%+** *(22:32)*.
- **미 공급:** **재고 부족**·**제때 공급 어려움** *(24:00)*.
- **지정학:** **NATO·트럼프** 맥락에서 **유럽**이 **한국**으로 **주문 전환** *(24:00)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **포지셔닝:** **가격·성능·납기** **삼박자**로 **미국 대안** *(24:49)*.
- **증시:** **한국 증시** **구조 강세** 서사와 결합(요약 말미).

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **신뢰 자산** | **실전 데이터**가 **수출 RFP**로 전환 |
| **대체 공급** | **미 공백**을 **한국이 메움** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**실전 성능**이 **브랜드·신뢰**를 만들고, **미국의 공급 병목**과 **동맹 정치**가 **수요 지리**를 **한국으로 이동**시킨다는 **합성 인과**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 명중률 | **96%+** | *(22:32)* |
| 수요 | **유럽→한국** | *(24:00)* |
| 결론 | **미국 대안** | *(24:49)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Korea_Defense_Export_Global_Thesis` | `supports` | `Korea_Equity_Market` | `defense_orders` |

---

<a id="backlinks"></a>

## 8. 역링크

- [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-korea-equity-ai-defense-war-flow-causality.md)

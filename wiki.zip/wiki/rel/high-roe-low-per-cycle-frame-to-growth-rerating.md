---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 고ROE·저PER·사이클 프레임 → 성장주 재인식·리레이팅

**목적:** **메모리 대형주**가 **고ROE**임에도 **저PER**로 남아 있는 이유를 **사이클 프레임**으로 설명하고, 인식이 **성장주**로 바뀔 때 **대규모 리레이팅**이 온다는 주장을 구조화한다.

**관련 개체:** [메모리 대형주 ROE·PER 괴리](../entity/memory-equity-high-roe-low-per.md) · [국내 메모리 이익 전망 급상향](../entity/korea-memory-sector-earnings-forecast-surge.md) · [삼성전자](../entity/samsung-electronics.md) · [SK하이닉스](../entity/sk-hynix.md) · [ROE(시장·대형주 맥락)](../entity/roe.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Memory_Equity_HighROE_LowPER`** | 고ROE·저PER | [memory-equity-high-roe-low-per.md](../entity/memory-equity-high-roe-low-per.md) |
| **`Korea_Memory_Earnings_Forecast_Surge`** | 이익 전망 급상향 | [korea-memory-sector-earnings-forecast-surge.md](../entity/korea-memory-sector-earnings-forecast-surge.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **수익성:** **ROE 50~90%** 수준 *(16:20)*.
- **밸류:** **PER 4~6배**에 머무름 *(16:20)*.
- **인식 프레임:** 시장이 반도체를 **사이클 주식**으로 **보수 평가** *(18:27)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **리레이팅:** 프레임이 **성장주**로 바뀌는 과정에서 **대규모 주가 재평가** *(18:27)*.
- **종목:** **삼성전자·SK하이닉스** 밸류 논의와 접속.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **라벨 전환** | **사이클 → 성장/플랫폼형 이익** 서사로 **배수 밴드** 이동 |
| **전망 상향** | **EPS** 급상향이 **PER 재해석**(forward 기준)을 촉발 |
| **리스크 프리미엄** | **피크아웃 공포** 완화 시 **할인율 축소** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**이익률은 이미 ‘성장/프리미엄 산업’ 수준**인데 **배수는 ‘사이클 산업’ 수준**에 머물러 **불일치**가 크다. **인식 전환**이 일어나면 **배수 정상화**가 **주가**에 **비선형**으로 반영될 수 있다는 **인과 주장**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| ROE | **50~90%** | *(16:20)* |
| PER | **4~6배** | *(16:20)* |
| 프레임 | **사이클 → 성장** | *(18:27)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Memory_Equity_HighROE_LowPER` | `rerates_when_label_shifts_to` | `Growth_Stock_ReRating` | `cycle_to_growth` |
| `Korea_Memory_Earnings_Forecast_Surge` | `supports` | `Growth_Stock_ReRating` | `eps_revision_support` |

> 노트: `Growth_Stock_ReRating`은 **관계 문서 내부 요약 노드**.

---

<a id="backlinks"></a>

## 8. 역링크

- [이익 전망 vs 주가](earnings-forecast-upgrade-vs-price-to-memory-targets.md) · [통합 메모](../kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md)
- [ROE(엔티티)](../entity/roe.md) · [ROE → 멀티플(시장 전체)](roe-to-valuation-multiples-per-pbr.md) — **표본·수치 범위가 다름**(메모리 대형주 vs 코스피형 서술).

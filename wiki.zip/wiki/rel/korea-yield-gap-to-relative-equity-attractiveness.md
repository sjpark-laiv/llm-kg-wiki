---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 한·미 일드 갭 차이 → 한국 주식 상대 매력·비중 확대

**목적:** **금리·기대수익** 관점의 **일드 갭** 차이가 **한국 vs 미국** **주식 매력**과 **자산배분** 논리로 이어진다는 주장을 구조화한다.

**관련 개체:** [일드 갭](../entity/yield-gap-equity-bond.md) · [미국 주식시장](../entity/us-equity-market.md) · [한국 주식시장](../entity/korea-equity-market.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Yield_Gap_Equity_vs_Bond`** | 일드 갭 | [yield-gap-equity-bond.md](../entity/yield-gap-equity-bond.md) |
| **`US_Equity_Market`** | 미국 주식시장 | [us-equity-market.md](../entity/us-equity-market.md) |
| **`Korea_Equity_Market`** | 한국 주식시장 | [korea-equity-market.md](../entity/korea-equity-market.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **미국:** **채권 금리 대비 주식 기대수익률 차이(일드 갭)** 가 **약 0.5%**로 **낮아** 주식 **매력 하락** *(19:44)*.
- **한국:** **채권 대비 주식 기대수익률**이 여전히 **높은 편** *(19:44)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **상대 매력:** 금리 환경을 고려할 때 **미국보다 한국**이 **주식 투자**로서 **상대 매력**이 높다 *(20:00)*.
- **배분 함의:** **자산배분**에서 **한국 비중을 높여야** 한다는 실무적 결론 *(20:00)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **기대수익 스프레드** | 채권 **확정/준확정 수익** 대비 주식 **위험조정 기대** 비교 |
| **국가 간 차등** | 동일 개념(일드 갭)을 **한·미**에 각각 적용해 **상대평가** |
| **자본 배분** | 상대 매력 → **포트폴리오 비중** 조정 논리 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**미국**에서 **일드 갭 축소**는 **주식의 상대 매력 약화** 신호로 읽히고, **한국**에서는 **여전히 넓은(유리한) 일드 갭**이 남아 **주식이 채권 대비 유리**하다는 **대비**가 만들어진다. 이 **대비**가 **글로벌 자산배분**에서 **한국 비중 상향**의 **정당화**로 연결된다는 주장 *(20:00)*.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 미국 일드 갭 | **약 0.5%** 수준으로 **낮음** | *(19:44)* |
| 한국 일드 갭 | **채권 대비 주식** 기대수익 **상대적으로 높음** | *(19:44)* |
| 결론형 | **한국 비중 확대** | *(20:00)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Yield_Gap_Equity_vs_Bond` | `wider_in` | `Korea_Equity_Market` | `korea_bond_equity_spread` |
| `Yield_Gap_Equity_vs_Bond` | `narrow_in` | `US_Equity_Market` | `us_bond_equity_spread` |
| `Korea_Equity_Market` | `preferred_over` | `US_Equity_Market` | `relative_yield_gap` |

---

<a id="backlinks"></a>

## 8. 역링크

- [강관우 대표](../entity/kang-gwanwoo.md) · [이익·저평가 괴리 → 한국 비중](earnings-valuation-gap-to-korea-overweight-thesis.md)

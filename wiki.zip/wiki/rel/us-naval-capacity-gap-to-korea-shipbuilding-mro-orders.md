---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 인과: 미국 군함 인프라 부족·미중 경쟁 → 한국 조선 군함·MRO 발주 확대

**목적:** 미국의 군함 건조 제약과 지정학 경쟁이 결합해 한국 조선사로 군함 건조·MRO 수요가 이동하는 경로를 RCA·Impact 관점으로 정리한다.

**관련 개체:** [미국 선박 건조·수리 용량 부족](../entity/us-marine-shipbuilding-capacity-constraint.md) · [미국 군함 건조·MRO의 한국 아웃소싱 압력](../entity/us-naval-shipbuilding-mro-outsourcing-korea.md) · [한국 조선업 구조적 재도약](../entity/korea-shipbuilding-structural-resurgence.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`US_Marine_Shipbuilding_Capacity_Constraint`** | 미국 군함 인프라 제약 | [us-marine-shipbuilding-capacity-constraint.md](../entity/us-marine-shipbuilding-capacity-constraint.md) |
| **`Geopolitics_China_Shipyard_Exclusion`** | 미중 전략 경쟁 | [geopolitics-china-shipyard-exclusion.md](../entity/geopolitics-china-shipyard-exclusion.md) |
| **`US_Naval_Shipbuilding_MRO_Outsourcing_Korea`** | 한국 발주 확대 | [us-naval-shipbuilding-mro-outsourcing-korea.md](../entity/us-naval-shipbuilding-mro-outsourcing-korea.md) |
| **`Korea_Shipbuilding_Structural_Resurgence`** | 한국 조선 재도약 | [korea-shipbuilding-structural-resurgence.md](../entity/korea-shipbuilding-structural-resurgence.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **인력·비용 제약:** 미국 내 군함 건조는 인력 부족·고인건비로 단독 대응이 어렵다는 주장 *(30:41)*.
- **생산능력 격차:** 미국이 중국 대비 군함 건조 역량에서 열위라는 진단 *(30:58)*.
- **지정학 압력:** 미중 경쟁 심화로 신뢰 가능한 동맹 조선소 수요가 늘어나는 구조.

---

<a id="impact"></a>

## 3. 결과·영향

- **발주 전이:** 한국 조선사에 군함 건조 및 MRO 발주가 확장될 가능성.
- **시장 확장:** 상선 중심에서 방산·군함으로 조선업 TAM이 넓어지는 시나리오.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 | 분석 태그 |
|------|------|-----------|
| 공급 제약 | 미국 내 건조·수리 캐파 부족 | `RCA` |
| 지정학 필터 | 동맹 조선소 선호 및 중국 배제 | `RCA` |
| 발주 재배치 | 건조·MRO 물량의 한국 이동 | `Impact` |

---

<a id="causality-map"></a>

## 5. Causality map (엣지 표)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `US_Marine_Shipbuilding_Capacity_Constraint` | `raises_need_for` | `US_Naval_Shipbuilding_MRO_Outsourcing_Korea` | `capacity_shortfall` |
| `Geopolitics_China_Shipyard_Exclusion` | `channels_orders_to` | `US_Naval_Shipbuilding_MRO_Outsourcing_Korea` | `allied_security_filter` |
| `US_Naval_Shipbuilding_MRO_Outsourcing_Korea` | `supports` | `Korea_Shipbuilding_Structural_Resurgence` | `orderbook_expansion` |

---

<a id="logic-framework"></a>

## 6. 논리 프레임워크

```mermaid
flowchart LR
  A[US_Marine_Shipbuilding_Capacity_Constraint] --> B[US_Naval_Shipbuilding_MRO_Outsourcing_Korea]
  C[Geopolitics_China_Shipyard_Exclusion] --> B
  B --> D[Korea_Shipbuilding_Structural_Resurgence]
```

---

<a id="evidence-data"></a>

## 7. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 미국 제약 | 인력·비용으로 단독 건조 어려움 | *(30:41)* |
| 역량 격차 | 미 vs 중 군함 건조 능력 격차 | *(30:58)* |
| 발주 논리 | 한국 조선사 협력 필요성 | *(30:41)* |

---

<a id="backlinks"></a>

## 8. 역링크

- [염승환 이사](../entity/yeom-seunghwan.md)
- [주제 통합: 염승환 2026 코스피·조선](../yeom-seunghwan-2026-kospi-8500-shipbuilding-thesis-causality.md)

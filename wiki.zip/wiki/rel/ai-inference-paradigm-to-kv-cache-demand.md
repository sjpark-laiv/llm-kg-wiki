---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: AI 추론 패러다임 → KV 캐시 메모리 수요 폭증

**목적:** **학습→추론** 단계 전환이 **KV 캐시** 용량 요구를 **기하급수적으로** 키운다는 주장을 구조화한다.

**관련 개체:** [AI 학습→추론](../entity/ai-inference-paradigm-shift.md) · [KV 캐시 메모리](../entity/kv-cache-memory.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`AI_Inference_Paradigm`** | 추론 중심 국면 | [ai-inference-paradigm-shift.md](../entity/ai-inference-paradigm-shift.md) |
| **`KV_Cache_Memory`** | KV 캐시 | [kv-cache-memory.md](../entity/kv-cache-memory.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **단계 전환:** 과거 **학습** 중심에서 **생성형 AI 추론**으로 **진입** *(07:50)*.
- **워크로드 특성:** 추론은 **순간 기억**을 **키-밸류 형태**로 **대량 저장**해야 함.

---

<a id="effect"></a>

## 3. 결과·영향

- **KV 용량:** **80GB → 1TB** 수준으로 **8배 이상** 급증 서술 *(07:50)*, *(09:41)*.
- **2차 파급:** **HBM 단독 한계**·**범용 DRAM 혼용** 논리로 연결 ([다음 인과](kv-cache-inference-to-ddr5-mix-and-tightening.md)).

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **컨텍스트 길이** | 긴 **프롬프트·세션**이 **KV 테이블**을 팽창 |
| **배치·동시 추론** | 서빙 측 **병렬성**이 **메모리 발자국**을 증가 |
| **하드웨어 바인딩** | GPU/가속기 **온보드·근접 메모리** 용량 압력 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**추론**은 **학습**과 달리 **온라인 상태**에서 **반복적 메모리 접근**이 커지고, 특히 **KV 캐시**가 **용량의 핵심 병목**이 되어 **메모리 칩 수요**를 **급격히 팽창**시킨다는 **인과 서사**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 패러다임 | **학습 → 추론** | *(07:50)* |
| KV 용량 | **80GB→1TB**, **8배+** | *(09:41)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `AI_Inference_Paradigm` | `requires` | `KV_Cache_Memory` | `inference_kv_footprint` |

---

<a id="backlinks"></a>

## 8. 역링크

- [김장열 본부장](../entity/kim-jangyeol.md) · [통합 메모](../kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md) · [KV→DDR5](kv-cache-inference-to-ddr5-mix-and-tightening.md)

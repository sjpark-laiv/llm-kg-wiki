---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 메모리 이익(뉴 노멀) → 주식 밸류에이션 업사이드

**목적:** **메모리 반도체 이익**이 **뉴 노멀**로 이동하는데 **밸류에이션 프레임**은 **올드(메모리 할인)** 에 머물러 **추가 상승 여력**이 생긴다는 주장을 구조화한다.

**관련 개체:** [메모리 이익(뉴 노멀)](../entity/memory-semiconductor-earnings-new-normal.md) · [메모리 할인 프레임](../entity/memory-valuation-discount-frame.md) · [삼성전자](../entity/samsung-electronics.md) · [SK하이닉스](../entity/sk-hynix.md) · [글로벌 빅테크](../entity/global-big-tech-peers.md) · [TSMC](../entity/tsmc.md) · [이익 컨센서스 상향](../entity/earnings-consensus-upward-revision.md) · [PER·PBR 멀티플](../entity/valuation-multiples-per-pbr.md) · [한국 주식시장](../entity/korea-equity-market.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Memory_Semiconductor_Earnings_NewNormal`** | 메모리 이익(지속·구조) | [memory-semiconductor-earnings-new-normal.md](../entity/memory-semiconductor-earnings-new-normal.md) |
| **`Memory_Valuation_Discount_Frame`** | 메모리 할인 인식 | [memory-valuation-discount-frame.md](../entity/memory-valuation-discount-frame.md) |
| **`Samsung_Electronics` / `SK_Hynix`** | 한국 메모리 대표사 | [samsung-electronics.md](../entity/samsung-electronics.md), [sk-hynix.md](../entity/sk-hynix.md) |
| **`Earnings_Consensus_Upward_Revision`** | 컨센서스 상향 | [earnings-consensus-upward-revision.md](../entity/earnings-consensus-upward-revision.md) |
| **`Korea_Equity_Market`** | 한국 주식시장(수혜) | [korea-equity-market.md](../entity/korea-equity-market.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **이익 스케일:** 한국 메모리 기업 이익이 **애플·구글·메타** 등과 **비교 가능**하거나 **TSMC**보다 **높은 추정**이 거론됨 *(09:58)*.
- **지속성:** **일시적 피크아웃**이 아니라 **2027년**까지 **성장**으로 **컨센서스 상향** *(10:48)*.
- **뉴 노멀 서술:** 이익 경로가 **구조적 상향** 국면으로 읽힘 *(03:55)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **밸류 갭:** 이익은 **뉴 노멀**인데 멀티플 논의는 **올드 기준(메모리 할인)** 에 머물러 **불일치** *(10:48)*.
- **주가 업사이드:** 위 **불일치**가 **추가 상승 여력**으로 작용한다는 결론형 *(10:48)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 경로 | 기제 |
|------|------|
| **이익 레벨 → 동종 비교** | 글로벌 **빅테크·TSMC** 대비 **이익 스케일** 프레이밍 |
| **기대 경로 → 멀티플** | **컨센서스 상향**이 **지속성**을 뒷받침 → **할인율 축소·배수 상향** 논리 |
| **인식 지연** | 과거 **메모리 사이클** 경험이 **배수에 잔존 할인**으로 남음 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**이익 변수**는 **뉴 노멀**로 이동하고 있으나, **가격(밸류에이션)** 은 **과거의 메모리 할인**이라는 **낡은 잣대**에 머물러 있어, **이익 대비 주가**에 **추가적인 업사이드**가 남아 있다는 **인과적 주장**이 정리된다 *(10:48)*.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 글로벌 비교 | 빅테크·**TSMC** 대비 이익 스케일 서술 | *(09:58)* |
| 컨센서스 | **2027년**까지 성장, **상향** | *(10:48)* |
| 밸류 프레임 | **메모리 할인** 잔존 | *(09:58)* |
| 이익 국면 | **뉴 노멀** | *(03:55)*, *(10:48)* |

---

<a id="causality-map"></a>

## 7. Causality map·엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Memory_Semiconductor_Earnings_NewNormal` | `diverges_from` | `Memory_Valuation_Discount_Frame` | `earnings_vs_old_multiple` |
| `Memory_Valuation_Discount_Frame` | `implies_rerating_for` | `Korea_Equity_Market` | `re_rating_potential` |

---

<a id="backlinks"></a>

## 8. 역링크

- [강관우 대표](../entity/kang-gwanwoo.md) · [이익·저평가 괴리 → 한국 비중](earnings-valuation-gap-to-korea-overweight-thesis.md)

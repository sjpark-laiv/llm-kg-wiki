---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 인과: 코스피 저PER 국면 → 평균 멀티플 복귀 → 코스피 8,500 상방 시나리오

**목적:** 코스피의 낮은 PER이 평균 회귀할 때 지수 상방이 열린다는 논리를 RCA·Impact 형태로 정리한다.

**관련 개체:** [코스피 지수](../entity/kospi-index.md) · [PER·PBR 멀티플](../entity/valuation-multiples-per-pbr.md) · [한국 주식시장](../entity/korea-equity-market.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`KOSPI_Index`** | 코스피 지수 | [kospi-index.md](../entity/kospi-index.md) |
| **`Valuation_Multiples_PER_PBR`** | 멀티플 축 | [valuation-multiples-per-pbr.md](../entity/valuation-multiples-per-pbr.md) |
| **`Korea_Equity_Market`** | 한국 증시 | [korea-equity-market.md](../entity/korea-equity-market.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **현재 PER 저점 인식:** 코스피 PER이 8배 미만으로 장기 평균(9.8배) 대비 낮다는 주장 *(03:52)*.
- **이익 유지 가정:** 이익 레벨이 유지되면 멀티플 복귀만으로도 지수 상방이 가능하다는 해석 *(04:02)*.

---

<a id="impact"></a>

## 3. 결과·영향

- **지수 업사이드:** 평균 멀티플 복귀 시 8,000 이상, 상단으로 8,500 시나리오 제시.
- **전략 함의:** 지수 하방보다 재평가 여력에 무게를 두는 장세 해석.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 | 분석 태그 |
|------|------|-----------|
| 멀티플 갭 | 평균 대비 저평가 구간 확인 | `RCA` |
| 평균 회귀 | 이익 유지 시 밸류 복원 | `Impact` |
| 지수 환산 | 멀티플 변화가 지수 레벨로 전이 | `Evidence` |

---

<a id="causality-map"></a>

## 5. Causality map (엣지 표)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Valuation_Multiples_PER_PBR` | `below_history_for` | `KOSPI_Index` | `discount_gap` |
| `Valuation_Multiples_PER_PBR` | `mean_reverts_to` | `Korea_Equity_Market` | `multiple_normalization` |
| `Korea_Equity_Market` | `implies_upside_for` | `KOSPI_Index` | `index_translation` |

---

<a id="logic-framework"></a>

## 6. 논리 프레임워크

```text
IF KOSPI PER is below long-term average
AND earnings level remains stable
THEN multiple normalization upside opens.
IF normalization continues
THEN KOSPI_Index can extend toward 8,000+ and 8,500 scenario.
```

---

<a id="evidence-data"></a>

## 7. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 밸류 | PER 8배 미만 vs 평균 9.8배 | *(03:52)* |
| 환산 | 평균 멀티플 적용 시 8,000+ 논리 | *(04:02)* |

---

<a id="backlinks"></a>

## 8. 역링크

- [염승환 이사](../entity/yeom-seunghwan.md)
- [주제 통합: 염승환 2026 코스피·조선](../yeom-seunghwan-2026-kospi-8500-shipbuilding-thesis-causality.md)

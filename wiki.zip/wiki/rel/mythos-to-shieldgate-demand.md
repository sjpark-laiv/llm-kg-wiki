---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 미토스(Mythos) 등장 → 실드게이트(SHIELD Gate) 수요 급증

RCA·Impact 추론용 근거 문서. [미토스](../entity/mythos-ai-agent.md) 사태가 [실드게이트](../entity/shieldgate.md)([소프트캠프](../entity/softcamp.md))의 시장 수요를 구조적으로 끌어올리는 인과관계를 구조화한다.

---

<a id="entity-table"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 정의(분석용) | 엔티티 문서 |
|-----------|-----------|-------------|-------------|
| `Mythos` | 미토스 AI 에이전트 | AI 기반 취약점 탐지·공격 에이전트 | [mythos-ai-agent.md](../entity/mythos-ai-agent.md) |
| `SHIELD_Gate` | 실드게이트 | RBI 기반 원천 차단 보안 솔루션 | [shieldgate.md](../entity/shieldgate.md) |
| `Softcamp` | 소프트캠프 (258790) | 실드게이트 개발·공급 기업 | [softcamp.md](../entity/softcamp.md) |
| `RBI` | 원격 브라우저 격리 | 원격 서버에서 웹 실행 후 화면만 전송 | [rbi-remote-browser-isolation.md](../entity/rbi-remote-browser-isolation.md) |
| `Legacy_Security` | 기존 로컬 설치형 보안 | EDR 등 | [edr-endpoint-security.md](../entity/edr-endpoint-security.md) |

<a id="causality-map"></a>

## 2. Causality Map

| 단계 | 원인 | → | 결과 | 전달 유형 | 분석 태그 |
|------|------|---|------|-----------|-----------|
| 1차 | `Mythos` 등장 | → | `Legacy_Security` 구조적 한계 노출 | 직접 | `RCA` |
| 2차 | `Legacy_Security` 위기 | → | "로컬 무설치" 보안 수요 폭증 | 간접 | `Impact` |
| 2차 | "로컬 무설치" 수요 | → | `RBI` 기술 각광 | 간접 | `Impact` |
| 3차 | `RBI` 수요 급증 | → | `SHIELD_Gate` 수주·매출 확대 | 간접 | `Impact` |
| 3차 | `SHIELD_Gate` 성장 | → | `Softcamp` 턴어라운드 가속 | 간접 | `Impact` |

<a id="edge-table"></a>

## 3. 그래프 엣지 표

| source | edge | target | mechanism_id |
|--------|------|--------|-------------|
| `Mythos` | 로컬 보안 무력화 입증 | `Legacy_Security` | `M1_security_breach` |
| `Legacy_Security` | 대안 기술 수요 촉발 | `RBI` | `M2_demand_shift` |
| `RBI` | 대표 제품으로 수혜 집중 | `SHIELD_Gate` | `M3_product_adoption` |
| `SHIELD_Gate` | 원천 차단으로 침투 경로 제거 | `Mythos` | `M4_countermeasure` |
| `SHIELD_Gate` | 매출 확대 기여 | `Softcamp` | `M5_revenue_growth` |

<a id="root-cause"></a>

## 4. 원인·근원 (Root Cause)

- **근본 원인**: `Mythos`가 로컬 PC 보안의 구조적 한계를 입증 → 로컬 무설치 보안이 유일한 대안으로 부상
- `SHIELD_Gate`는 RBI 방식으로 로컬 PC에 공격 대상 자체가 없음 → 미토스 같은 AI 해킹 도구에 대한 **물리적 방어** 가능
- [이충헌](../entity/lee-chung-hun.md) 밸류파인더 대표: "침입 자체를 원천 차단하는 사전적 방어가 가능"

<a id="impact"></a>

## 5. 결과·영향 (Impact)

- [ ] RBI 기반 보안 솔루션 시장 급성장
- [ ] 실드게이트가 금융권·공공·민간 시장에서 수주 확대
- [ ] 소프트캠프 매출 169억원(2024) → 257억원(2025), 영업이익 −18억 → +30억 흑자전환
- [ ] "미토스 사태는 RBI 전환의 결정적 촉매제" (밸류파인더)

<a id="evidence-data"></a>

## 6. Evidence

| 관측 사실 | 수치·근거 | 출처 |
|-----------|-----------|------|
| 소프트캠프 매출 성장 | 169억(2024) → 257억(2025), +52% | 밸류파인더 리포트 |
| 영업이익 턴어라운드 | −18억(2024) → +30억(2025) | 동일 |
| 보안 솔루션 매출 비중 | 전체의 70.1% (2025) | 동일 |
| 실드게이트 방어 원리 | 로컬 PC 무설치 → 공격 경로 자체 없음 | 동일 |

<a id="logic-framework"></a>

## 7. 논리 프레임워크

```mermaid
flowchart TD
    A[Mythos 등장] --> B[로컬 설치형 보안 한계 노출]
    B --> C[로컬 무설치 보안 수요 폭증]
    C --> D[RBI 기술 각광]
    D --> E[SHIELD Gate 수주 확대]
    E --> F["Softcamp 매출 257억 / 흑자전환"]
    G[SHIELD Gate 원천 차단] -.->|대응| A
    style G fill:#e6f3e6
```

<a id="backlinks"></a>

## 8. 역링크

- [미토스](../entity/mythos-ai-agent.md) · [실드게이트](../entity/shieldgate.md) · [소프트캠프](../entity/softcamp.md) · [RBI](../entity/rbi-remote-browser-isolation.md)
- [미토스 → 기존 보안체계 위기](mythos-to-legacy-security-crisis.md)
- [실드게이트 RBI → 보안시장 확대](shieldgate-rbi-to-security-market-expansion.md)
- [소프트캠프·실드게이트 AI 보안 전망 (주제 통합)](../softcamp-shieldgate-ai-security-outlook.md)

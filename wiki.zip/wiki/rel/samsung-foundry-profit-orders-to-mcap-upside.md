---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 삼성 파운드리 수율·수주·흑자 전환 → 시가총액 추가 상승 여력

**목적:** **적자 파운드리**가 **수율·수주**로 **흑자**로 전환될 때 **시가총액**에 **큰 옵션**이 붙는다는 주장을 구조화한다.

**관련 개체:** [삼성전자 파운드리](../entity/samsung-foundry-division.md) · [삼성전자](../entity/samsung-electronics.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Samsung_Foundry_Division`** | 삼성 파운드리 | [samsung-foundry-division.md](../entity/samsung-foundry-division.md) |
| **`Samsung_Electronics`** | 삼성전자 | [samsung-electronics.md](../entity/samsung-electronics.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **수익성 전환:** **적자** → **내년 흑자** 기대 *(29:13)*.
- **운영·수주:** **수율 개선**, **테슬라·오픈AI** 등 **수주 가능성** *(29:13)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **밸류 반영:** 가치가 **주가에 반영**될 경우 **시총 50~100조 원** 추가 상승 **여력** *(31:38)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **손익전환** | **EBIT 전환**이 **섹터 배수**에 **합산 밸류**로 들어감 |
| **수주 가시성** | **하이프로필 고객**이 **지속 매출** 프리미엄을 부여 |
| **SOTP** | **메모리 + 파운드리** **합성 밸류** 재평가 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**파운드리**는 **메모리**와 별도로 **손익·수주 스토리**를 가진 **옵션 자산**이다. **흑자 전환**과 **수주 레짐**이 확인되면, 투자자는 **Sum-of-the-parts** 관점에서 **추가 시총**을 **배당**한다는 **인과 주장**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 전환 | **내년 흑자** 기대 | *(29:13)* |
| 수주 | **테슬라·오픈AI** | *(29:13)* |
| 시총 | **50~100조** 추가 여력 | *(31:38)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Samsung_Foundry_Division` | `values_into` | `Samsung_Electronics` | `sotp_foundry` |

---

<a id="backlinks"></a>

## 8. 역링크

- [이익 전망 vs 주가·목표가](earnings-forecast-upgrade-vs-price-to-memory-targets.md) · [통합 메모](../kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md)

---
wiki_created: 2026-04-23
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# AI 기업 효용 체감 → 한국 반도체 400조원 실적 확신

RCA·Impact 추론용 근거 문서. [클로드](../entity/claude-ai-model.md)·제미나이 등 AI 모델의 성능이 실무에서 인간을 압도하면서, 기업들의 AI 투자가 불가역적으로 확대되고, 이것이 한국 반도체 기업의 **400조원** 이익 전망에 확신을 더하는 인과관계를 구조화한다. [염승환](../entity/yeom-seunghwan.md) 이사 발언.

---

<a id="entity-table"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 정의(분석용) | 엔티티 문서 |
|-----------|-----------|-------------|-------------|
| `Claude` | 클로드 AI 모델 | 앤스로픽의 AI, 리서치·사실 관계에 강점 | [claude-ai-model.md](../entity/claude-ai-model.md) |
| `AI_Enterprise_Efficacy` | AI 기업 효용 체감 | AI 성능이 실무에서 인간을 압도 → 투자 불가역 | — |
| `Korea_Semi_400T` | 한국 반도체 400조 실적 | 삼성전자+SK하이닉스 합산 이익 전망 | — |
| `Samsung_Electronics` | 삼성전자 | 메모리·파운드리 | [samsung-electronics.md](../entity/samsung-electronics.md) |
| `SK_Hynix` | SK하이닉스 | HBM 선도 | [sk-hynix.md](../entity/sk-hynix.md) |

<a id="causality-map"></a>

## 2. Causality Map

| 단계 | 원인 | → | 결과 | 전달 유형 | 분석 태그 |
|------|------|---|------|-----------|-----------|
| 1차 | `Claude`·제미나이 등 AI 성능이 실무에서 인간 압도 | → | 기업들이 AI 투자 불가역 체감 | 직접 | `RCA` |
| 2차 | AI 투자 불가역 | → | AI 인프라 CAPEX 장기 지속 확신 | 직접 | `Impact` |
| 3차 | CAPEX 장기 지속 | → | 한국 반도체 **400조원** 이익 전망에 확신 | 간접 | `Impact` |

<a id="edge-table"></a>

## 3. 그래프 엣지 표

| source | edge | target | mechanism_id |
|--------|------|--------|-------------|
| `Claude` | 실무 성능 압도 | `AI_Enterprise_Efficacy` | `M1_ai_efficacy` |
| `AI_Enterprise_Efficacy` | 과소투자 시 도태 | `AI_Infra_Capex` | `M2_capex_irreversible` |
| `AI_Infra_Capex` | 메모리 수요 장기화 | `Korea_Semi_400T` | `M3_400t_conviction` |

<a id="root-cause"></a>

## 4. 원인·근원 (Root Cause)

- 클로드·제미나이 등 AI 모델이 **리서치·실무에서 인간을 압도** [25:30]
- AI 효용을 **체감한 기업**들이 투자를 포기할 수 없게 됨 — **"과소 투자 시 도태"** [21:00]
- [오픈AI](../entity/openai.md) 샘 알트먼: **30GW 컴퓨팅 수요** 목표 [24:10]

<a id="impact"></a>

## 5. 결과·영향 (Impact)

- [ ] AI 인프라 CAPEX가 일시적이 아닌 **장기 구조적** 사이클로 확정
- [ ] 한국 반도체(삼성전자+SK하이닉스) **내년까지 400조원** 이익 가능 분석에 확신 [21:00]
- [ ] 코스피 "대운" 서사의 **실적 근거** 강화

<a id="evidence-data"></a>

## 6. Evidence

| 관측 사실 | 수치·근거 | 타임코드 |
|-----------|-----------|----------|
| AI 모델 성능 (클로드·제미나이) | 리서치·실무에서 인간 압도 | [25:30] |
| 한국 반도체 이익 전망 | **400조원** (삼성+하이닉스) | [21:00] |
| 샘 알트먼 컴퓨팅 수요 | 30GW 목표 | [24:10] |
| 아마존 → 앤스로픽 투자 | 대규모 투자 유치 | [22:30] |

<a id="logic-framework"></a>

## 7. 논리 프레임워크

```mermaid
flowchart TD
    A["클로드·제미나이: 실무에서 인간 압도"] --> B["기업들: AI 투자 불가역 체감"]
    B --> C["과소 투자 시 도태"]
    C --> D["AI 인프라 CAPEX 장기 지속 확정"]
    D --> E["한국 반도체 400조원 이익 전망 확신"]
    E --> F["코스피 '대운' 실적 근거"]
    style A fill:#ffcccc
    style E fill:#ccffcc
```

<a id="backlinks"></a>

## 8. 역링크

- [클로드](../entity/claude-ai-model.md) · [오픈AI](../entity/openai.md) · [아마존](../entity/amazon-aws.md)
- [삼성전자](../entity/samsung-electronics.md) · [SK하이닉스](../entity/sk-hynix.md)
- [빅테크 CAPEX → 한국 반도체 매출](bigtech-capex-to-korea-semiconductor-revenue.md)
- [AI 에이전트·CPU → DDR5 수요](ai-agent-cpu-to-general-dram-demand.md)
- [염승환 · 코스피 대운 (주제 통합)](../yeom-seunghwan-kospi-great-fortune-ai-semiconductor-causality.md)

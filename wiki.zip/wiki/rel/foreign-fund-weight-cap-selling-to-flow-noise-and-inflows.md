---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(이선엽 대표)
---

# 인과: 펀드 비중 규정 매도 → 단기 노이즈 vs 펀더멘털·장기 외국인 유입·하방 경직

**목적:** **외국인 매도**를 **한국 비호**가 아니라 **펀드 비중 규정**의 **기계적 결과**로 읽고, **장기 유입**이 **하방**을 지탱한다는 주장을 구조화한다.

**관련 개체:** [펀드 비중 규정 매도](../entity/foreign-fund-weight-cap-selling-korea.md) · [한국 주식시장](../entity/korea-equity-market.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Foreign_Fund_Weight_Cap_Selling_Korea`** | 비중 규정 매도 | [foreign-fund-weight-cap-selling-korea.md](../entity/foreign-fund-weight-cap-selling-korea.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **규정:** **펀드 내 비중 상한(예: 25%)** → **주가 상승** 시 **자동 매도** *(28:10)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **노이즈:** **일시적** 수급 압력으로 읽힘.
- **펀더멘털:** **이익 창출** 강화 → **외국인 자금 지속 유입** *(26:45)*.
- **장기:** **환차익·반도체 업황** **유입** *(27:19)* → **하방 경직성** *(26:45)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **규칙 기반 리밸런싱** | **단일 펀드**의 **한도** |
| **별도 트랙** | **전략·국면** 투자자의 **펀더멘털 매수** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**가격 상승**이 **비중 초과**를 만들면 **강제 매도**가 나오나, 이는 **한국 자산의 매력 부재**와 **동치되지 않는다**는 **주장**이다. **장기 트렉**은 **실적·환율**이 지배한다는 **이원 구조**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 매도 이유 | **비중 규정** | *(28:10)* |
| 유입 | **환차익·반도체** | *(27:19)* |
| 결론 | **하방 경직** | *(26:45)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Foreign_Fund_Weight_Cap_Selling_Korea` | `creates_short_term` | `Flow_Noise_Korea` | `weight_cap_selling` |

> 노트: `Flow_Noise_Korea`는 **관계 문서 내부 라벨**.

---

<a id="backlinks"></a>

## 8. 역링크

- [외국인 기계적 매도 (다른 메커니즘)](../entity/foreign-investor-mechanical-selling.md) · [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-korea-equity-ai-defense-war-flow-causality.md)

---
wiki_created: 2026-04-23
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# 빅테크 CAPEX 전환 → 한국 반도체 매출 직결

RCA·Impact 추론용 근거 문서. [글로벌 빅테크(M7)](../entity/global-big-tech-peers.md)가 자사주 매입에서 **AI 인프라 투자**로 자금을 전환하면서, 그 지출이 [삼성전자](../entity/samsung-electronics.md)·[SK하이닉스](../entity/sk-hynix.md)의 매출로 직결되는 인과관계를 구조화한다. [염승환](../entity/yeom-seunghwan.md) 이사 발언.

---

<a id="entity-table"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 정의(분석용) | 엔티티 문서 |
|-----------|-----------|-------------|-------------|
| `M7_BigTech` | M7 빅테크 | 미국 7대 빅테크(애플·구글·메타·아마존 등) | [global-big-tech-peers.md](../entity/global-big-tech-peers.md) |
| `AI_Infra_Capex` | AI 인프라 CAPEX | GPU·메모리·DC·전력 투자 사이클 | [ai-infrastructure-capex-cycle.md](../entity/ai-infrastructure-capex-cycle.md) |
| `Samsung_Electronics` | 삼성전자 | HBM + 범용 메모리 공급사 | [samsung-electronics.md](../entity/samsung-electronics.md) |
| `SK_Hynix` | SK하이닉스 | AI 메모리(HBM) 선도 기업 | [sk-hynix.md](../entity/sk-hynix.md) |
| `KOSPI` | 코스피 | 한국 주식시장 지수 | [kospi-index.md](../entity/kospi-index.md) |

<a id="causality-map"></a>

## 2. Causality Map

| 단계 | 원인 | → | 결과 | 전달 유형 | 분석 태그 |
|------|------|---|------|-----------|-----------|
| 1차 | `M7_BigTech` 자사주 매입 → AI CAPEX 전환 | → | AI 데이터센터 증설 투자 급증 | 직접 | `RCA` |
| 2차 | AI CAPEX 급증 | → | 메모리·반도체 수요 → `Samsung`·`SK_Hynix` 매출 직결 | 직접 | `Impact` |
| 2차 | 빅테크 비용 증가 | → | 빅테크 주가 할인 | 직접 | `Evidence` |
| 3차 | 한국 반도체 실적 급등 | → | `KOSPI` "대운" 서사 강화 | 간접 | `Impact` |

<a id="edge-table"></a>

## 3. 그래프 엣지 표

| source | edge | target | mechanism_id |
|--------|------|--------|-------------|
| `M7_BigTech` | 자사주→CAPEX 전환 | `AI_Infra_Capex` | `M1_capex_shift` |
| `AI_Infra_Capex` | 메모리·반도체 수요 | `Samsung_Electronics` | `M2_revenue_direct` |
| `AI_Infra_Capex` | HBM 수요 | `SK_Hynix` | `M3_hbm_revenue` |
| `M7_BigTech` | 투자비용 증가 → 할인 | `US_Equity` | `M4_discount` |
| `Samsung_Electronics` | 실적 급등 → 재평가 | `KOSPI` | `M5_rerating` |

<a id="root-cause"></a>

## 4. 원인·근원 (Root Cause)

- **과거 10년**: M7 빅테크가 번 돈으로 **자사주 매입** → 자기 주가 상승
- **현재**: 같은 돈을 **AI 데이터센터 증설(인프라 투자)**에 투입 [15:35]
- 빅테크의 **비용(CAPEX)**이 한국 반도체 기업의 **매출**로 직결되는 구조로 전환 [16:30]
- "빅테크는 투자비용 증가로 할인을 받지만, 그 돈을 받아 실적이 찍히는 한국 기업들은 재평가" [17:10]

<a id="impact"></a>

## 5. 결과·영향 (Impact)

- [ ] 삼성전자·SK하이닉스 매출·영업이익 역대급 전망
- [ ] 빅테크 CAPEX → 한국 전력 인프라 기업(버티브, 캐터필러 등)으로도 확산
- [ ] 코스피 "대운" 진입 — 실적 장세의 구조적 근거
- [ ] 미국 증시 vs 한국 증시 역전 가능성 (비용 vs 매출 구조)

<a id="evidence-data"></a>

## 6. Evidence

| 관측 사실 | 수치·근거 | 타임코드 |
|-----------|-----------|----------|
| M7 투자 패턴 전환 | 자사주→AI CAPEX | [15:35] |
| 빅테크 비용 = 한국 매출 | 구조 전환 | [16:30] |
| 빅테크 할인 vs 한국 재평가 | 구간 특성 | [17:10] |
| 인프라주 수혜 | 버티브·캐터필러·GE버노바·루멘텀 | [16:15~20] |

<a id="logic-framework"></a>

## 7. 논리 프레임워크

```mermaid
flowchart TD
    A["M7 빅테크: 자사주 매입 → AI CAPEX 전환"] --> B[AI 데이터센터 증설 급증]
    B --> C["삼성전자·SK하이닉스 매출 직결"]
    B --> D["전력·냉각 인프라 기업 수혜"]
    A --> E["빅테크 주가: 투자비용 증가 → 할인"]
    C --> F["한국 반도체 실적 역대급"]
    F --> G["코스피 '대운' — 실적 장세"]
    style A fill:#ffcccc
    style F fill:#ccffcc
    style G fill:#cce5ff
```

<a id="backlinks"></a>

## 8. 역링크

- [글로벌 빅테크(M7)](../entity/global-big-tech-peers.md) · [AI 인프라 CAPEX](../entity/ai-infrastructure-capex-cycle.md)
- [삼성전자](../entity/samsung-electronics.md) · [SK하이닉스](../entity/sk-hynix.md) · [코스피](../entity/kospi-index.md)
- [오픈AI](../entity/openai.md) · [아마존](../entity/amazon-aws.md) · [엔비디아](../entity/nvidia.md)
- [AI 에이전트·CPU → DDR5 수요](ai-agent-cpu-to-general-dram-demand.md)
- [AI 효용 체감 → 400조 실적 확신](ai-enterprise-efficacy-to-korea-400t-earnings-conviction.md)
- [염승환 · 코스피 대운 (주제 통합)](../yeom-seunghwan-kospi-great-fortune-ai-semiconductor-causality.md)

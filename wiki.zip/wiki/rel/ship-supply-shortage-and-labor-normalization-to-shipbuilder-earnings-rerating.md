---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 인과: 글로벌 선박 공급 부족·인력 정상화 → 조선 실적 개선·주가 재평가

**목적:** 조선업의 수주 환경과 비용 구조 변화가 실적 개선 및 밸류 리레이팅으로 연결되는 경로를 RCA·Impact 형태로 구조화한다.

**관련 개체:** [조선 수주잔고·마진 정상화](../entity/shipbuilding-order-backlog-margin-normalization.md) · [한국 조선업 구조적 재도약](../entity/korea-shipbuilding-structural-resurgence.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Global_Ship_Supply_Tightness`** | 글로벌 선박 공급 부족 | [shipbuilding-order-backlog-margin-normalization.md](../entity/shipbuilding-order-backlog-margin-normalization.md) |
| **`Shipbuilding_OrderBacklog_Margin_Normalization`** | 수주·마진 정상화 | [shipbuilding-order-backlog-margin-normalization.md](../entity/shipbuilding-order-backlog-margin-normalization.md) |
| **`Korea_Shipbuilding_Structural_Resurgence`** | 한국 조선 업황 | [korea-shipbuilding-structural-resurgence.md](../entity/korea-shipbuilding-structural-resurgence.md) |
| **`Valuation_Multiples_PER_PBR`** | 밸류 멀티플 재평가 | [valuation-multiples-per-pbr.md](../entity/valuation-multiples-per-pbr.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **수주 기반:** 조선 수주잔고가 높은 수준으로 유지된다는 진단 *(15:09)*.
- **비용 개선:** 과거 인력 부족으로 훼손된 마진이 숙련도 개선으로 완화되는 흐름 *(31:50)*.

---

<a id="impact"></a>

## 3. 결과·영향

- **이익 가시화:** 기대감 선행이 아니라 실제 실적 인식 구간으로 이동.
- **밸류 재평가:** 공급 부족이 지속되는 가운데 이익률 개선이 주가 재평가 트리거로 작동.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 | 분석 태그 |
|------|------|-----------|
| 수주 가시성 | 잔고가 매출·가동률을 선행 지지 | `RCA` |
| 비용 정상화 | 인력 숙련도 개선으로 마진 복원 | `Impact` |
| 숫자 검증 | 실적 발표로 서사의 신뢰도 강화 | `Evidence` |

---

<a id="causality-map"></a>

## 5. Causality map (엣지 표)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Global_Ship_Supply_Tightness` | `supports` | `Shipbuilding_OrderBacklog_Margin_Normalization` | `backlog_visibility` |
| `Shipbuilding_OrderBacklog_Margin_Normalization` | `strengthens` | `Korea_Shipbuilding_Structural_Resurgence` | `margin_recovery` |
| `Korea_Shipbuilding_Structural_Resurgence` | `leads_to` | `Valuation_Multiples_PER_PBR` | `earnings_rerating` |

---

<a id="logic-framework"></a>

## 6. 논리 프레임워크

```text
IF Global_Ship_Supply_Tightness persists
THEN order backlog remains high.
IF labor normalization progresses
THEN shipbuilder margin recovers.
IF backlog visibility AND margin recovery coexist
THEN Korea_Shipbuilding_Structural_Resurgence rerating probability rises.
```

---

<a id="evidence-data"></a>

## 7. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 수주 | 수주잔고가 이미 차 있는 상태 | *(15:09)* |
| 실적 | 기대감이 아닌 숫자 기반 확인 | *(15:09)* |
| 비용 | 인력 이슈 완화·숙련도 개선 | *(31:50)* |

---

<a id="backlinks"></a>

## 8. 역링크

- [염승환 이사](../entity/yeom-seunghwan.md)
- [주제 통합: 염승환 2026 코스피·조선](../yeom-seunghwan-2026-kospi-8500-shipbuilding-thesis-causality.md)

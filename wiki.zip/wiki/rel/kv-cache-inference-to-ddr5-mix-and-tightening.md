---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 추론·KV 부하 → HBM+범용 DDR5 혼용 → 범용 DRAM 재고·가격 긴장

**목적:** **추론 메모리** 수요가 **HBM만으로는 부족**해 **범용 DRAM**이 **대량 혼입**되며, **삼성전자 강점 영역**의 **재고 소진·가격 급등**으로 이어진다는 주장을 구조화한다.

**관련 개체:** [KV 캐시](../entity/kv-cache-memory.md) · [HBM](../entity/hbm-memory-product.md) · [범용 DDR5](../entity/ddr5-general-purpose-dram.md) · [삼성전자](../entity/samsung-electronics.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`KV_Cache_Memory`** | KV 캐시 | [kv-cache-memory.md](../entity/kv-cache-memory.md) |
| **`HBM_Product`** | HBM | [hbm-memory-product.md](../entity/hbm-memory-product.md) |
| **`DDR5_GeneralPurpose_DRAM`** | 범용 DDR5 | [ddr5-general-purpose-dram.md](../entity/ddr5-general-purpose-dram.md) |
| **`Samsung_Electronics`** | 삼성전자 | [samsung-electronics.md](../entity/samsung-electronics.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **추론 부하:** **KV 캐시** 등으로 **메모리 발자국** 급증 *(07:50)*, *(09:41)*.
- **HBM 제약:** **비싼 HBM만**으로 **전량 커버 어려움** *(08:50)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **믹스:** **일반(범용) DRAM**을 **대량 혼용** *(08:50)*.
- **시장 결과:** **범용 DRAM 재고 소진**·**가격 급등** *(11:13)*.
- **기업 포지션:** **삼성전자**가 **범용 DRAM**에서 **강점** — 수혜 서사와 연결 *(11:13)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **비용 최적화** | HBM **단가/용량** 한계 → **DDR5**로 **계층화** |
| **서빙 아키텍처** | **KV 오프로드·계층 메모리** 설계 확산(요약 주장 수준) |
| **재고 사이클** | 수요 급증 → **가용 재고 소진** → **ASP 상승** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**추론 워크로드**는 **고대역 메모리(HBM)** 에 **집중**되지만, **비용·용량** 관점에서 **범용 DRAM**이 **필수 보조층**으로 끌려 들어와 **총 메모리 소비**가 팽창한다. 이 과정에서 **범용 DRAM**의 **재고·가격**이 **급격히 타이트**해진다는 **인과**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| HBM 한계 | **단독 감당 어려움** | *(08:50)* |
| DDR5 | **대량 혼용** | *(08:50)* |
| 결과 | **재고 소진·가격 급등** | *(11:13)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `KV_Cache_Memory` | `forces_mix_with` | `DDR5_GeneralPurpose_DRAM` | `hbm_binding` |
| `HBM_Product` | `complements` | `DDR5_GeneralPurpose_DRAM` | `tiered_memory` |
| `DDR5_GeneralPurpose_DRAM` | `tightens_inventory_for` | `Samsung_Electronics` | `general_dram_leadership` |

---

<a id="backlinks"></a>

## 8. 역링크

- [AI 추론→KV](ai-inference-paradigm-to-kv-cache-demand.md) · [김장열 본부장](../entity/kim-jangyeol.md) · [통합 메모](../kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md)

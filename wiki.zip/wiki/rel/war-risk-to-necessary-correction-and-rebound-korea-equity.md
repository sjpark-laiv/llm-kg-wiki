---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(이선엽 대표)
---

# 인과: 전쟁 리스크·단기 조정 → 필수 냉각·이후 산업 수요·강한 반등

**목적:** **전쟁 불확실성**이 만든 **조정**을 **과열 냉각**으로 읽고, **분쟁 구조**상 **장기화 제약** 뒤 **증시 강한 반등**으로 이어진다는 주장을 구조화한다.

**관련 개체:** [전쟁·조정·반등 패턴](../entity/war-risk-market-correction-recovery-pattern.md) · [한국 주식시장](../entity/korea-equity-market.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`War_Risk_Market_Correction_Recovery_Pattern`** | 전쟁 패턴 | [war-risk-market-correction-recovery-pattern.md](../entity/war-risk-market-correction-recovery-pattern.md) |
| **`Korea_Equity_Market`** | 한국 증시 | [korea-equity-market.md](../entity/korea-equity-market.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **역사:** 전쟁 → **단기 불안** + **신산업** → **증시 상방** *(11:06)*.
- **이번 분쟁:** **영토 분쟁 아님**, **미 90일** 등 **장기화 어려움** *(14:14)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **조정:** **필수적 조정**으로 **과열 완화** *(13:33)*.
- **이후:** **산업 수요** → **2보 전진을 위한 1보 후퇴** 후 **강한 반등** *(13:33)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **리스크 오프** | 지정학 **프리미엄** 소진 |
| **재기동** | **방산·IT** 등 **CAPEX/수주** 재가동 서사 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**지속성이 낮은 리스크**는 **시장을 영구 하방**으로 두기보다 **변동성 이벤트**로 소진되고, **구조 수요(AI·방산)** 가 **다시 주도**한다는 **서사**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 역사 패턴 | **전쟁→산업→증시** | *(11:06)* |
| 구조 | **90일·비영토** | *(14:14)* |
| 조정 | **필수 조정** | *(13:33)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `War_Risk_Market_Correction_Recovery_Pattern` | `temporarily_pressures` | `Korea_Equity_Market` | `geopolitical_risk_off` |

---

<a id="backlinks"></a>

## 8. 역링크

- [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-korea-equity-ai-defense-war-flow-causality.md)

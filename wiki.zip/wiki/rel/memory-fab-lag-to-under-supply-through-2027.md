---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 증설·가동 시차 → 2027년까지 공급 부족 지속

**목적:** **수요 폭증** 대비 **공급 탄력(증설·가동)** 이 **느려** **2027년 전후**까지 **수요 초과**가 이어진다는 주장을 구조화한다.

**관련 개체:** [메모리 증설·2027 시차](../entity/memory-fab-capacity-lag-2027.md) · [삼성전자](../entity/samsung-electronics.md) · [마이크론](../entity/micron.md) · [국내 메모리 이익 전망 급상향](../entity/korea-memory-sector-earnings-forecast-surge.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Memory_Fab_Capacity_Lag_2027`** | 공급 지연 | [memory-fab-capacity-lag-2027.md](../entity/memory-fab-capacity-lag-2027.md) |
| **`Samsung_Electronics`** | 삼성전자(평택5·용인) | [samsung-electronics.md](../entity/samsung-electronics.md) |
| **`Micron`** | 마이크론(신규 케파) | [micron.md](../entity/micron.md) |
| **`Korea_Memory_Earnings_Forecast_Surge`** | 이익 전망 | [korea-memory-sector-earnings-forecast-surge.md](../entity/korea-memory-sector-earnings-forecast-surge.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **리드타임:** 공장 **증설**에 **최소 1년 이상** *(14:13)*.
- **의미 있는 케파 시점:** **삼성전자 평택 5·용인**, **마이크론 신규 케파**가 시장에 **본격 반영**되려면 **2027년 하반기** *(15:30)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **수급:** **그때까지** **공급이 수요를 따라가지 못함**이 **지속** *(14:13)*.
- **투자 전망:** **2027년 상반기**까지 **공급 부족·이익 성장**이 **보장된 환경**이라는 **총평형 메시지**와 연결(요약 말미).

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **CAPEX-to-wafer** | 투자→**클린룸·장비·수율 램프**까지 **시간 지연** |
| **동시 다발 증설** | 다수 파브가 **같은 연도 하반기**에 **가동**되며 **공급 곡선이 한꺼번에** 이동한다는 서술 |
| **가격** | **공급 제약**이 **ASP**에 **상방 압력** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**수요 측 폭증**은 **즉시** 반응하지만, **공급 측 증설**은 **물리적·공정적 리드타임** 때문에 **후행**한다. 따라서 **의미 있는 신규 케파**가 **집중 가동**되기 전까지는 **구조적 셰너지**가 남는다는 **인과 주장**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 리드타임 | **1년+** | *(14:13)* |
| 가동 | **2027 하반기** 의미 시점 | *(15:30)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Memory_Fab_Capacity_Lag_2027` | `sustains` | `Korea_Memory_Earnings_Forecast_Surge` | `tight_supply_to_margin` |

---

<a id="backlinks"></a>

## 8. 역링크

- [김장열 본부장](../entity/kim-jangyeol.md) · [DRAM 마진→전망](dram-margin-and-prices-to-earnings-forecast-surge.md) · [통합 메모](../kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md)

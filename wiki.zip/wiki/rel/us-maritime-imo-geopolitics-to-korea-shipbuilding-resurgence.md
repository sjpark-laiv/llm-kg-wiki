---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 미 해운 병목·IMO 규제·지정학 → 한국 조선업 구조적 재도약

**목적:** **미국**의 **선박 인프라 부족**, **IMO 환경 규제**, **미·중·안보**가 맞물려 **한국 조선**이 **신뢰 파트너**로 **선택될 수밖에 없는 구조**가 된다는 주장을 구조화한다.

**관련 개체:** [미 선박 건조·수리 부족](../entity/us-marine-shipbuilding-capacity-constraint.md) · [지정학·중국 조선 배제](../entity/geopolitics-china-shipyard-exclusion.md) · [IMO 교체 수요](../entity/imo-environmental-ship-replacement-demand.md) · [한국 조선 재도약](../entity/korea-shipbuilding-structural-resurgence.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`US_Marine_Shipbuilding_Capacity_Constraint`** | 미 해운 병목 | [us-marine-shipbuilding-capacity-constraint.md](../entity/us-marine-shipbuilding-capacity-constraint.md) |
| **`Geopolitics_China_Shipyard_Exclusion`** | 지정학 | [geopolitics-china-shipyard-exclusion.md](../entity/geopolitics-china-shipyard-exclusion.md) |
| **`IMO_Environmental_Ship_Replacement_Demand`** | IMO 교체 | [imo-environmental-ship-replacement-demand.md](../entity/imo-environmental-ship-replacement-demand.md) |
| **`Korea_Shipbuilding_Structural_Resurgence`** | 한국 조선 | [korea-shipbuilding-structural-resurgence.md](../entity/korea-shipbuilding-structural-resurgence.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **미 인프라:** **에너지 수출** 대비 **선박 건조·수리** 역량 **부족** *(01:11)*.
- **IMO:** **노후선→친환경선** **교체 수요 폭증** *(01:32)*.
- **안보·갈등:** **중국 해군** 대응 vs **중국 조선소 배제** *(01:46)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **파트너 구조:** 미국이 **신뢰 가능한 파트너**로 **한국 조선**을 **선택**할 수밖에 없다 *(01:53)*.
- **산업 전망:** **한국 조선업 강력한 재도약 근거** *(01:53)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **물리 병목** | **수출 실물 이동**에 **선박 공급**이 따라가지 못함 |
| **규제 드리븐 교체** | **IMO**가 **선박 수요 곡선**을 **상향 이동** |
| **신뢰·보안** | **지정학**이 **조선소 선택**을 **제한** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

세 축은 **독립적**이기보다 **강화 루프**를 만든다: **물리 부족**은 **수주 필요성**을 키우고, **규제**는 **교체 수요**를 키우며, **안보**는 **공급자 풀**을 **좁혀** **한국**의 **상대적 지위**를 올린다는 **합성 인과**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 미국 | **선박 건조·수리 부족** | *(01:11)* |
| IMO | **환경 규제·교체** | *(01:32)* |
| 안보 | **중국 배제** | *(01:46)* |
| 결론 | **한국 재도약** | *(01:53)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `US_Marine_Shipbuilding_Capacity_Constraint` | `supports` | `Korea_Shipbuilding_Structural_Resurgence` | `trusted_capacity` |
| `IMO_Environmental_Ship_Replacement_Demand` | `supports` | `Korea_Shipbuilding_Structural_Resurgence` | `replacement_orders` |
| `Geopolitics_China_Shipyard_Exclusion` | `supports` | `Korea_Shipbuilding_Structural_Resurgence` | `security_screening` |

---

<a id="backlinks"></a>

## 8. 역링크

- [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md)

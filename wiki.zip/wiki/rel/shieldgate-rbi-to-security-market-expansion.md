---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 실드게이트(SHIELD Gate) RBI 기술 → 금융·공공·민간 보안시장 확대

RCA·Impact 추론용 근거 문서. [실드게이트](../entity/shieldgate.md)가 [RBI](../entity/rbi-remote-browser-isolation.md) 기술을 기반으로 금융·공공·민간 보안 시장에서 지배력을 확대하는 인과관계를 구조화한다.

---

<a id="entity-table"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 정의(분석용) | 엔티티 문서 |
|-----------|-----------|-------------|-------------|
| `SHIELD_Gate` | 실드게이트 | RBI 기반 원천 차단 보안 솔루션 | [shieldgate.md](../entity/shieldgate.md) |
| `RBI` | 원격 브라우저 격리 | 원격 서버 웹 실행 + 화면 전송 | [rbi-remote-browser-isolation.md](../entity/rbi-remote-browser-isolation.md) |
| `Financial_Security_Mkt` | 금융보안시장 | 금융기관 대상 보안 솔루션 시장 | — |
| `Public_Security_Mkt` | 공공보안시장 | 정부·공공기관 대상 보안 시장 | — |
| `Private_Security_Mkt` | 민간보안시장 | 민간기업 대상 보안 시장 | — |
| `Net_Sep_Dereg` | 망분리 규제 완화 | 금융권 외부망 접속 단계적 허용 | [network-separation-deregulation-korea.md](../entity/network-separation-deregulation-korea.md) |

<a id="causality-map"></a>

## 2. Causality Map

| 단계 | 원인 | → | 결과 | 전달 유형 | 분석 태그 |
|------|------|---|------|-----------|-----------|
| 1차 | `SHIELD_Gate` RBI 기술력 | → | 로컬 무설치 + 화면전송 보안 구현 | 직접 | `RCA` |
| 1차 | `Net_Sep_Dereg` | → | 금융권 외부망 안전 접속 솔루션 수요 | 직접 | `RCA` |
| 2차 | 기술력 + 규제 적합성 | → | `Financial_Security_Mkt` 점유율 확대 | 간접 | `Impact` |
| 3차 | 금융권 레퍼런스 | → | `Public_Security_Mkt` 진입 가속 | 간접 | `Impact` |
| 3차 | 금융+공공 레퍼런스 | → | `Private_Security_Mkt` 확대 | 간접 | `Impact` |

<a id="edge-table"></a>

## 3. 그래프 엣지 표

| source | edge | target | mechanism_id |
|--------|------|--------|-------------|
| `SHIELD_Gate` | RBI 원천 차단 | `Financial_Security_Mkt` | `M1_rbi_financial` |
| `Net_Sep_Dereg` | 외부망 접속 허용 확대 | `Financial_Security_Mkt` | `M2_dereg_demand` |
| `SHIELD_Gate` | 물리적 이중화 대체 | `Financial_Security_Mkt` | `M3_cost_efficiency` |
| `SHIELD_Gate` | 금융 레퍼런스 확장 | `Public_Security_Mkt` | `M4_public_expansion` |
| `SHIELD_Gate` | RBI 수요 확산 | `Private_Security_Mkt` | `M5_private_expansion` |

<a id="root-cause"></a>

## 4. 원인·근원 (Root Cause)

- **기술 강점**: 별도 장비 없이 화면 전송만으로 기존 물리적 이중화 단말·가상 PC와 동일 효과 + 보안성 상위
- **규제 적합**: 로컬 PC에 무설치 → 금감원의 "외부 프로그램 설치 최소화" 규제와 정확히 부합
- **망분리 완화**: 금융권 AI·클라우드 접속 확대 → 안전한 외부망 접속 솔루션으로 실드게이트 채택

<a id="impact"></a>

## 5. 결과·영향 (Impact)

- [ ] **금융권 (주력)**: 망분리 규제 완화 맞물려 수요 급증 → 매출의 70.1%가 보안 솔루션
- [ ] **공공기관**: 금융권 레퍼런스 바탕으로 공공 보안 시장 확대
- [ ] **민간기업**: RBI 기반 보안 수요의 구조적 확산
- [ ] "미토스 사태는 이러한 전환의 결정적 촉매제" (밸류파인더)

<a id="evidence-data"></a>

## 6. Evidence

| 관측 사실 | 수치·근거 | 출처 |
|-----------|-----------|------|
| 보안 솔루션 매출 비중 | 전체의 70.1% (2025) | 밸류파인더 리포트 |
| 실드게이트 vs 기존 방식 | 물리적 이중화·가상PC와 동일 효과 + 보안성 상위 | 동일 |
| 시장 확장 경로 | 금융 → 공공 → 민간 | 동일 |

<a id="logic-framework"></a>

## 7. 논리 프레임워크

```mermaid
flowchart TD
    A[SHIELD Gate RBI 기술] --> B[로컬 무설치 + 화면전송]
    C[망분리 규제 완화] --> D[금융권 외부망 접속 수요]
    B --> E[금융보안시장 점유 확대]
    D --> E
    E --> F[공공보안시장 진입 가속]
    F --> G[민간보안시장 확산]
    style E fill:#fff3cd
    style F fill:#d4edda
    style G fill:#d4edda
```

<a id="backlinks"></a>

## 8. 역링크

- [실드게이트](../entity/shieldgate.md) · [RBI](../entity/rbi-remote-browser-isolation.md) · [소프트캠프](../entity/softcamp.md)
- [망분리 규제 완화](../entity/network-separation-deregulation-korea.md)
- [미토스 → 실드게이트 수요 급증](mythos-to-shieldgate-demand.md)
- [망분리 규제 완화 → 소프트캠프 실적 성장](network-separation-deregulation-to-softcamp-growth.md)
- [소프트캠프·실드게이트 AI 보안 전망 (주제 통합)](../softcamp-shieldgate-ai-security-outlook.md)

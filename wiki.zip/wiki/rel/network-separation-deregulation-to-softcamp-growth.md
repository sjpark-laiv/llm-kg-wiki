---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 망분리 규제 완화 → 소프트캠프 실적 성장 (턴어라운드)

RCA·Impact 추론용 근거 문서. [망분리 규제 완화](../entity/network-separation-deregulation-korea.md)가 [소프트캠프](../entity/softcamp.md)의 [실드게이트(SHIELD Gate)](../entity/shieldgate.md) 매출을 구조적으로 성장시키는 인과관계를 구조화한다.

---

<a id="entity-table"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 정의(분석용) | 엔티티 문서 |
|-----------|-----------|-------------|-------------|
| `Net_Sep_Dereg` | 망분리 규제 완화 | 금융권 외부망 접속 단계적 허용 | [network-separation-deregulation-korea.md](../entity/network-separation-deregulation-korea.md) |
| `Softcamp` | 소프트캠프 (258790) | RBI 보안 솔루션 기업 | [softcamp.md](../entity/softcamp.md) |
| `SHIELD_Gate` | 실드게이트 | RBI 기반 원천 차단 보안 솔루션 | [shieldgate.md](../entity/shieldgate.md) |
| `FSS` | 금융감독원 | 금융 감독 기관 | [fss-korea.md](../entity/fss-korea.md) |

<a id="causality-map"></a>

## 2. Causality Map

| 단계 | 원인 | → | 결과 | 전달 유형 | 분석 태그 |
|------|------|---|------|-----------|-----------|
| 1차 | `Net_Sep_Dereg` (규제 완화) | → | 금융권 외부망 접속 솔루션 수요 급증 | 직접 | `RCA` |
| 2차 | 외부망 접속 수요 | → | `SHIELD_Gate` 수주 확대 | 직접 | `Impact` |
| 3차 | `SHIELD_Gate` 수주 | → | `Softcamp` 매출 급증 + 흑자전환 | 직접 | `Impact` |
| 부가 | AI 클라우드 활용 필요성 | → | 망분리 완화 가속 | 간접 (양의 피드백) | `Evidence` |

<a id="edge-table"></a>

## 3. 그래프 엣지 표

| source | edge | target | mechanism_id |
|--------|------|--------|-------------|
| `Net_Sep_Dereg` | 외부망 접속 허용 확대 | `Financial_Sec_Demand` | `M1_dereg_demand` |
| `Financial_Sec_Demand` | RBI 솔루션 채택 | `SHIELD_Gate` | `M2_rbi_adoption` |
| `SHIELD_Gate` | 매출 확대 | `Softcamp` | `M3_revenue` |
| `AI_Cloud_Need` | 규제 완화 가속 | `Net_Sep_Dereg` | `M4_feedback_loop` |

<a id="root-cause"></a>

## 4. 원인·근원 (Root Cause)

- 국내 금융권은 외부망 접속이 엄격히 제한 → AI 클라우드 서비스 활용에 한계
- 최근 금융당국이 규제를 단계적 완화 → 안전한 외부망 접속 솔루션 수요 급증
- 실드게이트는 별도 장비 없이 화면 전송만으로 망분리 효과 유지 → 규제와 정확히 부합

<a id="impact"></a>

## 5. 결과·영향 (Impact)

- [ ] 소프트캠프 매출: 169억원(2024) → **257억원(2025)**, YoY +52%
- [ ] 영업이익: −18억원(2024) → **+30억원(2025)**, 완벽한 턴어라운드
- [ ] 보안 솔루션 매출 비중: 전체의 **70.1%** (2025)
- [ ] 금융권 → 공공 → 민간 확대 시 추가 실적 성장 기대

<a id="evidence-data"></a>

## 6. Evidence

| 지표 | 2024 | 2025 | 변화 | 출처 |
|------|------|------|------|------|
| 매출액 | 169억원 | 257억원 | +52% | 밸류파인더 |
| 영업이익 | −18억원 | +30억원 | 흑자전환 | 동일 |
| 보안 솔루션 비중 | — | 70.1% | — | 동일 |

<a id="logic-framework"></a>

## 7. 논리 프레임워크

```mermaid
flowchart TD
    A["금융권 AI·클라우드 활용 필요"] --> B[망분리 규제 완화]
    B --> C[외부망 접속 솔루션 수요 급증]
    C --> D[SHIELD Gate 수주 확대]
    D --> E["Softcamp 매출 257억 / 영업이익 30억"]
    E --> F[턴어라운드 성공]
    G[Mythos 사태] --> H[보안 강화 촉매]
    H --> C
```

<a id="backlinks"></a>

## 8. 역링크

- [망분리 규제 완화](../entity/network-separation-deregulation-korea.md) · [소프트캠프](../entity/softcamp.md) · [실드게이트](../entity/shieldgate.md) · [금융감독원](../entity/fss-korea.md)
- [실드게이트 RBI → 보안시장 확대](shieldgate-rbi-to-security-market-expansion.md)
- [미토스 → 실드게이트 수요 급증](mythos-to-shieldgate-demand.md)
- [소프트캠프·실드게이트 AI 보안 전망 (주제 통합)](../softcamp-shieldgate-ai-security-outlook.md)

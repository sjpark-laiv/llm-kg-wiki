---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 사모 대출 조정·부실 정리 → 은행 중심 대출 시장 재편

**목적:** **사모 대출** 스트레스가 **단기 충격**을 줄 수 있으나, **부실이 정리**되는 과정에서 **대출 시장**이 **은행 중심**으로 **재편**된다는 주장을 구조화한다.

**관련 개체:** [사모 대출 스트레스](../entity/private-credit-collateral-stress.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Private_Credit_Collateral_Stress`** | 사모대출 스트레스 | [private-credit-collateral-stress.md](../entity/private-credit-collateral-stress.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **신용 사건:** 담보·금리 스트레스로 **사모 신용** **조정** 압력 ([관련 인과](private-credit-yields-to-near-term-volatility-low-crisis-transmission.md)).

---

<a id="effect"></a>

## 3. 결과·영향

- **시장 재편:** **부실 정리**가 진행되며 **대출 시장**이 **은행 중심**으로 **돌아가는 계기** *(08:33)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **규제·감독** | **은행**은 **자본·공시**로 **리스크 가시성**이 상대적으로 높음 |
| **유동성 창구** | 스트레스 시 **중앙은행·은행**이 **최종 대출자** 역할 |
| **재중개** | 사모 시장 **축소**분이 **은행 대출**로 **재할당** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**사모 신용**의 **조정**은 **파이낸스의 탈은행화** 일부를 **되돌리는** 역할을 하여, **중기적으로** **은행 대출**의 **상대 비중**이 **회복**된다는 **구조 전환 서사**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 결과 | **은행 중심 재편** | *(08:33)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Private_Credit_Collateral_Stress` | `workout_rechannels_to` | `Bank_Centric_Loan_Market` | `delever_private_credit` |

> 노트: `Bank_Centric_Loan_Market`는 **관계 문서 내부 라벨**.

---

<a id="backlinks"></a>

## 8. 역링크

- [사모대출·금리·단기 변동성](private-credit-yields-to-near-term-volatility-low-crisis-transmission.md) · [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md)

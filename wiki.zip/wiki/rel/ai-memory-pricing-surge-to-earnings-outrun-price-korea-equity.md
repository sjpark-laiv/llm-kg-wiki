---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(이선엽 대표)
---

# 인과: AI·메모리 가격 급등 → 실적 전망이 주가보다 빠름 → 한국 증시 상방

**목적:** **AI 수요**와 **공급 부족**으로 **메모리 가격**이 급등하고, **실적 전망**이 **주가 상승**보다 빨라 **밸류**는 **저평가**라는 주장을 구조화한다.

**관련 개체:** [AI·메모리 가격 급등](../entity/ai-driven-memory-pricing-surge-korea.md) · [삼성전자](../entity/samsung-electronics.md) · [SK하이닉스](../entity/sk-hynix.md) · [한국 주식시장](../entity/korea-equity-market.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`AI_Driven_Memory_Pricing_Surge_Korea`** | 가격 급등 | [ai-driven-memory-pricing-surge-korea.md](../entity/ai-driven-memory-pricing-surge-korea.md) |
| **`Samsung_Electronics`** | 삼성전자 | [samsung-electronics.md](../entity/samsung-electronics.md) |
| **`SK_Hynix`** | SK하이닉스 | [sk-hynix.md](../entity/sk-hynix.md) |
| **`Korea_Equity_Market`** | 한국 증시 | [korea-equity-market.md](../entity/korea-equity-market.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **수요:** **AI**가 강세 **핵심 동력** *(08:05)*.
- **가격:** **월 50%+** 등 **고정가 급등** *(18:09)*.
- **구조:** **공급 부족** 대비 **AI 수요 기하급수** → **실적 전망**이 **주가보다 빠르게** 상향 *(19:29)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **밸류:** 주가는 비싸 보여도 **이익 대비** **저평가** *(19:29)*.
- **삼성전자:** **내년 세계에서 돈을 가장 많이 버는 기업** 가능성 **큼** → **증시 상승 견인** *(19:29)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **ASP→EPS** | **계약·고정가** 상승이 **이익 레버리지**로 전이 |
| **주가 대비 이익** | **컨센서스 상향 속도** > **주가 램프** → **forward 배수 압축** 서술 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**가격·수요**가 먼저 움직이고 **이익 추정**이 따라가며, **주가**는 상대적으로 **뒤처져** **밸류 갭**이 벌어진다는 **인과 주장**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| AI | **핵심 동력** | *(08:05)* |
| 가격 | **월 50%+** | *(18:09)* |
| 실적 vs 주가 | **전망이 더 빠름** | *(19:29)* |
| 총평 | **가격 < 실적 전망** | *(00:16)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `AI_Driven_Memory_Pricing_Surge_Korea` | `drives` | `Korea_Equity_Market` | `memory_earnings_engine` |

---

<a id="backlinks"></a>

## 8. 역링크

- [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-korea-equity-ai-defense-war-flow-causality.md)

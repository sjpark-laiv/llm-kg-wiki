---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 이익 강화 vs 저평가 괴리 → 한국 시장 비중·낙관 전망

**목적:** **반도체 사이클 관리 가능성**, **세계 최정상급 이익**, **저평가**가 결합되어 **한국 시장 선호**로 수렴한다는 **종합 서사**를 구조화한다.

**관련 개체:** [강관우 대표](../entity/kang-gwanwoo.md) · [한국 주식시장](../entity/korea-equity-market.md) · [미국 주식시장](../entity/us-equity-market.md) · [삼성전자](../entity/samsung-electronics.md) · [SK하이닉스](../entity/sk-hynix.md) · [메모리 이익(뉴 노멀)](../entity/memory-semiconductor-earnings-new-normal.md) · [ROE](../entity/roe.md) · [코스피 지수](../entity/kospi-index.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Kang_GwanWoo`** | 발화자 | [kang-gwanwoo.md](../entity/kang-gwanwoo.md) |
| **`Korea_Equity_Market`** | 한국 주식시장 | [korea-equity-market.md](../entity/korea-equity-market.md) |
| **`US_Equity_Market`** | 미국 주식시장 | [us-equity-market.md](../entity/us-equity-market.md) |
| **`Memory_Semiconductor_Earnings_NewNormal`** | 메모리 이익 | [memory-semiconductor-earnings-new-normal.md](../entity/memory-semiconductor-earnings-new-normal.md) |
| **`ROE_Korea_LargeCap_Context`** | ROE | [roe.md](../entity/roe.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **사이클:** **반도체 사이클**이 **관리 가능한 범위**에서 **연장** *(25:56)*.
- **이익 레벨:** 기업 **이익**이 **세계 최정상급**으로 상승 *(25:56)*.
- **가격:** 그럼에도 **주가는 저평가** 상태 유지 *(25:56)*.
- **거시 잡음:** **전쟁·금리 불확실성**은 **단기 변수**로 두되, **가치·가격 괴리** 활용을 권하는 톤 *(25:56)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **시장 선택:** **미국 vs 한국** 중 **한국**을 **단연** 선호 *(32:46 요약)*.
- **전략:** **강화된 이익(가치)** 와 **낮은 가격** 사이 **괴리**를 활용한 투자 유효 *(25:56)*.
- **전망 톤:** **코스피 6,000** 재도달 국면을 과거와 **근본적으로 다르게** 보며 **긍정 전망 유지** *(요약 도입)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 축 | 기제 |
|----|------|
| **실적** | **ROE·이익 스케일** 개선 → **내재가치 상향** |
| **밸류** | **저평가·메모리 할인** → **리레이팅 여력** ([관계 문서](memory-earnings-new-normal-to-equity-valuation-upside.md)) |
| **수급** | **외국인 기계적 매도 vs 개인·머니무브** ([관계 문서](foreign-mechanical-selling-to-domestic-bid-strength.md)) |
| **상대평가** | **일드 갭** ([관계 문서](korea-yield-gap-to-relative-equity-attractiveness.md)) |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

여러 **중간 원인**(이익 레짐·밸류 프레임·수급·상대 일드 갭)이 **합성**되어, **한국 주식시장**이 **글로벌 배분에서 우선순위가 높아져야 한다**는 **종합 인과 주장**으로 정리된다. **단기 리스크**에 휘둘리기보다 **가치 대비 가격 괴리**에 주목하라는 **행동 규범**으로 수렴한다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 사이클 | **관리 가능·연장** | *(25:56)* |
| 이익·가격 | **최정상급 이익** vs **저평가 주가** | *(25:56)* |
| 선택 | **한국 선호** | *(32:46)* |
| 투자 원칙 | **가치-가격 괴리** 활용 | *(25:56)* |

---

<a id="causality-map"></a>

## 7. 엣지 표 (합성)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Memory_Semiconductor_Earnings_NewNormal` | `supports` | `Korea_Equity_Market` | `sector_earnings_engine` |
| `ROE_Korea_LargeCap_Context` | `supports` | `Korea_Equity_Market` | `broad_quality` |
| `US_Equity_Market` | `contrasts_with` | `Korea_Equity_Market` | `pairwise_choice` |

---

<a id="backlinks"></a>

## 8. 역링크·하위 인과

- [ROE → 멀티플](roe-to-valuation-multiples-per-pbr.md)
- [고ROE·저PER(메모리) → 리레이팅](high-roe-low-per-cycle-frame-to-growth-rerating.md)
- [메모리 뉴 노멀 → 업사이드](memory-earnings-new-normal-to-equity-valuation-upside.md)
- [외국인 매도 → 국내 수급](foreign-mechanical-selling-to-domestic-bid-strength.md)
- [일드 갭 → 상대 매력](korea-yield-gap-to-relative-equity-attractiveness.md)

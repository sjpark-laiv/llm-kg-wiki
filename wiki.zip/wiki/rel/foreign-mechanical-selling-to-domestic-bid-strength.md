---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 외국인 기계적 매도 → 국내 수급(개인·머니무브) 강화

**목적:** **외국인 매도**를 **펀더멘털 악화**가 아닌 **지수 비중 조절**로 해석하고, 그 **물량**이 **개인·머니무브**로 **흡수**되어 **시장 수급 기반**이 강화된다는 주장을 구조화한다.

**관련 개체:** [MSCI 이머징 마켓](../entity/msci-emerging-markets.md) · [외국인 기계적 매도](../entity/foreign-investor-mechanical-selling.md) · [개인 집단지성 수급](../entity/retail-investor-collective-bid.md) · [머니무브](../entity/money-move-deposits-to-equities.md) · [한국 주식시장](../entity/korea-equity-market.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`MSCI_EmergingMarkets_Index`** | MSCI EM | [msci-emerging-markets.md](../entity/msci-emerging-markets.md) |
| **`Foreign_Investor_Mechanical_Selling`** | 외국인 기계적 매도 | [foreign-investor-mechanical-selling.md](../entity/foreign-investor-mechanical-selling.md) |
| **`Retail_Investor_Collective_Bid`** | 개인 집단지성 매수 | [retail-investor-collective-bid.md](../entity/retail-investor-collective-bid.md) |
| **`Money_Move_Deposits_to_Equities`** | 머니무브 | [money-move-deposits-to-equities.md](../entity/money-move-deposits-to-equities.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **비중 과대:** **MSCI 이머징 마켓** 내 **한국 비중**이 **지나치게 커짐** *(17:44)*.
- **기계적 조절:** **잔디 깎기식** **비중 조절** 성격 → **펀더멘털** 문제와 **분리** *(17:44)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **개인 흡수:** 외국인 **매도 물량**을 **개인**이 **집단지성**으로 **받아냄** *(17:36 요약)*.
- **머니무브:** **예금→주식** 이동이 **본격화** → **시장 떠받침** 수급 *(13:58)*.
- **시장 전체:** **수급 기반**이 **탄탄**해졌다는 총평 *(13:58)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 단계 | 기제 |
|------|------|
| 1 | **지수 규칙·한도** → **패시브 매도** 유발 |
| 2 | **가격 조정** → **개인 순매수**가 **유동성 공급** |
| 3 | **금리·기대수익** 맥락에서 **예금 이탈→주식 유입**이 **매수 재원** 확대 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**상위 원인**은 **한국 비중 과대**로 인한 **지수 레벨의 기계적 매도 압력**이고, **전달**은 **외국인 순매도** 형태로 나타나며, **결과**는 동일 물량을 **개인**이 **흡수**하고 **머니무브**가 **가속**되면서 **국내 쪽 수급 곡선**이 **시장 하방을 지지**한다는 **서사**로 정리된다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 매도 성격 | **MSCI EM** 비중·**기계적 조절** | *(17:44)* |
| 개인 | **집단지성**으로 **매도 흡수** | *(17:36)* |
| 자금 이동 | **머니무브** 본격화 | *(13:58)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `MSCI_EmergingMarkets_Index` | `triggers_rebalance` | `Foreign_Investor_Mechanical_Selling` | `em_weight_cap` |
| `Foreign_Investor_Mechanical_Selling` | `absorbed_by` | `Retail_Investor_Collective_Bid` | `flow_handoff` |
| `Money_Move_Deposits_to_Equities` | `reinforces` | `Retail_Investor_Collective_Bid` | `funding_source` |

---

<a id="backlinks"></a>

## 8. 역링크

- [강관우 대표](../entity/kang-gwanwoo.md) · [한국 주식시장](../entity/korea-equity-market.md)

---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 인과: AI 데이터센터 전력 부족 → 선박 엔진 대체 수요 → 조선사 이익 상향

**목적:** AI 인프라 확대 과정의 **전력 병목**이 선박 엔진 수요로 전이되고, 이를 통해 조선·엔진 계열사의 실적 기대가 높아지는 경로를 RCA·Impact 근거로 구조화한다.

**관련 개체:** [데이터센터 전력용 선박 엔진](../entity/marine-engine-for-datacenter-power.md) · [한국 조선업 구조적 재도약](../entity/korea-shipbuilding-structural-resurgence.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`AI_Infrastructure_Capex_Cycle`** | AI 인프라 투자 확대 | [ai-infrastructure-capex-cycle.md](../entity/ai-infrastructure-capex-cycle.md) |
| **`Datacenter_Power_Gap`** | 데이터센터 전력 부족 | [marine-engine-for-datacenter-power.md](../entity/marine-engine-for-datacenter-power.md) |
| **`Marine_Engine_for_Datacenter_Power`** | 선박 엔진 전원 대안 | [marine-engine-for-datacenter-power.md](../entity/marine-engine-for-datacenter-power.md) |
| **`Korea_Shipbuilding_Structural_Resurgence`** | 한국 조선 수혜 | [korea-shipbuilding-structural-resurgence.md](../entity/korea-shipbuilding-structural-resurgence.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **AI 인프라 증설:** 데이터센터 증설 속도가 전력 인프라 확장을 앞지르는 구간이 발생한다는 전제 *(28:39)*.
- **전력 병목 대응:** 비상 발전·분산 전원 맥락에서 선박용 엔진의 대체 활용 가능성이 부각된다는 주장 *(28:39)*.

---

<a id="impact"></a>

## 3. 결과·영향

- **수요 전이:** 엔진 제작 역량 보유 조선사·계열사의 신규 수요가 확대될 수 있다.
- **실적 상향:** 엔진 수주 증가가 조선 섹터의 이익 추정치 상방 요인으로 작동한다는 시나리오 *(29:27)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 | 분석 태그 |
|------|------|-----------|
| 전력 병목 전이 | AI 투자 급증이 전력 공급 제약으로 변환 | `RCA` |
| 대체 전원 채택 | 선박 엔진의 산업 외 수요 확대 | `Impact` |
| 수주-이익 연결 | 엔진 주문 증가가 실적 기대를 상향 | `Evidence` |

---

<a id="causality-map"></a>

## 5. Causality map (엣지 표)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `AI_Infrastructure_Capex_Cycle` | `creates` | `Datacenter_Power_Gap` | `power_bottleneck` |
| `Datacenter_Power_Gap` | `raises_demand_for` | `Marine_Engine_for_Datacenter_Power` | `backup_generation` |
| `Marine_Engine_for_Datacenter_Power` | `supports` | `Korea_Shipbuilding_Structural_Resurgence` | `engine_order_flow` |

---

<a id="logic-framework"></a>

## 6. 논리 프레임워크

```text
IF AI_Infrastructure_Capex_Cycle accelerates
THEN Datacenter_Power_Gap increases.
IF Datacenter_Power_Gap persists
THEN demand for Marine_Engine_for_Datacenter_Power rises.
IF engine demand rises
THEN Korea_Shipbuilding_Structural_Resurgence earnings narrative strengthens.
```

---

<a id="evidence-data"></a>

## 7. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 전력 병목 | AI 데이터센터 전력 부족 서술 | *(28:39)* |
| 엔진 대안 | 선박 엔진의 전력 활용 맥락 | *(28:39)* |
| 수혜 사례 | 현대중공업 엔진 언급 | *(29:27)* |

---

<a id="backlinks"></a>

## 8. 역링크

- [염승환 이사](../entity/yeom-seunghwan.md)
- [주제 통합: 염승환 2026 코스피·조선](../yeom-seunghwan-2026-kospi-8500-shipbuilding-thesis-causality.md)

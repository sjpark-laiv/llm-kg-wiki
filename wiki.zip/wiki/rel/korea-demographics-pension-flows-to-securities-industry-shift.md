---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 인구·연금 갭·사적연금·401k 유비·자금이동 → 증권·자본시장 위상·산업 재편

**목적:** **저출산·고령화**로 **국민연금 한계**가 드러나고 **사적 연금**이 커지며, **미국 401k 사례**와 **부동산→주식** 이동이 **증권/자본시장 중심** 재편으로 이어진다는 주장을 구조화한다.

**관련 개체:** [연금 갭](../entity/korea-demographics-pension-gap.md) · [사적 연금 시장](../entity/korea-private-pension-market-growth.md) · [401k 선행](../entity/us-401k-equity-shift-precedent.md) · [부동산→주식](../entity/capital-flow-real-estate-to-equities-korea.md) · [증권·자본시장 위상](../entity/korea-securities-capital-markets-ascendance.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Korea_Demographics_Pension_Gap`** | 연금 갭 | [korea-demographics-pension-gap.md](../entity/korea-demographics-pension-gap.md) |
| **`Korea_Private_Pension_Market_Growth`** | 사적 연금 | [korea-private-pension-market-growth.md](../entity/korea-private-pension-market-growth.md) |
| **`US_401k_Equity_Shift_Precedent`** | 401k 선행 | [us-401k-equity-shift-precedent.md](../entity/us-401k-equity-shift-precedent.md) |
| **`Capital_Flow_RealEstate_To_Equities_Korea`** | 부동산→주식 | [capital-flow-real-estate-to-equities-korea.md](../entity/capital-flow-real-estate-to-equities-korea.md) |
| **`Korea_Securities_Capital_Markets_Ascendance`** | 증권·자본시장 | [korea-securities-capital-markets-ascendance.md](../entity/korea-securities-capital-markets-ascendance.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **인구:** **국민연금만으로 노후 불가** *(03:33)*.
- **제도 수요:** **퇴직·사적 연금** 시장 확대 *(03:33)*.
- **역사 유비:** **1980년대 미국** **퇴직연금 주식 비중** 상향·**증시 호황** *(03:50)*.
- **자금 배분:** **부동산→주식(자본시장)** 이동 *(03:02)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **은행→증권:** **은행 중심**에서 **증권/자본시장** 중심 **재편** *(03:02)*.
- **산업 구조:** **증권업 위상** 상승과 **구조 변화** 전망 *(03:02)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **적립금 증가** | **DC/IRP** 등이 **장기 주식 수요**를 형성 |
| **자산 재평가** | **실물(부동산)** 대비 **금융자산(주식)** **기대수익·유동성** 비교 |
| **제도 모방** | **미국 사례**가 **정책·시장 논의**의 **템플릿** |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**노후 자금의 공백**이 **사적 연금**으로 **이전**되고, **부동산 쏠림**이 **완화**되며 **주식 시장**이 **자본 형성의 허브**로 이동한다. 이 과정에서 **은행 중심 금융**보다 **시장 중개·운용(증권·자본시장)** 의 **상대적 비중**이 커진다는 **인과**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 연금 | **국민연금 한계** | *(03:33)* |
| 사적연금 | 시장 **확대** | *(03:33)* |
| 미국 | **401k** 모델 | *(03:50)* |
| 자금 | **부동산→주식** | *(03:02)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Korea_Demographics_Pension_Gap` | `drives` | `Korea_Private_Pension_Market_Growth` | `funding_gap` |
| `US_401k_Equity_Shift_Precedent` | `templates` | `Korea_Securities_Capital_Markets_Ascendance` | `historical_parallel` |
| `Capital_Flow_RealEstate_To_Equities_Korea` | `reweights` | `Korea_Securities_Capital_Markets_Ascendance` | `allocation_shift` |

---

<a id="backlinks"></a>

## 8. 역링크

- [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md) · [머니무브](../entity/money-move-deposits-to-equities.md) (유사 주제, **다른 화자**)

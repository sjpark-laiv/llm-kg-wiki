---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: AI 특이점·광범위 인프라 투자 → 실체 강세·장기 섹터 우상향

**목적:** **AI**가 **닷컴 버블**과 달리 **투입 대비 성능·효율**이 **확실**하고, **GPU·메모리·데이터센터·전력**까지 **케이펙스**가 **광범위**하다는 주장을 구조화한다.

**관련 개체:** [AI 투자 특이점](../entity/ai-investment-performance-singularity.md) · [AI 인프라 CAPEX](../entity/ai-infrastructure-capex-cycle.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`AI_Investment_Performance_Singularity`** | AI 특이점 | [ai-investment-performance-singularity.md](../entity/ai-investment-performance-singularity.md) |
| **`AI_Infrastructure_Capex_Cycle`** | AI 인프라 | [ai-infrastructure-capex-cycle.md](../entity/ai-infrastructure-capex-cycle.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **특이점 논리:** 투입이 커질수록 **성능·효율**이 **기하급수적으로** 개선 *(04:44)*.
- **인프라 폭:** **엔비디아(GPU)·메모리·데이터센터·전력 기기**까지 **동반 투자** *(05:14)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **버블 논박:** **과거 닷컴**과 **다른 실체 있는 강세장** *(02:23)*.
- **산업 전망:** **반도체**, **메모리 효율화 관련 전기/전자**, **전력/에너지**의 **장기 우상향** *(02:23)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **스케일 법칙** | **모델·데이터·컴퓨트** 투입이 **출력 품질**에 **비선형** 기여한다는 서사 |
| **파급 CAPEX** | **반도체→전력→부동산(DC)** 로 **고정투자**가 **산업 광역**에 퍼짐 |
| **자본 생산성** | **비용**이 **즉시 소비**가 아니라 **생산 가능성**을 높인다는 프레임 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**확률적 유행**이 아니라 **투입-산출 관계가 관측 가능한 국면**이며, **공급망 깊이**가 넓어 **단일 테마주**로 끝나지 않는다는 점에서 **장기 섹터 강세**로 연결된다는 **인과 주장**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 특이점 | 투입↑ **성능·효율** | *(04:44)* |
| 인프라 | **GPU·메모리·DC·전력** | *(05:14)* |
| 비교 | **닷컴과 상이** | *(02:23)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `AI_Investment_Performance_Singularity` | `supports` | `Productive_LongCycle_Sectors` | `scaling_returns` |
| `AI_Infrastructure_Capex_Cycle` | `broadens` | `Productive_LongCycle_Sectors` | `multi_industry_capex` |

> 노트: `Productive_LongCycle_Sectors`는 **요약상 수혜 산업군**을 가리키는 **관계 문서 내부 라벨**.

---

<a id="backlinks"></a>

## 8. 역링크

- [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md)

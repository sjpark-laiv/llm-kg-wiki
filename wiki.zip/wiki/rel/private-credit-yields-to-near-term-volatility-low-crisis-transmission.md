---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 사모 대출 담보 이슈·고금리 → 단기 충격 가능·체계적 금융위기 전이는 낮음

**목적:** **사모 대출**의 **담보 적정성** 문제와 **미 10년 금리 4.5%+** 가 **단기 변동성**을 키울 수 있으나, **서브프라임** 대비 **레버리지가 낮아** **금융위기로 전이될 가능성은 낮다**는 주장을 구조화한다.

**관련 개체:** [사모 대출 스트레스](../entity/private-credit-collateral-stress.md) · [美 10년 국채 임계](../entity/us-treasury-10y-yield-stress-threshold.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Private_Credit_Collateral_Stress`** | 사모대출 담보 | [private-credit-collateral-stress.md](../entity/private-credit-collateral-stress.md) |
| **`US_Treasury_10Y_Yield_Stress_Threshold`** | 10Y 금리 | [us-treasury-10y-yield-stress-threshold.md](../entity/us-treasury-10y-yield-stress-threshold.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **담보:** **비상장 SW** 등 **담보 적정성** 문제 제기 *(06:21)*.
- **금리:** **미 10년 4.5% 이상** 시 **리스크 발현** 가능 *(07:03)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **단기:** **시장 충격(위기)** 가능성 *(08:00)* (요약은 **단기 변동성** 톤).
- **체계 위기:** **과거 서브프라임**과 달리 **레버리지 낮음** → **금융위기 전이 가능성 낮음** *(08:00)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **금리 민감** | **사모 신용**은 **플로팅·단기** 구조와 맞물려 **금리 급등**에 취약 |
| **담보 재평가** | **비유동 자산** **마킹**이 **신용 사건**을 촉발 |
| **전이 차단** | **은행 부실 규모·레버리지**가 **서브프라임 국면**보다 **제한적**이라는 서술 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**사모 신용**은 **고금리·담보 불확실성**으로 **부문 조정**을 일으킬 수 있으나, **시스템 전체의 레버리지 체인**이 **2000년대 서브프라임**만큼 **두껍지 않다**는 **비교 인과**이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 담보 | **비상장 SW** 등 | *(06:21)* |
| 금리 | **10년 4.5%+** | *(07:03)* |
| 전이 | **레버리지 낮음** | *(08:00)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Private_Credit_Collateral_Stress` | `can_trigger` | `Near_Term_Market_Volatility` | `credit_event` |
| `US_Treasury_10Y_Yield_Stress_Threshold` | `amplifies` | `Near_Term_Market_Volatility` | `discount_rate_shock` |
| `Near_Term_Market_Volatility` | `low_likelihood_to_become` | `Systemic_Financial_Crisis` | `lower_leverage_vs_subprime` |

> 노트: `Near_Term_Market_Volatility`, `Systemic_Financial_Crisis`는 **관계 문서 내부 라벨**.

---

<a id="backlinks"></a>

## 8. 역링크

- [사모대출 조정→은행 중심](private-credit-workout-to-bank-centric-loan-market.md) · [이선엽 대표](../entity/lee-sunyeop.md) · [통합 메모](../lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md)

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 인과: 이익 전망 급상향 vs 주가 상승폭 → 한국 메모리 대형주 저평가·목표가·선호순위

**목적:** **이익 전망 상향**에 비해 **주가 상승폭**이 **상대적으로 작다**는 **저평가** 논리와 **목표주가**, **Top Pick** 서열, **단기 리스크(소부장)** 를 한 흐름으로 구조화한다.

**관련 개체:** [국내 메모리 이익 전망 급상향](../entity/korea-memory-sector-earnings-forecast-surge.md) · [삼성전자](../entity/samsung-electronics.md) · [SK하이닉스](../entity/sk-hynix.md) · [마이크론](../entity/micron.md) · [샌디스크](../entity/sandisk.md) · [국내 소부장](../entity/korea-sme-parts-sector.md)

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 개체 문서 |
|-----------|-----------|-----------|
| **`Korea_Memory_Earnings_Forecast_Surge`** | 이익 전망 급상향 | [korea-memory-sector-earnings-forecast-surge.md](../entity/korea-memory-sector-earnings-forecast-surge.md) |
| **`Samsung_Electronics`** | 삼성전자 | [samsung-electronics.md](../entity/samsung-electronics.md) |
| **`SK_Hynix`** | SK하이닉스 | [sk-hynix.md](../entity/sk-hynix.md) |
| **`Micron`** | 마이크론 | [micron.md](../entity/micron.md) |
| **`Sandisk`** | 샌디스크 | [sandisk.md](../entity/sandisk.md) |
| **`Korea_SME_Parts_Sector`** | 소부장 | [korea-sme-parts-sector.md](../entity/korea-sme-parts-sector.md) |

---

<a id="cause"></a>

## 2. 원인·근원

- **이익 변수:** **전망치 급상향**(앞선 인과와 연결).
- **가격 변수:** 주가는 **체감상 많이 올랐으나**, **이익 전망 상승분 대비** **주가는 약 2배** 수준에 그쳤다는 **상대평가** *(18:45)*.

---

<a id="effect"></a>

## 3. 결과·영향

- **저평가 진단:** 위 대비로 **여전히 저평가** *(18:45)*.
- **목표주가(보수 시나리오):** **내년 이익 감소**를 가정해도 **삼성전자 25~29만 원**, **SK하이닉스 180만 원 이상** *(20:23)*, *(27:32)*.
- **투자 메시지:** **“지금 사도 늦지 않았다”** *(요약·18:45 근처)*.
- **선호순위:** **SK하이닉스 Top Pick**, **삼성전자**가 **바짝 추격**, **마이크론·샌디스크**보다 **한국 2사**가 **기술·이익 체력** 우위 *(43:44)*, *(44:14)*.
- **주의:** **소부장**은 **실적 시즌 차익 실현** 가능 *(26:20)* — 그러나 **대형 메모리**는 **내년까지 방향성 확고**, **“지금 팔아서는 안 된다”** *(48:07)*.

---

<a id="mechanism"></a>

## 4. 전달 기제

| 기제 | 설명 |
|------|------|
| **이익 대비 배수** | **EPS 상향** 속 **주가 탄력**이 **상대적으로 낮음** → **forward 밸류** 유리 |
| **시나리오 밴드** | **보수적 이익**에도 **목표가 레인지** 산출 |
| **섹터 내 순위** | **HBM/메모리 포지션**·**이익 체력** 기준 **선호 재배치** |
| **수급·테마** | **소부장**은 **이벤트성 매물** 가능, **대형주**는 **추세** 강조 |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명

**이익 곡선**이 **주가보다 빠르게** 올라가면, 동일 주가라도 **밸류**는 **저평가**로 **수렴**한다. **보수 시나리오**에서도 **목표가**가 **현재가 대비 크게 남아** **매수 유효**라는 논리이며, **종목 선택**은 **기술·이익 포지션**으로 **한국 2사**에 **쏠린다**는 주장이다.

---

<a id="evidence"></a>

## 6. Evidence

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 상대 상승 | 이익 대비 주가 **~2배** | *(18:45)* |
| 삼성 목표가 | **25~29만 원** (보수) | *(20:23)* |
| 하이닉스 목표가 | **180만 원+** | *(27:32)* |
| Top Pick | **SK하이닉스** | *(43:44)* |
| 비교 | **마이크론·샌디스크**보다 **한국 2사** | *(44:14)* |
| 리스크 | **소부장** 차익 실현 가능 | *(26:20)* |
| 결론 | **대형 메모리 지금 매도 비추** | *(48:07)* |

---

<a id="causality-map"></a>

## 7. 엣지 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Korea_Memory_Earnings_Forecast_Surge` | `outpaces` | `Memory_LargeCap_PriceMove` | `eps_faster_than_price` |
| `Memory_LargeCap_PriceMove` | `implies_undervaluation_for` | `Samsung_Electronics` | `forward_valuation_gap` |
| `Memory_LargeCap_PriceMove` | `implies_undervaluation_for` | `SK_Hynix` | `forward_valuation_gap` |

> 노트: `Memory_LargeCap_PriceMove`는 **주가 변화**를 가리키는 **관계 문서 내부 라벨**.

---

<a id="backlinks"></a>

## 8. 역링크

- [고ROE·저PER 리레이팅](high-roe-low-per-cycle-frame-to-growth-rerating.md) · [김장열 본부장](../entity/kim-jangyeol.md) · [통합 메모](../kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md)

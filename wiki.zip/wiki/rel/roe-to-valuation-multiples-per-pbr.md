---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(타임코드는 요약 인용)
---

# 인과: ROE(자기자본이익률) → PER·PBR 멀티플 재평가 근거

**목적:** 영상 요약에서 제시된 **수익성(ROE) 개선**이 **밸류에이션 멀티플** 재평가로 **전달**된다는 주장을 **RCA·Impact**용으로 구조화한다. 개체 파일: [**ROE**](../entity/roe.md), [**PER·PBR 멀티플**](../entity/valuation-multiples-per-pbr.md).

---

<a id="entities"></a>

## 1. Entity 정의 표

| Entity ID | 한글·설명 | 정의(분석용) | 개체 문서 |
|-----------|-----------|---------------|-----------|
| **`ROE_Korea_LargeCap_Context`** | ROE | 자기자본 대비 이익률. 과거 13~14% → 현재 20~25% 서술. | [roe.md](../entity/roe.md) |
| **`Valuation_Multiples_PER_PBR`** | PER·PBR | 주가 대비 이익·순자산 배수. | [valuation-multiples-per-pbr.md](../entity/valuation-multiples-per-pbr.md) |
| **`KOSPI_Index`** | 코스피 지수 | 6,000 부근 국면 비교의 지수 레벨. | [kospi-index.md](../entity/kospi-index.md) |
| **`Samsung_Electronics`** | 삼성전자 | 영업이익 스케일(약 57조 원 언급) 등 이익 체력 사례. | [samsung-electronics.md](../entity/samsung-electronics.md) |

---

<a id="cause"></a>

## 2. 원인·근원 (Root / driver)

- **ROE 수준의 구조적 상승:** 과거 코스피 **6,000** 시절 **13~14%** 대비 현재 **20~25%** *(01:31)*.
- **기업 이익 체력 사례:** **삼성전자** 영업이익이 **컨센서스를 크게 상회**하는 **약 57조 원** 규모로 거론 *(01:42)*.
- **해석 프레임:** ROE가 **20%대**에 진입하면 **효율성·수익성**이 과거와 **다른 단계**라는 인식 *(02:30)*.

---

<a id="effect"></a>

## 3. 결과·영향 (Impact)

- **멀티플 정당화:** 동일한 이익 스케일을 전제할 때 **PER·PBR**이 과거보다 **더 높게** 매겨져야 할 **논리적 근거**가 생긴다는 주장 *(02:30)*.
- **시장 전망:** **코스피** 재방문 국면이 과거와 **근본적으로 다르다**는 서사의 한 축 *(01:31 맥락)*.

---

<a id="mechanism"></a>

## 4. 전달 기제 (Transmission)

| 경로 | 기제 | 태그 |
|------|------|------|
| **이익률 → 배수** | ROE 상승이 **자본 효율·지속 이익** 신호로 읽혀 **요구수익률·성장 프리미엄** 논의로 연결 | `RCA` |
| **이익 → PBR** | 높은 ROE는 **PBR** 재평가(순자산 대비 주가)와 직접 연결되기 쉬움 | `Impact` |
| **이익 → PER** | 이익 레벨·지속성 기대가 **PER** 논의로 연결 | `Impact` |

---

<a id="causality-statement"></a>

## 5. 인과관계 설명 (요약 주장)

**ROE**가 **두 자릿수를 넘어 20%대**에 들어갔다는 사실은, 기업 **효율성·수익성**이 과거와 **다른 레짐**에 진입했음을 의미하고, 이는 **PER·PBR** 등 **멀티플**이 과거 대비 **더 높게** 측정될 **정당한 근거**가 된다는 **논리적 연결**이 제시된다 *(02:30)*.

---

<a id="evidence"></a>

## 6. Evidence (영상 요약에 명시된 관측)

| 지표·관측 | 내용 | 타임코드(요약) |
|-----------|------|----------------|
| ROE (과거) | 코스피 6,000 시절 **13~14%** | *(01:31)* |
| ROE (현재) | **20~25%** | *(01:31)* |
| 삼성전자 영업이익 | **약 57조 원**, 예상 **대폭 상회** | *(01:42)* |
| 멀티플 논증 | **PER·PBR**이 과거보다 **높게** 정당화 | *(02:30)* |

---

<a id="causality-map"></a>

## 7. Causality map·엣지 표

### 7.1 Causality map

| 구분 | 인과 기제 | 세부 |
|------|------------|------|
| 직접 | ROE 레벨 상승 | 자본 효율·이익률 레짐 변화 서술 |
| 간접 | 대표 기업 이익 스케일 | ROE 논증의 **사례 증거** |

### 7.2 Edge 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `ROE_Korea_LargeCap_Context` | `justifies_higher` | `Valuation_Multiples_PER_PBR` | `roe_to_multiple_fairness` |
| `Samsung_Electronics` | `exemplifies` | `ROE_Korea_LargeCap_Context` | `earnings_surprise_scale` |

---

<a id="backlinks"></a>

## 8. 역링크·교차 참조

- 발화자: [강관우 대표](../entity/kang-gwanwoo.md)
- 시장 허브: [한국 주식시장](../entity/korea-equity-market.md), [코스피 지수](../entity/kospi-index.md)
- 상위 요약: [이익·저평가 괴리 → 한국 비중](earnings-valuation-gap-to-korea-overweight-thesis.md)
- **메모리·고ROE 축(별도 표본):** [메모리 ROE·PER 괴리](../entity/memory-equity-high-roe-low-per.md) · [고ROE·저PER → 리레이팅](high-roe-low-per-cycle-frame-to-growth-rerating.md)

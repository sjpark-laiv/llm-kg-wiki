---

## wiki_created: 2026-04-23
content_as_of: 2026-04-20

# 소프트캠프·실드게이트 — AI 보안 위협 시대의 구조적 성장 전망

[밸류파인더](entity/valuefinder-research.md)([이충헌](entity/lee-chung-hun.md) 대표) 리서치(2026-04-20) 기반. 출처: 프라임경제. [앤스로픽](entity/anthropic.md)의 AI 보안 에이전트 [미토스(Mythos)](entity/mythos-ai-agent.md) 등장으로 촉발된 보안 패러다임 전환과, [소프트캠프(258790)](entity/softcamp.md)의 [실드게이트(SHIELD Gate)](entity/shieldgate.md)가 구조적 수혜를 받는 전망을 정리한다.

---



## 1. 이벤트 요약: 미토스 사태

- [앤스로픽](entity/anthropic.md)이 AI 보안 에이전트 **[미토스(Mythos)](entity/mythos-ai-agent.md)**를 공개
- 27년간 검증된 [OpenBSD](entity/openbsd.md) 취약점을 **단 몇 분 만에** 발견, 리눅스 서버 장악 경로 자율 설계
- [EDR](entity/edr-endpoint-security.md) 등 **로컬 설치형 보안 체계의 구조적 한계** 노출
- → [금융감독원](entity/fss-korea.md) 금융기관 보안실무자 긴급 소집 / [과기정통부](entity/msit-korea.md) CISO 긴급회의

> 상세: [미토스 → 기존 보안체계 위기](rel/mythos-to-legacy-security-crisis.md), [미토스 → 금융당국 규제 대응](rel/mythos-to-regulatory-response.md)



## 2. 실드게이트의 대응 기술

[실드게이트(SHIELD Gate)](entity/shieldgate.md)는 [RBI(원격 브라우저 격리)](entity/rbi-remote-browser-isolation.md) 방식 보안 솔루션:

- **원격 서버에서 웹 작업 수행** → 로컬 PC에는 **화면만 전송**
- 로컬 PC에 아무것도 설치하지 않음 → **공격 경로 자체가 존재하지 않음**
- 별도 장비 없이 기존 물리적 이중화 단말·가상 PC와 동일한 효과 + 보안성 상위
- 이충헌 밸류파인더 대표: "침입 자체를 원천 차단하는 **사전적 방어**가 가능"

> 상세: [미토스 → 실드게이트 수요 급증](rel/mythos-to-shieldgate-demand.md)



## 3. 제품별 시장 영향력


| 제품                                   | 타겟 시장           | 영향력                               | 관계 문서                                                                 |
| ------------------------------------ | --------------- | --------------------------------- | --------------------------------------------------------------------- |
| **[실드게이트](entity/shieldgate.md)**    | **금융보안시장**      | 매우 높음 — 망분리 규제 완화 직접 수혜, 매출 70.1% | [실드게이트 → 보안시장 확대](rel/shieldgate-rbi-to-security-market-expansion.md) |
| **[실드게이트](entity/shieldgate.md)**    | **공공보안시장**      | 높음 — 금융 레퍼런스로 확대                  | [실드게이트 → 보안시장 확대](rel/shieldgate-rbi-to-security-market-expansion.md) |
| **[실드게이트](entity/shieldgate.md)**    | **민간보안시장**      | 성장 잠재력 큼 — RBI 수요 확산              | [실드게이트 → 보안시장 확대](rel/shieldgate-rbi-to-security-market-expansion.md) |
| **[미토스](entity/mythos-ai-agent.md)** | **로컬 설치형 보안시장** | 파괴적 — EDR 등 기존 체계 무력화             | [미토스 → 기존 보안체계 위기](rel/mythos-to-legacy-security-crisis.md)           |




## 4. 성장 동인: 규제 + 기술 복합

1. **[망분리 규제 완화](entity/network-separation-deregulation-korea.md)**: 금융권 AI·클라우드 접속 허용 확대 → 안전한 외부망 접속 솔루션 수요 급증
2. **미토스 사태**: 로컬 보안 한계 입증 → RBI 방식 원천 차단 기술 부각
3. **금감원 규제 방향**: 로컬 PC 외부 프로그램 설치 최소화 → 실드게이트와 정확히 부합

> 상세: [망분리 규제 완화 → 소프트캠프 실적 성장](rel/network-separation-deregulation-to-softcamp-growth.md)



## 5. 실적 (밸류파인더 기준)


| 지표        | 2024  | 2025  | 변화       |
| --------- | ----- | ----- | -------- |
| 매출액       | 169억원 | 257억원 | **+52%** |
| 영업이익      | −18억원 | +30억원 | **흑자전환** |
| 보안 솔루션 비중 | —     | 70.1% | —        |




## 6. 전망

- 금융권뿐 아니라 **공공 및 민간 시장**에서도 RBI 기반 보안 수요 확대
- 미토스 사태는 "이러한 전환의 **결정적 촉매제**" (밸류파인더)
- 구조적 성장 기대 — 규제 적합성 + 기술 우위 + 시장 확대 3중 동인



## 7. 인과관계 전체 흐름

```mermaid
flowchart TD
    A["Anthropic: Mythos 공개"] --> B[OpenBSD 취약점 분 단위 발견]
    B --> C["로컬 설치형 보안(EDR) 한계 노출"]
    C --> D["금감원·과기정통부 긴급 대응"]
    C --> E[RBI 원천 차단 기술 부각]

    F[금융당국 망분리 규제 완화] --> G[외부망 접속 솔루션 수요 급증]

    E --> H[SHIELD Gate 수요 급증]
    G --> H
    D --> I[로컬 설치 최소화 규제 강화]
    I --> H

    H --> J["Softcamp 매출 257억 / 흑자전환"]
    J --> K["금융 → 공공 → 민간 시장 확대"]

    style A fill:#ffcccc
    style H fill:#ccffcc
    style J fill:#ccffcc
    style K fill:#cce5ff
```



---

## 관련 문서 (Named entity)

**엔티티:**

- [앤스로픽](entity/anthropic.md) · [미토스](entity/mythos-ai-agent.md) · [소프트캠프](entity/softcamp.md) · [실드게이트](entity/shieldgate.md)
- [RBI](entity/rbi-remote-browser-isolation.md) · [EDR](entity/edr-endpoint-security.md) · [OpenBSD](entity/openbsd.md)
- [망분리 규제 완화](entity/network-separation-deregulation-korea.md) · [금융감독원](entity/fss-korea.md) · [과기정통부](entity/msit-korea.md)
- [밸류파인더](entity/valuefinder-research.md) · [이충헌](entity/lee-chung-hun.md)

**인과관계:**

- [미토스 → 기존 보안체계 위기](rel/mythos-to-legacy-security-crisis.md)
- [미토스 → 실드게이트 수요 급증](rel/mythos-to-shieldgate-demand.md)
- [미토스 → 금융당국 규제 대응](rel/mythos-to-regulatory-response.md)
- [실드게이트 RBI → 금융·공공·민간 보안시장 확대](rel/shieldgate-rbi-to-security-market-expansion.md)
- [망분리 규제 완화 → 소프트캠프 실적 성장](rel/network-separation-deregulation-to-softcamp-growth.md)


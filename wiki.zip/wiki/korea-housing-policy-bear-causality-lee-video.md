---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: "영상 메타·자막(YouTube) 기준"
---

# 한국 주택·정책 하방 논리 (이현철 영상 인과, RCA·Impact)

**목적:** YouTube 영상 **「다들 잘못 알고 있어요」 강남 급매물 90% 줄었다? … \| 이현철 소장 3부**의 **근거·인과**를 **RCA·Impact** 추론용 위키로 구조화함. 원본: `https://www.youtube.com/watch?v=iqkcH4H1F_0`. 본문은 영상 주장의 **재구성**이며, 법·세제·실제 시장 결과를 **단정하지 않음**.

다른 **한국 거시·자산** 인과와 병행: [한국 스태그플레이션 리스크 (영상)](korea-stagflation-risk-causality.md), [국내 증시·선행지수 (영상)](korea-kospi-leading-indicator-causality.md).

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Korea_Housing_Speculation_Market`** | 한국 주택=투기시장 | 영상 전제: 시장 힘이 크고, 이에 맞서려면 **정책급** 힘이 필요하다는 서술. |
| **`Policy_Lever_vs_MacroWeak`** | 정책 레버 vs 거시 요인 약함 | 금리·경기·환율 등은 **영향이 약**하고 **정책**이 **압도적**이라는 비유·서술. |
| **`Govt_Downward_Stabilization_Goal`** | 하향 안정화 목표 | 대출 규제의 목적을 **가계부채 위험만**이 아니라 **시장 하향 안정화·투기 억제**로 해석. |
| **`Policy_Escalation_If_Market_Resists`** | 규제 에스컬레이션 | 규제를 **시장이 이기면**(가격 상승) **더 셀 것**, **보유세** 등 추가 가능성 논리. |
| **`Regional_Market_Connection`** | 지역 간 연결 | 부동산은 **연결**; 하락장에서 일부 상승은 **되돌림** 메타포. |
| **`Single_Complex_Narrative_Fallacy`** | 단지 단독 낙관 오류 | 특정 단지만으로 **전체 국면**을 판단하면 안 된다는 지적. |
| **`Collusion_Among_Owners`** | 집주인 담합 | 가격 방어 **담합** 시도. |
| **`Market_Regime_Backing_Collusion`** | 담합 뒷받침 국면 | **상승 분위기**가 담합을 지지할 때 vs **하락장**에서 붕괴. |
| **`Prisoner_Dilemma_Defection`** | 이탈(죄수의 딜레마) | 담합 깨고 먼저 움직이는 쪽 이익 → **이탈**. |
| **`TimePressure_Sellers`** | 시간 압박 매도측 | 임대·대출 만기 등; **일시적 1가구 2주택 3년** 등 **기한 내 처분** 서술. |
| **`Dual_Loss_Principal_Interest`** | 원금+이자 이중 손실 | 하락장에서 **자산가치 하락**과 **이자**가 겹치는 서술. |
| **`Bear_Market_Duration_Long`** | 하락장 기간 장기 | **5~6년** 고통, **최저 바닥** 부근 매도 패턴 언급. |
| **`Selling_At_Trough_Behavior`** | 저점권 매도 행동 | 고통 지속 후 **바닥** 부근에서 정리되는 **행동** 패턴(영상 사례). |
| **`Distressed_Listing_Drawdown_Ephemeral`** | 급매 감소(일시) | “급매 대폭 감소” 등 **단기 신호**. |
| **`Sustained_Price_Recovery`** | 지속적 가격 회복(가설) | 영상이 **단기 신호로부터 바로 추론하면 안 된다**고 하는 **결과 범주**. |
| **`Official_Price_Tax_Burden`** | 공시지가·세 부담 | **공시지가 상승** → 세금 부담 → **강남 초고가** 보유 비용 맥락. |
| **`Lee_HyunIk`** | 이현철 (발화자) | Person. |
| **`Video_Source_YT_iqkcH4H1F_0`** | 출처 영상 | Evidence·챕터의 원천. |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 인과 기제 | 세부 | 태그 |
|------|------------|------|------|
| **정책 우위** | 투기시장 + 정책 >> 금리·경기 | 시장이 **정책을 이기지 못한다** | `RCA`+`Impact` |
| **에스컬레이션** | 하향 안정화 | 시장이 규제를 이기면 **추가 수단** | `RCA`+`Impact` |
| **연결·부분 반등** | 전국 연결 | 하락장 **부분 상승**은 **되돌림** | `Impact` |
| **담합** | 국면 | 상승장 **뒷받침** 시 vs 하락장 **붕괴** | `RCA`+`Impact` |
| **시간·이중손실** | 만기·이자·가격 | 매도·조정 **압력** | `Impact` |
| **지표 오독** | 급매 감소 | **반등 확정**으로 읽기 **금지** | `Evidence` |

### 2.1 Edge 표 (`source | edge | target | `mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Korea_Housing_Speculation_Market` | `implies` | `Policy_Lever_vs_MacroWeak` | `market_structure` |
| `Policy_Lever_vs_MacroWeak` | `supports_goal_of` | `Govt_Downward_Stabilization_Goal` | `policy_priority` |
| `Govt_Downward_Stabilization_Goal` | `may_escalate_to` | `Policy_Escalation_If_Market_Resists` | `escalation` |
| `Regional_Market_Connection` | `limits` | `Single_Complex_Narrative_Fallacy` | `partial_rally_revert` |
| `Market_Regime_Backing_Collusion` | `enables` | `Collusion_Among_Owners` | `upcycle_collusion` |
| `Korea_Housing_Speculation_Market` | `in_bear_breaks` | `Collusion_Among_Owners` | `downcycle_collusion_fail` |
| `Collusion_Among_Owners` | `subject_to` | `Prisoner_Dilemma_Defection` | `defection` |
| `TimePressure_Sellers` | `interacts_with` | `Dual_Loss_Principal_Interest` | `liquidity_stress` |
| `Dual_Loss_Principal_Interest` | `prolongs` | `Bear_Market_Duration_Long` | `pain_hold` |
| `Bear_Market_Duration_Long` | `correlates_with` | `Selling_At_Trough_Behavior` | `behavioral_bottom` |
| `Distressed_Listing_Drawdown_Ephemeral` | `does_not_imply` | `Sustained_Price_Recovery` | `ephemeral_listings` |
| `Official_Price_Tax_Burden` | `adds_to` | `TimePressure_Sellers` | `tax_carry` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`)

- **시장 정의:** **투기 시장** → 일반 거시요인보다 **정책**이 지배적이라는 **원인론**.
- **정책 목표 해석:** **하향 안정화·투기 억제**가 목표라면, 시장이 저항할수록 **추가 규제·세** 시나리오가 **근본 촉발 요인**으로 제시됨.
- **담합 실패 근원:** 하락장에서 **국면이 담합을 뒷받침하지 않음** + **이탈 인센티브**.
- **시간 구조:** **만기·세금·2주택 기한** 등으로 **매각 시한**이 걸린 집단 존재 → **현금흐름·세금**과 결합.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`)

- **가격·거래:** **부분 반등·호재**는 **전체 연결** 속에서 **되돌림** 가능성이 크다는 **영향 방향** 서술.
- **급매 지표:** **급매 감소**를 **곧바로 회복**으로 연결하는 것은 **오류**(`Distressed_Listing_Drawdown_Ephemeral` → `Sustained_Price_Recovery` **비추론**).
- **행동:** **이중 손실**·장기 하락 → **저점 부근**에서의 **정리 행동** 패턴을 **경험담**으로 제시.
- **강남 초고가:** **공시지가·세** 부담이 **보유 비용**을 키운다는 **압력 채널**.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF Korea_Housing_Speculation_Market THEN Policy_Lever_vs_MacroWeak dominates short_run_drivers END
IF Govt_Downward_Stabilization_Goal AND market_resists_up THEN Policy_Escalation_If_Market_Resists END
IF bear_regime THEN Collusion_Among_Owners tends_to_fail AND Prisoner_Dilemma_Defection rises END
IF TimePressure_Sellers AND Dual_Loss_Principal_Interest THEN seller_distress_prolongs END
IF Distressed_Listing_Drawdown_Ephemeral observed THEN NOT (infer Sustained_Price_Recovery) END
```

```mermaid
flowchart TB
  S[Korea_Housing_Speculation_Market] --> P[Policy_Lever_vs_MacroWeak]
  P --> G[Govt_Downward_Stabilization_Goal]
  G --> E[Policy_Escalation_If_Market_Resists]
  R[Regional_Market_Connection] --> F[Single_Complex_Narrative_Fallacy]
  C[Collusion_Among_Owners] --> D[Prisoner_Dilemma_Defection]
  T[TimePressure_Sellers] --> L[Dual_Loss_Principal_Interest]
  L --> B[Bear_Market_Duration_Long]
  B --> ST[Selling_At_Trough_Behavior]
  DI[Distressed_Listing_Drawdown_Ephemeral] -.->|does_not_imply| SU[Sustained_Price_Recovery]
  O[Official_Price_Tax_Burden] --> T
```

---

<a id="evidence-data"></a>

## 6. Evidence (`Video_Source_YT_iqkcH4H1F_0`)

| 유형 | 내용 |
|------|------|
| **출처** | `https://www.youtube.com/watch?v=iqkcH4H1F_0` (채널: 이현철 아파트사이클연구소, 약 24:29) |
| **챕터(메타)** | 00:43 정부·시장 대립 프레이밍; 08:01 매도·버티기·심리; 12:30 가격·6년 고통 류 서술 |
| **자막 키워드** | 투기 시장, 정책 우위, 하향 안정화, 담합·죄수의 딜레마, 시간 압박, 이중 손실, 5~6년·바닥 매도, 급매 일시 현상 오독 경고, 공시지가·세 |

---

<a id="summary"></a>

## 7. 결론(메타)

영상 논지는 **“정책이 정한 하향 국면을 투기 시장이 이기기 어렵다”**는 **정책 우선 인과**와, **담합·급매 지표의 단기성을 과대해석하지 말라**는 **인지 오류 경고**, **시간·세금·이자가 매도·장기 조정을 밀어낸다**는 **행동·현금흐름 인과**로 압축된다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| Lee_HyunIk, 이현철 | Person | 이 문서 |
| Video_Source_YT_iqkcH4H1F_0 | Source | [§6](#evidence-data) |
| 한국 거시·증시 (참고) | Macro | [korea-stagflation-risk-causality.md](korea-stagflation-risk-causality.md), [korea-kospi-leading-indicator-causality.md](korea-kospi-leading-indicator-causality.md) |
| 부동산 양극화·현금 수요 (채상욱 영상) | Real estate / graph | [chae-sangwook-housing-polarization-causality.md](chae-sangwook-housing-polarization-causality.md) |
| 양도세 장특 폐지 논쟁 (정책 메모) | Policy / tax | [korea-cgt-longterm-holding-deduction-policy-debate.md](korea-cgt-longterm-holding-deduction-policy-debate.md) |

---

## 관련 문서

- [한국 스태그플레이션 리스크 (영상 근거)](korea-stagflation-risk-causality.md): 미국·유가·환율 등 **다른 축**의 한국 거시.
- [국내 증시·선행지수·섹터 로테이션 (영상)](korea-kospi-leading-indicator-causality.md): **주식** 자산군 인과.
- [유가·에너지·물가 전망과 투자 시사점](macro-energy-inflation-outlook.md): **인과·거시 클러스터** 허브.
- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): **공급·반도체** 기반 **장기 우상향** 서술과 **대비**.
- [한국 주택·양극화·관망 (채상욱 영상)](chae-sangwook-housing-polarization-causality.md): **하이닉스·현금 매수**·**전월세** 중심 **지역 강세·고가 관망** 인과 — 본 문서 **정책 하방**과 **대비**.
- [양도세 장특 폐지 논쟁 (정책 메모)](korea-cgt-longterm-holding-deduction-policy-debate.md): **장특**·**실거주 vs 투기** **프레임**·**점진 폐지**.

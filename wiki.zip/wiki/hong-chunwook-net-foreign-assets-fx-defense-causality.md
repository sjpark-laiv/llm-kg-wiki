---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: "영상 발화 요지 메모 기준 (타임스탬프 미기재)"
---

# 순대외금융자산·환율 해석 (홍춘욱 박사 영상 인과, RCA·Impact)

**목적:** **홍춘욱** 박사 발화 중 **순대외금융자산·공공부문 해외운용자산**이 **외환 위기 서사**를 어떻게 **완화·재해석**하는지, **환율 변동**을 **펀더멘털 붕괴**가 아닌 **지정학·안전자산 선호**로 읽는 논리를 **RCA·Impact**용으로 구조화함. **기업 디폴트**와 **국가 외환 위기**의 **구분**, **투자자 포지션(해외자산·달러)** 시사를 포함한다.

**병행:** [반도체 수출·구리·코스피 (홍춘욱)](hong-chunwook-semiconductor-copper-kospi-causality.md)(기업 **수출 외화** 완충), [한국 스태그플레이션 리스크](korea-stagflation-risk-causality.md)(**환율·물가·성장** 압력 서사)와 **대비·합성**해 읽는다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Net_Foreign_Assets_Korea`** | 순대외금융자산 | **대외자산 − 대외부채**로, 메모 기준 **약 1조 달러** 규모 서술. |
| **`Gross_Foreign_Assets_Korea`** | 대외금융자산(총액) | 메모 기준 **약 2조 8,000억 달러** 수준 서술. |
| **`Official_Sector_Overseas_AUM`** | 공공부문 해외운용 | **국민연금**, **KIC(한국투자공사)**, **한국은행** 해외자산 합이 **약 1조 달러에 육박**한다는 서술. |
| **`FX_Liquidity_Rebalance_Channel`** | 해외자산 매각·리밸런싱 | 외화 수급 **일시적** 이슈 시 **해외 자산 매각**으로 **달러 조달** 가능하다는 **유동성 공급** 논리(IMF 시절과 대비). |
| **`Corporate_Default_vs_SovereignFXCrisis`** | 디폴트 vs 외환위기 구분 | **특정 기업**의 달러 부채 **디폴트**와, **국가 순자산 ≫ 부채** 전제의 **외환 위기**를 **동일시하지 말라**는 논리. |
| **`Geo_Risk_MiddleEast`** | 중동 지정학 리스크 | **전쟁 리스크**·**안전자산(달러) 선호**로 **원/달러**가 움직인다는 **RCA** 축. |
| **`USD_Preference`** | 달러 선호 | [스태그플레이션 리스크](korea-stagflation-risk-causality.md#entities)와 동일 라벨; **안전자산·위험회피** 맥락에서 `FX_KRW_per_USD` 상방. |
| **`FX_KRW_per_USD`** | 원/달러 환율 | **1,500원** 돌파 등 **변동성 확대** 현상을 논의 대상으로 둠. |
| **`Foreign_Equity_Outflow_Korea`** | 외국인 주식 순매도 | **2~3월** 약 **50조 원** 규모 매도와 **환율 상승폭 ~100원** 방어를 **결합**한 **수급 견고** 반증 서술. |
| **`Corporate_USD_Inflow_Channel`** | 기업 달러 유입(수출 등) | 외국인 매도에도 환율이 크게 안 튄 배경으로 **기업 해외 벌이 외화**의 **탄탄함**을 듦. |
| **`FX_Hedge_Overseas_Portfolio`** | 해외자산 환차익(헤지) | 원화 약세 시 **해외 자산**의 **환차익**이 **원화 손실을 상쇄**하는 효과 서술. |
| **`Currency_Crisis_Risk_Korea_Low`** | 외환 위기 가능성(저평가) | **매우 희박**하다는 **전망형** 주장; **반도체 호조**·**막대한 대외자산**을 근거로 제시. |
| **`Conservative_Stance_Until_Shipping_Safe`** | 운송 안전 회복까지 보수 | 중동 분쟁 **해소**·**해상 운송 안전** 회복 전까지 **보수적** 대응. |
| **`USD_Asset_RiskMgmt_Recommendation`** | 달러 자산 보유 권고 | **리스크 관리**를 위해 **달러 자산 보유**를 제시. |
| **`Hong_ChunWook`** | 홍춘욱 (발화자) | Person. |
| **`Semiconductor_Export_Korea`** | (외부 참조) | [반도체·구리·코스피](hong-chunwook-semiconductor-copper-kospi-causality.md#entities) 정의; `Corporate_USD_Inflow_Channel`로 연결. |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 인과 기제 | 세부 | 태그 |
|------|------------|------|------|
| **방어막** | 순·총 대외금융자산 | **자산 ≫ 부채**·**총자산 규모**로 **국가 외환 위기** 서사 완화 | `RCA`+`Impact` |
| **공공 해외운용** | NPS·KIC·한은 | **해외 AUM**이 **거대** → **리밸런싱 달러** 공급 **능력** | `RCA` |
| **유동성** | 해외자산 → 달러 | **일시적** 외화 수급 압력에 **매각·조정** 대응 | `Impact` |
| **구분 논리** | 기업 디폴트 | **국가 전체** 대차대조표와 **혼동 금지** | `RCA` |
| **환율 RCA** | 지정학·달러 선호 | **한국 펀더멘털 붕괴**보다 **지정학·안전자산** 반영 | `RCA` |
| **수급 반증** | 외국인 매도 vs 환율 | **대규모 주식 매도** vs **제한적 환율 상승** → **기업 달러** 견고 | `Evidence`+`RCA` |
| **포트폴리오** | 해외 투자 | **환차익**으로 **실질 타격 완화** | `Impact` |
| **전망·운용** | 위기 저평가 + 보수 | **위기 가능성 희박** + **분쟁·운송** 해결 전 **보수**·**달러 자산** | `Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Net_Foreign_Assets_Korea` | `reduces_probability_narrative` | `Currency_Crisis_Risk_Korea_Low` | `national_balance_sheet` |
| `Gross_Foreign_Assets_Korea` | `supports` | `FX_Liquidity_Rebalance_Channel` | `asset_liquidity` |
| `Official_Sector_Overseas_AUM` | `feeds` | `FX_Liquidity_Rebalance_Channel` | `public_aum` |
| `FX_Liquidity_Rebalance_Channel` | `mitigates` | `FX_KRW_per_USD` | `usd_supply` |
| `Corporate_Default_vs_SovereignFXCrisis` | `distinguishes` | `Currency_Crisis_Risk_Korea_Low` | `terminology` |
| `Geo_Risk_MiddleEast` | `explains_move_in` | `FX_KRW_per_USD` | `safe_haven_usd` |
| `USD_Preference` | `amplifies` | `FX_KRW_per_USD` | `risk_off` |
| `Foreign_Equity_Outflow_Korea` | `would_pressure` | `FX_KRW_per_USD` | `capital_outflow` |
| `Corporate_USD_Inflow_Channel` | `offsets` | `Foreign_Equity_Outflow_Korea` | `trade_fx_inflow` |
| `Semiconductor_Export_Korea` | `feeds` | `Corporate_USD_Inflow_Channel` | `export_channel` |
| `FX_Hedge_Overseas_Portfolio` | `offsets_wealth_effect_of` | `FX_KRW_per_USD` | `mark_to_market_hedge` |
| `Conservative_Stance_Until_Shipping_Safe` | `implies` | `USD_Asset_RiskMgmt_Recommendation` | `tail_risk_mgmt` |

`USD_Preference`는 [한국 스태그플레이션 리스크](korea-stagflation-risk-causality.md)의 `USD_Preference`·`FX_KRW_per_USD`와 **동일 축**으로 **합성**한다. `Semiconductor_Export_Korea`는 [반도체·구리·코스피](hong-chunwook-semiconductor-copper-kospi-causality.md#entities)와 연결.

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`)

- **“외환 위기” 서사의 완화:** **순대외금융자산**이 **약 1조 달러**, **총 대외금융자산**이 **약 2조 8,000억 달러** 수준이라는 **스케일**을 전제로, 과거 **IMF** 국면과 달리 **해외에 쌓인 자산**이 커 **일시적** 외화 수급 문제에 **매각·리밸런싱**으로 대응 가능하다는 논리.
- **공공부문 해외:** **국민연금·KIC·한은** 해외 운용만 **약 1조 달러에 육박**한다는 서술로 **공적 완충**을 강조.
- **디폴트 vs 국가 위기:** **기업**이 달러 빚을 못 갚는 것은 **디폴트**일 뿐, **국가 전체**는 **자산 ≫ 부채**이므로 이를 **외환 위기**로 단정하기 어렵다는 **용어·사고 분리**.
- **환율이 튀는 이유(대안 RCA):** **1,500원** 돌파 등은 **한국 펀더멘털 붕괴**보다 **중동 전쟁**에 따른 **지정학 리스크**와 **달러(안전자산) 선호**의 반영이라는 주장.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`)

- **수급 신뢰:** **2~3월** 외국인 **약 50조 원** 주식 매도에도 **환율 상승폭이 약 100원** 수준에 **방어된** 점을 **기업 해외 수입 달러**의 **견고함** 반증으로 제시.
- **투자자 실질 손실:** 원화 약세 시 **해외 자산** 보유자는 **환차익**으로 **손실 상쇄(헤지)** → 최근 충격의 **실질 타격 완화** 서술.
- **거시 전망:** **외환 위기(Currency Crisis)** 가능성은 **매우 희박**; **반도체 수출 호조**와 **막대한 대외자산**으로 **대외 충격**을 **견딜 힘**이 충분하다는 쪽.
- **행동 규범:** 환율 상승을 **위기 징후**로만 보지 말고 **외화 수급 구조·대외자산 규모**를 신뢰하되, **중동 분쟁 해소**·**해상 운송 안전** 회복 전까지는 **보수적** 대응과 **달러 자산 보유**로 **리스크 관리**하라는 **결론**.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF Net_Foreign_Assets_Korea large AND Gross_Foreign_Assets_Korea large
THEN FX_Liquidity_Rebalance_Channel available AND Currency_Crisis_Risk_Korea_Low narrative_strengthens END
IF corporate USD default THEN Corporate_Default_vs_SovereignFXCrisis applies (firm-level) END
IF NOT (sovereign net foreign assets negative shock) THEN do NOT equate firm default with Currency_Crisis_Risk_Korea_Low spike END
IF Geo_Risk_MiddleEast high THEN explain FX_KRW_per_USD move as safe_haven_not_only_fundamental END
IF Foreign_Equity_Outflow_Korea large AND FX_KRW_per_USD rise_small THEN evidence Corporate_USD_Inflow_Channel strong END
IF investor holds Overseas_Assets THEN FX_Hedge_Overseas_Portfolio offsets KRW wealth effect END
UNTIL shipping_safe AND geopol_eases STRATEGY Conservative_Stance_Until_Shipping_Safe AND USD_Asset_RiskMgmt_Recommendation END
```

```mermaid
flowchart TB
  NFA[Net_Foreign_Assets_Korea] --> L[FX_Liquidity_Rebalance_Channel]
  GFA[Gross_Foreign_Assets_Korea] --> L
  OS[Official_Sector_Overseas_AUM] --> L
  L --> RISK[Currency_Crisis_Risk_Korea_Low]
  GEO[Geo_Risk_MiddleEast] --> FX[FX_KRW_per_USD]
  FO[Foreign_Equity_Outflow_Korea] --> FX
  CE[Corporate_USD_Inflow_Channel] --> FX
  H[FX_Hedge_Overseas_Portfolio] --> IMP[Investor real loss muted]
```

---

<a id="evidence-data"></a>

## 6. Evidence — 관측·지표(메모)

| 항목 | 내용 |
|------|------|
| **스케일** | 순대외금융자산 **~1조 USD**, 총 대외금융자산 **~2.8조 USD**, 공공 해외 **~1조 USD** (발화 메모). |
| **자본 흐름 vs 환율** | **2~3개월** 외국인 주식 **약 50조 원** 매도 vs 환율 **~100원**대 방어 서술. |
| **환율 수준** | **1,500원** 돌파·변동성 언급. |
| **타임스탬프** | 본 메모에는 **영상 시각 표기 없음** — 필요 시 원본 영상에서 **보강** 가능. |

---

<a id="summary"></a>

## 7. 결론(메타)

이 서사는 **대외 순·총 자산**과 **공공 해외운용**을 **국가 차원의 완충**으로 두고, **환율**을 **지정학·달러 선호**로 **재해석**하며, **외국인 주식 매도 vs 환율**을 **기업 달러 수급**의 **반증**으로 쓴다. [스태그플레이션 리스크](korea-stagflation-risk-causality.md) 문서의 **환율·물가·성장** 압력 경로와 **논리적으로 긴장**할 수 있으므로, **동일 지표(`FX_KRW_per_USD`)**에 **서로 다른 RCA 가설**을 **병행**해 두는 것이 분석에 유리하다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| Hong_ChunWook | Person | 이 문서, [홍춘욱 거시·부동산](hong-chunwook-macro-rebound-causality-video.md) |
| 국민연금, KIC, 한국은행 | Organization | [§1](#entities) |
| 순대외금융자산, 환율 | Macro | 이 문서 |
| 반도체 수출·기업 외화 | Macro | [hong-chunwook-semiconductor-copper-kospi-causality.md](hong-chunwook-semiconductor-copper-kospi-causality.md) |
| 중동·호르무즈 | Risk | [korea-stagflation-risk-causality.md](korea-stagflation-risk-causality.md) |
| 코스피 강세·안전자산 (홍춘욱 영상) | Macro / equity | [hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md) |

---

## 관련 문서

- [반도체 수출·구리·코스피 (홍춘욱 영상)](hong-chunwook-semiconductor-copper-kospi-causality.md): **기업 수출 외화**·환율 완충.
- [한국 스태그플레이션 리스크 (영상)](korea-stagflation-risk-causality.md): **환율·유가·성장** 스트레스 서사.
- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): 상위 **거시·자산** 서사.
- [유가·에너지·물가 전망 (메모)](macro-energy-inflation-outlook.md): 거시 **허브**.
- [코스피 강세·VIX·구리·AI·안전자산 (홍춘욱 영상)](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md): **달러·금** **안전자산 병행**·**코스피200 ETF** 인과.

---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
---

# 국내 증시·선행지수·섹터 로테이션 (김영익 교수, 영상 근거 인과)

**목적:** 영상 **「지금 시장, 주목할 ‘핵심 섹터’는 바로 이곳입니다」**에서 **김영익** 교수가 제시한 **거시·시장 근거와 인과**를 **RCA·Impact** 추론용으로 구조화함. 수치·전망은 **영상 내 주장**으로 한정.

**성장·수출 둔화** 맥락은 [한국 스태그플레이션 리스크 (영상)](korea-stagflation-risk-causality.md)의 수요 채널과 **참고용**으로 연결한다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Leading_Index_Cyclical`** | 경기 선행 지수(순환변동치) | 올해 **3~5월** 부근 **정점** 후 **하락 전환** 가능성이 높다는 영상 판단 *(01:40)*. |
| **`KOSPI_Valuation_vs_Fundamentals`** | 코스피 상대 밸류에이션 | **1일 평균 수출액**, **M2 대비 시가총액**, **명목 GDP** 등 **본질 가치** 대비 주가가 **과대**라는 분석 *(09:46)*. |
| **`Corporate_Earnings_Outlook`** | 기업 이익 전망 | 당장 실적은 양호하나 **경기 대비 후행** → **하향 조정** 가능성 *(02:50)*. |
| **`KOSPI_Adjustment`** | 코스피 조정(하방 압력) | 선행 악화·밸류 부담이 맞물릴 때의 **지수 조정** 국면. |
| **`Aggregate_Demand_Weakness`** | 소비·투자·수출 둔화 | 선행 지수 악화가 시사하는 **총수요** 둔화. |
| **`Sector_Cyclical_Export`** | 경기민감·수출주 | 예: **반도체**, **자동차** — 경기 둔화 시 **타격 큼** *(08:15)*. |
| **`Sector_Defensive_Value_Dividend`** | 방어·가치·배당주 | 예: **통신**, **음식료** — **배당 수익률** 상대적으로 높고(영상에서 **4~5%** 언급), **PBR 낮은 저평가**로 **상대 방어** *(05:31)*, *(08:15)*. |
| **`Portfolio_Equity_Weight`** | 주식 비중 | 선행 **하락 국면**에서 **축소** 권고 *(08:50)*. |
| **`Portfolio_Bond_Weight`** | 채권 비중 | **안전자산** 비중 **확대** 권고 *(08:50)*. |
| **`Kim_YoungIk`** | 김영익 (교수) | 본 영상의 발언 근거 정리 대상 Person. |

**추론 태그:** `RCA` · `Impact` · `Evidence`.

---

<a id="causality-map"></a>

## 2. Causality Map — 근거 → 시장·섹터

| 경로 구분 | 인과 기제 | 세부 | 분석 태그 |
|-----------|------------|------|-----------|
| **선행성** | 선행 지수 꺾임 → 코스피 조정 | 주가는 경기보다 **선행** → 선행 악화 후 **시차**로 지수 하방 *(03:36)* | `RCA`+`Impact` |
| **실적 파이프라인** | 선행 악화 → 수요 둔화 → 이익 감소 | 소비·투자·수출 감소 → **매출·영업이익** 하방 *(02:25)* | `Impact` |
| **밸류** | 펀더멘털 대비 고평가 → 조정 압력 | 수출·M2·GDP 대비 시총 등 **부담** *(09:46)* | `RCA`+`Impact` |
| **후행 실적** | 좋은 실적의 함정 | 실적은 지표에 **후행** → **전망 하향** 임박 *(02:50)* | `RCA` |
| **섹터 차별** | 둔화 → 민감주 약세 / 가치·배당 방어 | 민감주 대형 타격 vs **배당·저PBR** 상대 강세 *(08:15)* | `Impact` |
| **자산배분** | 국면 전환 → 주식↓ 채권↑ | 방어적 **혼합** *(08:50)* | `Impact` |
| **핵심 섹터 전환** | 성장주 중심 → 통신 등 가치주 | **핵심 섹터** 재정의 *(05:31)* | `Impact` |

### 2.1 그래프 엣지 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `Leading_Index_Cyclical` | `signals_future` | `KOSPI_Adjustment` | `lead_lag_equity` |
| `Leading_Index_Cyclical` | `implies` | `Aggregate_Demand_Weakness` | `demand_pipeline` |
| `Aggregate_Demand_Weakness` | `reduces` | `Corporate_Earnings_Outlook` | `sales_margin` |
| `KOSPI_Valuation_vs_Fundamentals` | `increases_downside` | `KOSPI_Adjustment` | `valuation_risk` |
| `Corporate_Earnings_Outlook` | `revises_down` | `KOSPI_Adjustment` | `earnings_revision` |
| `Aggregate_Demand_Weakness` | `hurts_more` | `Sector_Cyclical_Export` | `cyclical_beta` |
| `Aggregate_Demand_Weakness` | `relative_support` | `Sector_Defensive_Value_Dividend` | `defensive_tilt` |
| `Leading_Index_Cyclical` | `triggers_rebalance` | `Portfolio_Equity_Weight` | `asset_allocation` |
| `Leading_Index_Cyclical` | `triggers_rebalance` | `Portfolio_Bond_Weight` | `asset_allocation` |
| `KOSPI_Adjustment` | `motivates_rotation` | `Sector_Defensive_Value_Dividend` | `sector_rotation` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`) — “하방 압력의 근거는?”

- **선행 국면:** 순환변동치가 **3~5월** 전후 **정점** 후 **하락** 가능성 *(01:40)*.
- **밸류에이션:** **수출·M2·명목 GDP** 등 대비 **시총·주가 과대** *(09:46)*.
- **이익 사이클:** 현재 실적 호조는 **후행** → **전망 하향** 임박 *(02:50)*.
- **메타:** **‘선행 지수 정점 통과 + 밸류 부담’**을 시장 하방의 **복합 근거**로 요약 (영상 결론).

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`) — “무엇이 어떻게 변하는가?”

### A. 지수·실적

- **선행 하락 → 코스피 조정:** 시장이 경기보다 **앞서** 움직이므로 **시차** 후 **지수 하방** *(03:36)*.
- **선행 악화 → 수요 둔화 → 이익:** 소비·투자·수출 감소가 **매출·영업이익**으로 전가 *(02:25)*.

### B. 섹터

- **경기민감주(반도체·자동차 등):** 둔화 시 **타격 큼** *(08:15)*.
- **가치·배당(통신·음식료 등):** **배당 4~5%**·**낮은 PBR** 등으로 **상대 방어** *(05:31)*, *(08:15)*.

### C. 포트폴리오(전략)

- **주식 비중 축소·채권 확대:** 선행 **하락 국면** 진입에 맞춰 **주식↓·채권(안전자산)↑** *(08:50)*.
- **핵심 섹터 전환:** 반도체·자동차 중심에서 **통신** 등 **저평가 가치·배당** 중심 *(05:31)*.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF Leading_Index_Cyclical peaks Mar-May window THEN expect subsequent decline END
IF Leading_Index_Cyclical declines THEN future Aggregate_Demand_Weakness END
IF Aggregate_Demand_Weakness THEN Corporate_Earnings_Outlook down AND KOSPI_Adjustment pressure END
IF KOSPI_Valuation_vs_Fundamentals stretched THEN extra downside to KOSPI_Adjustment END
IF current earnings strong THEN treat as lagging; expect downward revision per [02:50] END
IF slowdown THEN Sector_Cyclical_Export underperforms vs Sector_Defensive_Value_Dividend END
STRATEGY: reduce Portfolio_Equity_Weight, raise Portfolio_Bond_Weight; rotate to Sector_Defensive_Value_Dividend
```

```mermaid
flowchart LR
  L[Leading_Index_Cyclical] --> K[KOSPI_Adjustment]
  L --> D[Aggregate_Demand_Weakness]
  D --> E[Corporate_Earnings_Outlook]
  V[KOSPI_Valuation_vs_Fundamentals] --> K
  E --> K
  D --> CY[Sector_Cyclical_Export weak]
  D --> DF[Sector_Defensive_Value_Dividend resilient]
  L --> PE[Portfolio_Equity_Weight down]
  L --> PB[Portfolio_Bond_Weight up]
```

---

<a id="evidence-data"></a>

## 6. Evidence — 영상 타임스탬프

| 시각 | 주제 |
|------|------|
| 01:40 | 선행 지수 순환변동치 3~5월 정점 후 하락 가능성 |
| 02:25 | 선행 악화 → 소비·투자·수출 감소 → 기업 매출·영업이익 |
| 02:50 | 실적 호조는 후행 → 전망 하향 가능성 |
| 03:36 | 선행 지수 하락 → 시차 후 코스피 조정 |
| 05:31 | 핵심 섹터: 통신 등 배당·저PBR 가치주 |
| 08:15 | 경기민감주 vs 가치·배당 방어 |
| 08:50 | 주식 비중 축소·채권 확대 |
| 09:46 | 수출·M2·명목 GDP 대비 코스피 과대평가 |

---

<a id="summary"></a>

## 7. 결론(메타)

영상은 **선행 지수 정점 통과**와 **밸류에이션 부담**을 축으로 **시장 하방 압력**을 강조하고, **방어적 포트폴리오(가치·배당)** 및 **채권 비중 확대**로 대응할 것을 설명한다.

---

## Named entity 링크 (문서 간)

| 개체 | 유형 | 연결 |
|------|------|------|
| 김영익 (`Kim_YoungIk`) | Person | 이 문서 |
| 코스피, 선행 지수 | Index / macro | 이 문서 [§1–4](#entities) |
| 성장·수출 둔화 (참고) | Macro | [korea-stagflation-risk-causality.md](korea-stagflation-risk-causality.md) |
| 미국 ODM·AI 낙관 (채상욱 영상) | Macro / equity | [chae-sangwook-korea-us-odm-ai-kospi-causality.md](chae-sangwook-korea-us-odm-ai-kospi-causality.md) |
| 주택 양극화·관망 (채상욱 영상) | Real estate / graph | [chae-sangwook-housing-polarization-causality.md](chae-sangwook-housing-polarization-causality.md) |
| 코스피 강세·VIX·AI (홍춘욱 영상) | Macro / equity | [hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md) |
| 가치·배당·장기 복리 (숙향 영상) | Equity / process | [sukhyang-value-dividend-longterm-investing-causality.md](sukhyang-value-dividend-longterm-investing-causality.md) |

---

## 관련 문서

- [한국 스태그플레이션 리스크 (영상 근거)](korea-stagflation-risk-causality.md): 미국 소비·수출 채널 등 **거시 둔화** 참고.
- [유가·에너지·물가 전망과 투자 시사점](macro-energy-inflation-outlook.md): 채권·분산 등 **투자 시사** 맥락.
- [유가(Oil_Price) ↔ 물가(Price_Level) 인과 구조](oil-price-inflation-causality.md): **에너지 원가→물가→실물** 일반 틀과 병행.
- [한국 주택·정책 하방 논리 (이현철 영상)](korea-housing-policy-bear-causality-lee-video.md): **부동산** 국면·정책 인과(영상 근거).
- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): S&P·**5분법+CD ETF**·거시 반등 서사.
- [반도체 수출·구리·코스피 (홍춘욱 영상)](hong-chunwook-semiconductor-copper-kospi-causality.md): **반도체 외화·구리 실물**로 보는 **코스피 조건·타이밍** 인과.
- [한국 증시·미국 제조 ODM·AI (채상욱 영상)](chae-sangwook-korea-us-odm-ai-kospi-causality.md): **미·중 공급망**·**ODM·HBM**·**연금 수급** 기반 **장기 우상향·재평가** 인과 — 본 문서 **선행·밸류 하방**과 **대비**.
- [한국 주택·양극화·관망 (채상욱 영상)](chae-sangwook-housing-polarization-causality.md): **미국 주식 수익** 등 **부의 채널**이 **주택 현금 수요**로 이어지는 서사.
- [코스피 강세·VIX·구리·AI·안전자산 (홍춘욱 영상)](hong-chunwook-kospi-bull-vix-copper-ai-portfolio-causality.md): **VIX·숏커버·구리·AI** 기반 **강세·ETF** 서사 — 본 문서 **선행 하방**과 **대비**.
- [가치·배당·장기 복리 (숙향 영상)](sukhyang-value-dividend-longterm-investing-causality.md): **재무제표·저PBR/PER·배당·10~20종·일기** 기반 **장기 복리** — 본 문서 **단기 조정·섹터 로테이션**과 **대비**.

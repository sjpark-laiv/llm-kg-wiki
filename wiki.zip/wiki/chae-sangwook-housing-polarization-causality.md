---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: "영상 발화 요지 메모 기준"
---

# 한국 주택·양극화·관망 (채상욱 대표 영상 인과, RCA·Impact)

**목적:** **채상욱** 대표 발화 중 **부동산 양극화·관망세**, **하이닉스 수혜권 수요**, **대출 규제 무력화(자산 다각화)**, **공급·세제 불확실성**, **비아파트 붕괴·전월세**, **가격대별 전망**을 **RCA·Impact** 추론용으로 구조화함.

**대비 서사:** **정책 하방·규제 우위** 강조는 [한국 주택·정책 하방 (이현철 영상)](korea-housing-policy-bear-causality-lee-video.md), **공급·반도체 장기 우상향**은 [홍춘욱 거시·부동산 반등](hong-chunwook-macro-rebound-causality-video.md), 동일 화자의 **증시·ODM**은 [한국 증시·미국 제조 ODM·AI (채상욱)](chae-sangwook-korea-us-odm-ai-kospi-causality.md)와 **병행**한다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Chae_SangWook`** | 채상욱 (대표) | 본 영상 발언 정리 대상 Person. |
| **`SK_Hynix_Profit_Linked_Incentive`** | 하이닉스 연동 인센티브 | 영업이익 호조로 **3년간 약 10억 원** 수준 인센티브 **기대** 등 **거액 보너스** 서술 *(01:21)*. |
| **`SK_Hynix_Employee_Buyer_Cohort`** | 하이닉스 매수 주체(직원군) | **약 3만 명**이 **강력한 매수 주체**로 등장했다는 서술 *(02:12)*. |
| **`Shuttle_Corridor_Preferred_Clusters`** | 셔틀 노선 선호 단지군 | **강동**, **송파**, **용인**, **청주** 등 **노선 단지** 선호·**시세 급등** *(02:12)*. |
| **`Mortgage_Regulation_Channel`** | 은행 대출·주택 금융 규제 | 과거에는 수요 **억제**에 효과적이었다는 전제. |
| **`Retail_US_Equity_Wealth_Channel`** | 미국 주식 등 개인 자산 | **미국 주식 투자 수익** 등으로 **개인 자산**이 풍부해졌다는 서술 *(02:38)*, *(03:06)*. |
| **`Cash_Buyer_Bypass_Regulation`** | 현금성 매수(규제 회피) | 대출과 **무관하게** 집을 살 **체력** → 규제 **약발 무력화** 구간 *(02:38)*, *(03:06)*. |
| **`Housing_Regulation_Beyond_Bank_Channel`** | 금융 규제로 막기 어려운 구간 | **“금융 규제로는 막을 수 없는 구간”** 진단 *(02:56)*. |
| **`MOLIT_Supply_Plan_Small_Plot_Bias`** | 국토부 공급 계획(소필지 편향) | **실질 임대차 공급**보다 **소규모 필지 개발**에 치중 → 시장이 **경상적 장기 공급 회복**으로 보기 어렵다는 비판 *(15:52)*, *(19:07)*. |
| **`Rental_Public_Supply_Policy_Gap`** | 임대 공급 정책 공백 | **임대차 공급** 대책이 **전무**에 가깝다는 서사(요지). |
| **`NonApartment_Housing_Market_Collapse`** | 비아파트(빌라 등) 시장 약화 | **비아파트 시장 사멸**·붕괴로 **임차 수요**가 아파트로 **쏠림** *(13:09)*, *(22:16)*. |
| **`Jeonse_Wolse_Price_Pressure`** | 전월세 가격 압력 | 임차 수요 쏠림 + 공급 부족 → **전월세 상승**·**매매 하방 지지** 서사. |
| **`Property_Tax_Reform_Uncertainty`** | 보유세·다주택 세제 불확실 | **다주택자 규제**·**보유세 개편**안이 **불명확** *(03:55)*, *(07:05)*. |
| **`Housing_Market_Wait_and_See`** | 부동산 관망세 | 매도·매수 **이익 실현·추가 매수 유보**, **눈치보기**. |
| **`High_End_Quintile_Housing_5th`** | 고가 주택(5분위 등) | **보유세 부담**으로 **관망·약보합**·**횡보**·**거래 절벽** 가능성 *(21:55)*. |
| **`Affordable_Quintile_Housing_3rd_Below`** | 구매 가능 가격대(3분위 이하) | **실거주** 및 **임차료 해지(Hedge)** 수요로 **견조** 전망 *(21:55)*. |
| **`Hedge_Demand_Occupier`** | 실거주·임차료 헤지 수요 | **실거주** 및 **임대료 리스크** 완화 목적의 **매수·체류** 수요 *(21:55)*. |
| **`Housing_Price_Spike_Regional`** | 지역 주택 시세 급등 | 셔틀권 등 **소수 지역**의 **스파이크** 상승 국면(영상 **“주가 스파이크”** 표현은 **주택 시세** 비유로 정리). |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 인과 기제 | 세부 | 태그 |
|------|------------|------|------|
| **수요** | 반도체 인센티브·직원군 | **3만 명**·**고액 인센티브** → **셔틀권** **집중 수요** | `RCA`+`Impact` |
| **수요** | 주식 부의 현금화 | **미국 주식** 등 → **현금 매수** → **대출 규제** 한계 | `RCA`+`Impact` |
| **공급** | 국토부 계획 구조 | **소필지** 중심 → **임대 공급** 기대 약화 | `RCA`+`Evidence` |
| **임대** | 비아파트 붕괴 | 수요 **아파트 전월세**로 이동 → **전월세 상승** | `Impact` |
| **심리·세제** | 보유세 불확실 | **고가** 구간 **관망·거래 위축** | `RCA`+`Impact` |
| **국면** | 복합 | **양극화**(특정 지역 강세 vs 고가 관망) | `Impact` |
| **가격** | 셔틀권 집중 | **지역 시세 스파이크** | `Evidence`+`Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `SK_Hynix_Profit_Linked_Incentive` | `funds` | `SK_Hynix_Employee_Buyer_Cohort` | `bonus_liquidity` |
| `SK_Hynix_Employee_Buyer_Cohort` | `concentrates_demand_on` | `Shuttle_Corridor_Preferred_Clusters` | `commute_preferences` |
| `Shuttle_Corridor_Preferred_Clusters` | `drives` | `Housing_Price_Spike_Regional` | `localized_boom` |
| `Retail_US_Equity_Wealth_Channel` | `enables` | `Cash_Buyer_Bypass_Regulation` | `equity_wealth` |
| `Cash_Buyer_Bypass_Regulation` | `weakens` | `Mortgage_Regulation_Channel` | `non_levered_demand` |
| `Mortgage_Regulation_Channel` | `loses_efficacy_vs` | `Housing_Regulation_Beyond_Bank_Channel` | `regime_shift` |
| `MOLIT_Supply_Plan_Small_Plot_Bias` | `fails_to_restore` | `Rental_Public_Supply_Policy_Gap` | `supply_design` |
| `NonApartment_Housing_Market_Collapse` | `shifts_tenants_to` | `Jeonse_Wolse_Pressure_Apartments` | `stock_substitution` |
| `Rental_Public_Supply_Policy_Gap` | `amplifies` | `Jeonse_Wolse_Pressure_Apartments` | `rent_squeeze` |
| `Jeonse_Wolse_Pressure_Apartments` | `supports` | `Affordable_Quintile_Housing_3rd_Below` | `rent_to_own_hedge` |
| `Hedge_Demand_Occupier` | `supports` | `Affordable_Quintile_Housing_3rd_Below` | `occupier_hedge` |
| `Property_Tax_Reform_Uncertainty` | `induces` | `Housing_Market_Wait_and_See` | `policy_option_value` |
| `Housing_Market_Wait_and_See` | `pressures` | `High_End_Quintile_Housing_5th` | `sideways_volume_cliff` |
| `Property_Tax_Reform_Uncertainty` | `adds_burden_narrative_to` | `High_End_Quintile_Housing_5th` | `holding_cost` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`) — “왜 양극화·관망인가?”

- **지역 강세:** **하이닉스** **인센티브·직원 규모**가 **실질 구매력**을 만들고, **셔틀 노선** 단지에 **수요 집중** → **용인·송파** 등 **세력권** **급등** 서사 *(01:21)*, *(02:12)*.
- **규제 무력화:** **미국 주식** 등 **자산 증가**로 **현금 매수** → **은행 대출 규제**만으로는 **가격 하락 압력**을 주기 어렵다는 **국면 전환** *(02:38)*, *(03:06)*, *(02:56)*.
- **공급:** **국토부** 계획이 **임대·장기 공급**보다 **소필지**에 치우쳐 **시장 신뢰**가 낮다는 **의지·설계** 비판 *(15:52)*, *(19:07)*.
- **임대:** **빌라 등 비아파트** 약화로 **임차 수요**가 **아파트**로 몰리는데 **임대 공급 대책**이 부재 → **전월세** 상방 *(13:09)*, *(22:16)*.
- **관망:** **보유세·다주택** **개편 불확실** → 매도·매수 **유보** *(03:55)*, *(07:05)*.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`) — “무엇이 어떻게 되는가?”

- **양극화:** **특정 기업 수혜·셔틀권**은 **강세**, **고가(5분위)**는 **관망·횡보·거래 절벽** 가능.
- **전월세·중저가:** **전월세**는 **상승** 압력, **매매**는 **하방 지지** 서사; **3분위 이하**는 **실거주·임대료 헤지** 수요로 **견조** *(21:55)*.
- **메타:** **금융 규제 중심** 프레임에서 **현금·보너스·해외자산**이 결합된 **수요**로 이동했다는 **진단** *(02:56)*.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF SK_Hynix_Profit_Linked_Incentive AND SK_Hynix_Employee_Buyer_Cohort
THEN concentrated demand_on Shuttle_Corridor_Preferred_Clusters END
IF Retail_US_Equity_Wealth_Channel THEN Cash_Buyer_Bypass_Regulation strengthens END
IF Cash_Buyer_Bypass_Regulation THEN Mortgage_Regulation_Channel weakens_for_price_control END
IF MOLIT_Supply_Plan_Small_Plot_Bias THEN Rental_Public_Supply_Policy_Gap persists END
IF NonApartment_Housing_Market_Collapse THEN Jeonse_Wolse_Pressure_Apartments rises END
IF Property_Tax_Reform_Uncertainty THEN Housing_Market_Wait_and_See AND High_End_Quintile_Housing_5th sideways END
IF Affordable_Quintile_Housing_3rd_Below AND Hedge_Demand_Occupier THEN resilient_price_path END
```

```mermaid
flowchart TB
  INC[SK_Hynix_Profit_Linked_Incentive] --> BUY[SK_Hynix_Employee_Buyer_Cohort]
  BUY --> SHU[Shuttle_Corridor_Preferred_Clusters]
  EQ[Retail_US_Equity_Wealth_Channel] --> CASH[Cash_Buyer_Bypass_Regulation]
  CASH -.->|weakens| MORT[Mortgage_Regulation_Channel]
  MOL[MOLIT_Supply_Plan_Small_Plot_Bias] --> GAP[Rental_Public_Supply_Policy_Gap]
  NON[NonApartment_Housing_Market_Collapse] --> JW[Jeonse_Wolse_Pressure_Apartments]
  GAP --> JW
  TAX[Property_Tax_Reform_Uncertainty] --> WAIT[Housing_Market_Wait_and_See]
  WAIT --> HI[High_End_Quintile_Housing_5th]
  JW --> AFF[Affordable_Quintile_Housing_3rd_Below]
  HD[Hedge_Demand_Occupier] --> AFF
```

---

<a id="evidence-data"></a>

## 6. Evidence — 타임스탬프(메모)

| 시각 | 주제 |
|------|------|
| 01:21 | 하이닉스 인센티브·영업이익 연동 |
| 02:12 | 직원 3만 명·셔틀권(강동·송파·용인·청주)·급등 |
| 02:38 | 자금 조달 다각화·대출 규제 한계 |
| 02:56 | 금융 규제로는 막기 어려운 구간 |
| 03:06 | 미국 주식 수익·현금 체력 |
| 03:55 | 보유세·다주택 규제 불확실 |
| 07:05 | 관망·눈치보기 보강 |
| 13:09 | 비아파트·임차 쏠림 |
| 15:52 | 국토부 공급 계획·소필지 |
| 19:07 | 장기 공급 회복 기대 약화 |
| 21:55 | 5분위 vs 3분위 이하 전망 |
| 22:16 | 비아파트 붕괴·전월세 구조 |

---

<a id="summary"></a>

## 7. 결론(메타)

영상 논지는 **(1) 기업 보너스·셔틀권**과 **(2) 증시 부의 현금화**가 **대출 규제**를 **우회**하는 **수요 레짐**과, **(3) 임대 공급 설계 공백**·**(4) 세제 불확실성**이 맞물려 **지역 스파이크 + 고가 관망 + 전월세 상방 + 중저가 견조**로 **분해된 국면**을 그린다. [이현철 영상](korea-housing-policy-bear-causality-lee-video.md)의 **정책 하방** 서사와 **축이 다름**을 유의한다.

---

## Named entity 링크 (문서 간)

| Entity / 개체 | 유형 | 연결 |
|-----------------|------|------|
| Chae_SangWook | Person | 이 문서, [증시·ODM·AI](chae-sangwook-korea-us-odm-ai-kospi-causality.md) |
| SK하이닉스(인센티브·직원 수요) | Organization / flow | 이 문서 |
| 이현철·정책 하방 | Cross-ref | [korea-housing-policy-bear-causality-lee-video.md](korea-housing-policy-bear-causality-lee-video.md) |
| 홍춘욱·부동산 반등 | Cross-ref | [hong-chunwook-macro-rebound-causality-video.md](hong-chunwook-macro-rebound-causality-video.md) |
| 장특 폐지 논쟁 (2026-04 메모) | Policy / tax | [korea-cgt-longterm-holding-deduction-policy-debate.md](korea-cgt-longterm-holding-deduction-policy-debate.md) |

---

## 관련 문서

- [한국 증시·미국 제조 ODM·AI (채상욱 영상)](chae-sangwook-korea-us-odm-ai-kospi-causality.md): 동일 화자 **증시·반도체** 서사.
- [한국 주택·정책 하방 (이현철 영상)](korea-housing-policy-bear-causality-lee-video.md): **규제·하방** 강조 **대비** 인과.
- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): **공급·반등** 서사 **대비**.
- [국내 증시·선행지수 (김영익, 영상)](korea-kospi-leading-indicator-causality.md): **주식 부** 채널과 연결.
- [반도체 수출·구리·코스피 (홍춘욱 영상)](hong-chunwook-semiconductor-copper-kospi-causality.md): **반도체 호황·이익**이 본 문서 **인센티브·수요**와 맞닿는 축.
- [유가·에너지·물가 전망 (메모)](macro-energy-inflation-outlook.md): 거시 **허브**.
- [양도세 장특 폐지 논쟁 (정책 메모)](korea-cgt-longterm-holding-deduction-policy-debate.md): **장특** 정의·**여야 프레임**·**점진 폐지·법률 잠금** 서술.

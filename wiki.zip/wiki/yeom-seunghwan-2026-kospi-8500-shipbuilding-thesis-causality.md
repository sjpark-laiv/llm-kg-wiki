---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# 2026 한국 증시·코스피 8,500·조선 주도주 (염승환 이사, RCA·Impact)

**목적:** 염승환 이사 발화 요약에서 **코스피 8,500 상방 시나리오**와 **조선주 중심 주도 논리**를 RCA·Impact 관점으로 구조화한다.

---

<a id="entities"></a>

## 1. 핵심 Entity

| Entity ID | 한글·설명 | 연결 |
|-----------|-----------|------|
| **`Yeom_SeungHwan`** | 염승환 이사 | [entity/yeom-seunghwan.md](entity/yeom-seunghwan.md) |
| **`KOSPI_Index`** | 코스피 지수 | [entity/kospi-index.md](entity/kospi-index.md) |
| **`Korea_Shipbuilding_Structural_Resurgence`** | 한국 조선 재도약 | [entity/korea-shipbuilding-structural-resurgence.md](entity/korea-shipbuilding-structural-resurgence.md) |
| **`Valuation_Multiples_PER_PBR`** | PER·PBR 멀티플 | [entity/valuation-multiples-per-pbr.md](entity/valuation-multiples-per-pbr.md) |
| **`US_Naval_Shipbuilding_MRO_Outsourcing_Korea`** | 미 군함·MRO 발주 확대 | [entity/us-naval-shipbuilding-mro-outsourcing-korea.md](entity/us-naval-shipbuilding-mro-outsourcing-korea.md) |

---

<a id="causality-map"></a>

## 2. Causality Map

| 축 | 원인 | 결과 | 태그 |
|----|------|------|------|
| 조선-엔진 | AI 전력 병목 | 선박 엔진 수요·실적 상향 | `RCA`+`Impact` |
| 조선-군함 | 미 군함 인프라 제약·지정학 | 한국 군함·MRO 발주 확대 | `RCA`+`Impact` |
| 조선-실적 | 공급 부족 + 인력 정상화 | 이익 개선·주가 재평가 | `Impact`+`Evidence` |
| 증시-밸류 | 코스피 저PER | 평균 회귀 시 8,000~8,500 상방 | `RCA`+`Impact` |
| 증시-국면 | 악재 둔감화·실적 집중 | 하방 경직·우상향 지속 | `Impact` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`)

- **조선을 실체 주도주로 분류:** 수주·실적·지정학 수요가 동시에 존재한다는 주장.
- **AI 전력 병목:** 데이터센터 전력 부족이 엔진 수요의 비전통 경로를 만든다는 해석 *(28:39)*.
- **군함 발주 구조:** 미국의 건조 역량·비용 제약, 미중 경쟁이 한국 조선소 선택 압력을 높인다는 서술 *(30:41, 30:58)*.
- **밸류 논리:** 코스피 PER이 역사 평균 대비 낮아 멀티플 정상화 여지가 크다는 주장 *(03:52)*.

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`)

- **조선 섹터:** 엔진·군함·상선 수요가 결합되며 업황의 내구성이 강화될 수 있음.
- **이익 가시성:** 수주잔고와 마진 회복이 동시에 확인되면 주가 재평가 강도가 커질 수 있음 *(15:09, 31:50)*.
- **지수 경로:** 실적 중심 장세 전환 시 코스피 하방 경직성과 상방 추세 지속 가능성.

---

<a id="evidence-data"></a>

## 5. Evidence (타임코드)

| 시각 | 포인트 |
|------|--------|
| 03:52 | 코스피 PER 8배 미만 vs 장기 평균 9.8배 |
| 04:02 | 평균 멀티플 환산 시 8,000+ 논리 |
| 09:07 | 실적 중심 장세 전환 언급 |
| 09:44 | 전쟁 이슈 민감도 둔화 |
| 12:38 | 조선주 핵심 수혜주 제시 |
| 15:09 | 수주잔고·실적 확인 |
| 28:39 | 데이터센터 전력 부족·엔진 대안 |
| 29:27 | 힘센 엔진 수혜 맥락 |
| 30:41 | 미 군함 건조·MRO 한국 협력 필요 |
| 30:58 | 미 군함 건조 역량 열위 진단 |
| 31:50 | 인력 숙련도 개선·마진 정상화 |

---

<a id="related-rel"></a>

## 6. 관련 인과 문서

- [AI 전력 부족 → 선박 엔진 수요 → 조선사 이익](rel/ai-datacenter-power-gap-to-marine-engine-demand-in-shipbuilders.md)
- [미 군함 인프라 부족 → 한국 조선·MRO 발주](rel/us-naval-capacity-gap-to-korea-shipbuilding-mro-orders.md)
- [공급 부족·인력 정상화 → 조선 실적·재평가](rel/ship-supply-shortage-and-labor-normalization-to-shipbuilder-earnings-rerating.md)
- [코스피 저PER → 8,500 상방 시나리오](rel/low-kospi-per-to-kospi-8500-upside-scenario.md)
- [악재 둔감화·실적장세 → 코스피 랠리 지속](rel/risk-noise-desensitization-to-fundamental-led-kospi-rally.md)

---

<a id="summary"></a>

## 7. 결론(메타)

요약의 핵심은 **조선주의 실적 기반 확장성(엔진·군함·기존 상선)**과 **코스피의 저평가 멀티플 복원 가능성**을 결합해, 2026년 한국 증시 상방을 설명하는 **복합 낙관 시나리오**다.

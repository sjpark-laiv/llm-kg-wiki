---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# DRAM 마진(소프트웨어급 수준)

<a id="summary"></a>

## 개요

요약에 따르면 **DRAM 마진**이 **약 80%**에 달해, 과거 반도체 **하드웨어 제조사** 수준이 아니라 **고수익 소프트웨어 기업**에 준하는 **이익률(뉴 노멀)** 로 서술된다 *(02:10)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [DRAM 마진·가격 → 이익 전망 급상향](../rel/dram-margin-and-prices-to-earnings-forecast-surge.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`DRAM_Margin_SoftwareLike`** | DRAM 고마진 | **DRAM 이익률**이 **SW급**으로 **구조적 상향**됐다는 **주장 축**. |

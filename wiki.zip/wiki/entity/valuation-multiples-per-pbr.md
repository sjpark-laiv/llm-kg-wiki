---
wiki_created: 2026-04-19
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# PER·PBR 멀티플

<a id="summary"></a>

## 개요

**ROE**가 **20%대**로 올라간 국면에서는 **PER**(주가수익비율)·**PBR**(주가순자산비율) 등 **밸류에이션 멀티플**이 과거보다 **높게 측정될 정당성**이 생긴다는 해석이 제시된다 *(02:30)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [ROE 상승 → 멀티플 재평가 근거](../rel/roe-to-valuation-multiples-per-pbr.md)
- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)
- [코스피 저PER → 8,500 상방 시나리오](../rel/low-kospi-per-to-kospi-8500-upside-scenario.md)
- [공급 부족·인력 정상화 → 조선 실적·재평가](../rel/ship-supply-shortage-and-labor-normalization-to-shipbuilder-earnings-rerating.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Valuation_Multiples_PER_PBR`** | PER·PBR 멀티플 | **주가 대비 이익·순자산** 배수. 요약에서는 **ROE 개선**과의 **정합성** 논증에 사용. |

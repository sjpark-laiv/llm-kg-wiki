---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 메모리 반도체 이익(뉴 노멀)

<a id="summary"></a>

## 개요

요약은 **메모리 반도체** 이익이 **일시적 피크아웃**이 아니라 **2027년**까지도 **성장 지속**으로 **컨센서스가 상향**되는 흐름을 강조한다 *(10:48)*. 이익이 **뉴 노멀**로 이동한다는 서술과 연결된다 *(03:55)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)
- [이익·저평가 괴리 → 한국 비중 논리](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Memory_Semiconductor_Earnings_NewNormal`** | 메모리 이익(뉴 노멀) | **구조적·지속적 이익 국면**으로 읽히는 **메모리 섹터 이익** 서술(영상 요약 주장). |

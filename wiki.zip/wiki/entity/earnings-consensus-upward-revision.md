---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 이익 컨센서스 상향

<a id="summary"></a>

## 개요

**반도체 기업** **이익**이 **2027년**까지 **성장 지속** 쪽으로 **컨센서스가 상향**된다는 서술이 있다 *(10:48)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Earnings_Consensus_Upward_Revision`** | 이익 컨센서스 상향 | 애널리스트·시장 **기대 이익 경로**의 **상향 조정**(요약 주장). |

---
wiki_created: 2026-04-23
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# AI 에이전트 패러다임 (학습 → 추론 → 에이전트)

<a id="ai-agent-paradigm"></a>

## 개요

AI가 **학습** 단계를 넘어 **추론** 단계를 거쳐, 스스로 계획하고 실행하는 **에이전트(AI 비서)** 단계로 진화하고 있다는 개념. [염승환](yeom-seunghwan.md) 이사에 따르면 에이전트 단계에서는 **CPU의 역할이 비약적으로 중요해지며**, 이는 GPU 옆의 HBM이 아닌 CPU 옆의 **범용 메모리([DDR5](ddr5-general-purpose-dram.md))** 수요 폭증으로 이어진다. [28:30]

기존 [AI 추론 패러다임](ai-inference-paradigm-shift.md)의 **다음 단계**에 해당한다.

## 핵심 구조

- **학습 단계**: GPU + HBM 중심 → [엔비디아](nvidia.md) 독점
- **추론 단계**: GPU + HBM + 범용 DRAM 혼용 → [삼성전자](samsung-electronics.md) 수혜 시작
- **에이전트 단계**: **CPU 역할 비약적 확대** → [인텔](intel.md) 재평가 + [DDR5](ddr5-general-purpose-dram.md) 수요 폭증 → [삼성전자](samsung-electronics.md) 범용 메모리 강점 극대화

## 관련 인과관계 (교차 링크)

- [AI 에이전트·CPU 수요 → 범용 메모리(DDR5) 수요 폭증](../rel/ai-agent-cpu-to-general-dram-demand.md)
- [AI 추론 → KV 캐시 수요](../rel/ai-inference-paradigm-to-kv-cache-demand.md)
- [KV·추론 → DDR5 혼용·긴장](../rel/kv-cache-inference-to-ddr5-mix-and-tightening.md)

## 관련 문서

- [AI 패러다임(학습 → 추론)](ai-inference-paradigm-shift.md) — 선행 단계
- [DDR5 범용 DRAM](ddr5-general-purpose-dram.md) · [HBM](hbm-memory-product.md)
- [삼성전자](samsung-electronics.md) · [인텔](intel.md) · [엔비디아](nvidia.md)
- [염승환 이사](yeom-seunghwan.md)

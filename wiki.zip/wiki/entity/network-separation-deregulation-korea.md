---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 망분리 규제 완화 (한국 금융권)

<a id="network-separation-deregulation-korea"></a>

## 개요

국내 금융당국이 금융기관의 외부망 접속을 단계적으로 완화하는 정책 기조. 기존에는 금융권 외부망 접속이 엄격히 제한되어 AI 클라우드 서비스 활용에 한계가 있었으나, 규제 완화로 안전한 외부망 접속 솔루션 수요가 급증하고 있다.

## 배경

- 금융권은 보안을 위해 내부망과 외부망을 물리적으로 분리 운영
- AI·클라우드 시대에 외부망 접속 필요성 증가 → 규제 완화 논의 본격화
- 단계적 완화 → 안전한 외부망 접속 보장 솔루션 수요 창출

## 수혜 기업·제품

- [소프트캠프](softcamp.md)의 [실드게이트(SHIELD Gate)](shieldgate.md): 로컬 PC 무설치로 외부망 접속 허용 → 규제 적합

## 관련 인과관계 (교차 링크)

- [망분리 규제 완화 → 소프트캠프 실적 성장](../rel/network-separation-deregulation-to-softcamp-growth.md)
- [실드게이트 RBI → 금융·공공·민간 보안시장 확대](../rel/shieldgate-rbi-to-security-market-expansion.md)

## 관련 문서

- [소프트캠프](softcamp.md)
- [실드게이트](shieldgate.md)
- [금융감독원](fss-korea.md)

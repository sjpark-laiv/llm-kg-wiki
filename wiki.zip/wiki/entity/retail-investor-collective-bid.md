---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 개인 투자자 집단지성·수급

<a id="summary"></a>

## 개요

**외국인**이 **비중 조절**을 위해 **파는 물량**을 **개인 투자자**가 **집단지성**으로 **받아낸다**는 서술이 있다 *(17:36 요약)*. **시장을 떠받치는 수급 기반** 강화 논리와 연결된다 *(13:58)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [외국인 기계적 매도 → 국내 수급·머니무브](../rel/foreign-mechanical-selling-to-domestic-bid-strength.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Retail_Investor_Collective_Bid`** | 개인 집단지성 매수 | **개인 군집**의 **순매수·흡수**로 읽히는 수급(요약 주장). |

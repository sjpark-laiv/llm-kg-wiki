---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 실드게이트 (SHIELD Gate)

<a id="shieldgate"></a>

## 개요

[소프트캠프(Softcamp, 258790)](softcamp.md)의 핵심 보안 제품. [RBI(원격 브라우저 격리)](rbi-remote-browser-isolation.md) 방식으로 로컬 PC에 아무것도 설치하지 않고 외부 웹 접속을 허용하는 **원천 차단 보안 솔루션**.

## 기술 구조

- **원격 브라우저 격리(RBI)**: 외부 웹 작업은 별도 원격 서버에서 수행
- **화면 전송 방식**: 로컬 PC에는 화면만 전송 — 악성코드 침투 경로 자체가 없음
- **무설치**: 별도 장비·로컬 소프트웨어 설치 불필요
- 기존 물리적 이중화 단말이나 가상 PC 방식과 동일 효과 + 보안성 상위 평가

## 미토스 대응 역량

[미토스(Mythos)](mythos-ai-agent.md)와 같은 AI 기반 해킹 도구가 로컬 PC의 취약점을 공격하는 반면, 실드게이트는 로컬 PC에 공격 대상 자체가 없어 **침입을 원천 차단**(사전적 방어).

[이충헌](lee-chung-hun.md) [밸류파인더](valuefinder-research.md) 대표: "침입 자체를 원천 차단하는 사전적 방어가 가능해 금감원이 로컬 PC의 외부 프로그램 설치를 최소화하려는 규제 강화 흐름과도 정확히 부합한다"

## 타겟 시장별 영향력

| 시장 | 진입 단계 | 영향력 |
|------|-----------|--------|
| **금융권** | 주력 | 매우 높음 — [망분리 규제 완화](network-separation-deregulation-korea.md)와 맞물려 수요 급증 |
| **공공기관** | 확대 중 | 높음 — 공공 보안 규제 대응 |
| **민간기업** | 초기 | 성장 잠재력 큼 — RBI 수요 구조적 확산 |

## 관련 인과관계 (교차 링크)

- [미토스 등장 → 실드게이트 수요 급증](../rel/mythos-to-shieldgate-demand.md)
- [실드게이트 RBI → 금융·공공·민간 보안시장 확대](../rel/shieldgate-rbi-to-security-market-expansion.md)
- [망분리 규제 완화 → 소프트캠프 실적 성장](../rel/network-separation-deregulation-to-softcamp-growth.md)

## 관련 문서

- [소프트캠프](softcamp.md)
- [RBI](rbi-remote-browser-isolation.md)
- [EDR](edr-endpoint-security.md) — 실드게이트와 대비되는 기존 방식
- [미토스](mythos-ai-agent.md) — 실드게이트가 방어하는 위협

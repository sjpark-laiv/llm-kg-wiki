---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(강관우·이선엽 등)
---

# 외국인 기계적 매도(비중 조절)

<a id="summary"></a>

## 개요

**외국인**의 **대규모 매도**가 **펀더멘털 악화**보다는 **지수 내 비중 과대**에 따른 **잔디 깎기식** **기계적 조절**에 가깝다는 진단이 있다 *(17:44)*.

**이선엽 대표 요약 맥락:** **펀드 내 비중 상한(예: 25%)** 등 **규정**으로 **주가 상승** 시 **자동 매도**가 나온다는 **별도 메커니즘**이 있다 — [펀드 비중 규정 매도](foreign-fund-weight-cap-selling-korea.md) · [펀드 비중 → 노이즈 vs 유입](../rel/foreign-fund-weight-cap-selling-to-flow-noise-and-inflows.md).

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [외국인 기계적 매도 → 국내 수급·머니무브](../rel/foreign-mechanical-selling-to-domestic-bid-strength.md)
- [펀드 비중 규정 매도 vs 장기 유입](../rel/foreign-fund-weight-cap-selling-to-flow-noise-and-inflows.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Foreign_Investor_Mechanical_Selling`** | 외국인 기계적 매도 | **규칙·비중 한도**에 따른 **패시브적 매도**로 읽히는 흐름(요약 주장). |

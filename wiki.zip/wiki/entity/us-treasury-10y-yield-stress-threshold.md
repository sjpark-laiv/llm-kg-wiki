---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 미국 10년 국채 금리(4.5% 이상 스트레스)

<a id="summary"></a>

## 개요

**미국 국채 10년물 금리**가 **4.5% 이상**으로 **치솟을 경우** **리스크**가 **불거질 수 있다**는 조건이 제시된다 *(07:03)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [사모대출·금리 → 단기 변동성](../rel/private-credit-yields-to-near-term-volatility-low-crisis-transmission.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`US_Treasury_10Y_Yield_Stress_Threshold`** | 10Y 금리 임계 | **할인율·금리 민감 자산**에 대한 **스트레스 트리거** 서술. |

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 미국 선박 건조·수리 용량 부족

<a id="summary"></a>

## 개요

**미국**은 **에너지 수출국**이지만, 이를 **실어 나를 선박**의 **건조·수리 능력**이 **매우 부족**하다는 진단이 있다 *(01:11)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [미 해운·IMO·지정학 → 한국 조선](../rel/us-maritime-imo-geopolitics-to-korea-shipbuilding-resurgence.md)
- [미 군함 인프라 부족 → 한국 조선·MRO 발주](../rel/us-naval-capacity-gap-to-korea-shipbuilding-mro-orders.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`US_Marine_Shipbuilding_Capacity_Constraint`** | 미 해운·조선 병목 | **수출 실물 이동** 대비 **선박 공급**의 **구조적 부족**. |

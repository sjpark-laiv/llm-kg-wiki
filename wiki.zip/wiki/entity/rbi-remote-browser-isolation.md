---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# RBI (Remote Browser Isolation, 원격 브라우저 격리)

<a id="rbi"></a>

## 개요

웹 브라우징 활동을 로컬 PC가 아닌 원격 서버에서 실행하고, 로컬에는 화면만 전송하는 보안 기술. 로컬에 소프트웨어를 설치하지 않으므로 악성코드 침투 경로를 원천 차단한다.

## 기존 보안 방식과의 비교

| 구분 | RBI | EDR 등 로컬 설치형 |
|------|-----|---------------------|
| 설치 여부 | 로컬 PC **무설치** | 로컬 PC에 소프트웨어 설치 |
| 방어 방식 | 공격 경로 **원천 차단** (사전적) | 침입 탐지·대응 (사후적) |
| AI 해킹 대응 | [미토스](mythos-ai-agent.md) 등 공격 대상 자체 없음 | 취약점 노출 위험 |

## 대표 제품

- [실드게이트(SHIELD Gate)](shieldgate.md) — [소프트캠프](softcamp.md)

## 관련 인과관계 (교차 링크)

- [미토스 등장 → 실드게이트 수요 급증](../rel/mythos-to-shieldgate-demand.md)
- [실드게이트 RBI → 금융·공공·민간 보안시장 확대](../rel/shieldgate-rbi-to-security-market-expansion.md)

## 관련 문서

- [실드게이트](shieldgate.md)
- [EDR](edr-endpoint-security.md)

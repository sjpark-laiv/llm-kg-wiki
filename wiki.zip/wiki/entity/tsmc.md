---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# TSMC

<a id="summary"></a>

## 개요

**한국 메모리 기업**의 **이익 추정**이 **TSMC**보다 **높게** 거론된다는 비교가 요약에 포함된다 *(09:58)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`TSMC`** | TSMC | **대만 파운드리 대표** 기업. 요약의 **글로벌 반도체 이익 비교** 벤치마크. |

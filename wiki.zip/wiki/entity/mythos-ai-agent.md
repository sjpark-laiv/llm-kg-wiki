---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 미토스 (Mythos) — AI 보안 에이전트

<a id="mythos-ai-agent"></a>

## 개요

[앤스로픽(Anthropic)](anthropic.md)이 공개한 AI 기반 보안 에이전트. 27년간 검증된 [OpenBSD](openbsd.md)의 취약점을 단 몇 분 만에 찾아내고, 리눅스 서버 장악 경로까지 자율 설계하는 능력을 시연했다.

## 핵심 능력

- **취약점 자동 탐색**: 고보안 OS인 [OpenBSD](openbsd.md)에서 취약점을 분 단위로 발견
- **공격 경로 자율 설계**: 리눅스 서버 장악 시나리오 스스로 설계
- **로컬 PC 보안 무력화**: [EDR](edr-endpoint-security.md) 등 로컬 설치형 보안 소프트웨어의 구조적 한계를 노출

## 시장 충격

- 전 세계 보안 업계에 "AI 기반 해킹 도구" 시대 도래를 각인
- [금융감독원](fss-korea.md): 금융기관 보안 실무자 긴급 소집, [EDR](edr-endpoint-security.md) 등 점검 지시
- [과학기술정보통신부](msit-korea.md): 통신 3사 및 주요 플랫폼사 CISO 대상 긴급 현안점검회의 개최

## 관련 인과관계 (교차 링크)

- [미토스 등장 → 기존 보안체계 위기](../rel/mythos-to-legacy-security-crisis.md)
- [미토스 등장 → 실드게이트 수요 급증](../rel/mythos-to-shieldgate-demand.md)
- [미토스 등장 → 금융당국 규제 대응](../rel/mythos-to-regulatory-response.md)

## 관련 문서

- [앤스로픽](anthropic.md)
- [OpenBSD](openbsd.md)
- [EDR](edr-endpoint-security.md)
- [소프트캠프](softcamp.md) — 미토스 대응 솔루션 보유
- [실드게이트](shieldgate.md) — 원천 차단 기술로 미토스 방어

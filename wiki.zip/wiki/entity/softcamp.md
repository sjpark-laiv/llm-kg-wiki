---

## wiki_created: 2026-04-23
content_as_of: 2026-04-20

# 소프트캠프 (Softcamp, 258790)



## 개요

코스닥 상장 보안 기업 (종목코드: 258790). 핵심 제품인 **[실드게이트(SHIELD Gate)](shieldgate.md)**를 통해 [RBI(원격 브라우저 격리)](rbi-remote-browser-isolation.md) 기반 보안 솔루션을 공급한다.

## 실적 (밸류파인더 리서치 기준)


| 연도   | 매출액   | 영업이익  | 비고                |
| ---- | ----- | ----- | ----------------- |
| 2024 | 169억원 | −18억원 | 영업손실              |
| 2025 | 257억원 | +30억원 | **흑자 전환 — 턴어라운드** |


- 2025년 기준 전체 매출의 **70.1%**가 보안 솔루션 부문에서 발생

## 성장 동인

- [미토스(Mythos)](mythos-ai-agent.md) 사태로 인한 RBI 수요 급증
- [망분리 규제 완화](network-separation-deregulation-korea.md) 기조 — 금융권 외부망 접속 허용 확대
- 금융권 → 공공 → 민간으로 시장 확대 전망

## 주요 제품

- **[실드게이트(SHIELD Gate)](shieldgate.md)**: RBI 기반 원천 차단 보안 솔루션

## 관련 인과관계 (교차 링크)

- [망분리 규제 완화 → 소프트캠프 실적 성장](../rel/network-separation-deregulation-to-softcamp-growth.md)
- [미토스 등장 → 실드게이트 수요 급증](../rel/mythos-to-shieldgate-demand.md)
- [실드게이트 RBI → 금융·공공·민간 보안시장 확대](../rel/shieldgate-rbi-to-security-market-expansion.md)

## 관련 문서

- [실드게이트](shieldgate.md)
- [RBI](rbi-remote-browser-isolation.md)
- [밸류파인더](valuefinder-research.md) · [이충헌 대표](lee-chung-hun.md)
---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 샌디스크

<a id="summary"></a>

## 개요

**마이크론**과 함께 언급되며, **한국 메모리 2사** 대비 **기술·이익 체력** 면에서 **매력이 낮다**는 **선호순위** 논의에 등장한다 *(44:14)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [이익 전망 vs 주가 → 목표가](../rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Sandisk`** | 샌디스크 | **저장** 관련 기업(요약 맥락). **한국 대형 메모리**와의 **비교 축**. |

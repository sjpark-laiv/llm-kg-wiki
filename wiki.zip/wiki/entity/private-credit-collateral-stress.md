---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 사모 대출(Private Credit) 담보·적정성 스트레스

<a id="summary"></a>

## 개요

**비상장 소프트웨어 기업** 등에 대출한 **사모 펀드**들의 **담보 적정성** 문제가 **제기**되고 있다는 서술이 있다 *(06:21)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [사모대출·금리 → 단기 변동성](../rel/private-credit-yields-to-near-term-volatility-low-crisis-transmission.md)
- [사모대출 조정 → 은행 중심 재편](../rel/private-credit-workout-to-bank-centric-loan-market.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Private_Credit_Collateral_Stress`** | 사모대출 리스크 | **비유동·정보 비대칭** 담보에 대한 **신용 품질** 우려. |

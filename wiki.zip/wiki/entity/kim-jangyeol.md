---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(김장열 본부장)
---

# 김장열 본부장

<a id="summary"></a>

## 개요

영상 요약에서 **김장열** 본부장은 **반도체 업황**의 **본질적 변화**를 설명하고, **현재 메모리 대형주**에 대한 **투자 전망을 강하게 긍정**한다. **“지금 사도 늦지 않았다”**는 취지의 단언과, **2027년 상반기**까지 **공급 부족·이익 성장**이 **보장된 환경**이라는 **보유 전략** 메시지가 요약된다.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [통합 RCA·Impact 메모](../kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md)
- [DRAM 마진·가격 → 이익 전망 급상향](../rel/dram-margin-and-prices-to-earnings-forecast-surge.md)
- [AI 추론 → KV 캐시 수요](../rel/ai-inference-paradigm-to-kv-cache-demand.md)
- [증설 시차 → 2027 공급 부족](../rel/memory-fab-lag-to-under-supply-through-2027.md)
- [KV·추론 → DDR5 혼용·긴장](../rel/kv-cache-inference-to-ddr5-mix-and-tightening.md)
- [고ROE·저PER → 성장 리레이팅](../rel/high-roe-low-per-cycle-frame-to-growth-rerating.md)
- [이익 전망 vs 주가 → 목표가](../rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md)
- [삼성 파운드리 → 시총 업사이드](../rel/samsung-foundry-profit-orders-to-mcap-upside.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Kim_JangYeol`** | 김장열 본부장 | Person. 본 요약의 **발화자·투자 논증 주체**. |

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 메모리 대형주 ROE·PER 괴리

<a id="summary"></a>

## 개요

**ROE**는 **50~90%**에 달하는데 **PER**는 **4~6배**에 머물러 있다는 대비가 제시된다. 시장이 반도체를 여전히 **사이클 주식**으로 **보수 평가**한다는 진단과, 인식이 **성장주**로 바뀌며 **대규모 리레이팅**이 온다는 전망이 이어진다 *(16:20)*, *(18:27)*.

> 주의: 본 노드는 **특정 화자·요약 맥락의 수치**이며, 저장소의 다른 문서(예: 시장 전체 ROE 서술)와 **숫자 범위가 다를 수 있음**.

**시장 전체 ROE 축:** 코스피·대형주 **13~14% → 20~25%** 서술은 [ROE(엔티티)](roe.md) · [ROE → 멀티플](../rel/roe-to-valuation-multiples-per-pbr.md) · [이익·저평가 → 한국 비중](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)와 연결된다. **메모리 주식 ROE**와 **혼동하지 않을 것**.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [고ROE·저PER·사이클틀 → 성장 리레이팅](../rel/high-roe-low-per-cycle-frame-to-growth-rerating.md)
- [이익 전망 vs 주가 → 목표가](../rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Memory_Equity_HighROE_LowPER`** | 고ROE·저PER | **메모리 대형주**에 대한 **수익률 vs 배수** 괴리 및 **프레임(사이클)** 논의. |

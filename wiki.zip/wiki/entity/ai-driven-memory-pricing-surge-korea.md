---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(이선엽 대표)
---

# AI 수요·한국 메모리 가격 급등(고정가)

<a id="summary"></a>

## 개요

**AI 산업 변화**가 시장 강세의 **핵심 동력**이라는 서술과 함께, **미국**이 **AI·로봇 제조**를 육성한다는 맥락이 있다 *(08:05)*. **삼성전자·SK하이닉스** 등 **한국 반도체** 제품 **가격(고정가)** 이 **달마다 50% 이상** 급등하는 등 **가격이 천문학적으로 오른다**는 진술이 있다 *(18:09)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [AI·메모리 가격 급등 → 실적 전망 vs 주가·증시](../rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`AI_Driven_Memory_Pricing_Surge_Korea`** | AI·메모리 ASP 급등 | **공급 제약** 대비 **AI 수요**가 커지며 **메모리 가격**이 **급격히 상승**한다는 서사. |

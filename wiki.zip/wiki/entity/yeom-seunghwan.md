---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 염승환 이사

<a id="summary"></a>

## 개요

**염승환** 이사는 2026년 한국 증시에 대해 **코스피 8,500선**까지의 상방 시나리오를 제시하며, 특히 **조선주**를 실적·수주·안보 축이 결합된 핵심 주도주로 강조한다.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [AI 전력 부족 → 선박 엔진 수요 → 조선사 이익](../rel/ai-datacenter-power-gap-to-marine-engine-demand-in-shipbuilders.md)
- [미 군함 인프라 부족 → 한국 조선·MRO 발주](../rel/us-naval-capacity-gap-to-korea-shipbuilding-mro-orders.md)
- [공급 부족·인력 정상화 → 조선 실적·재평가](../rel/ship-supply-shortage-and-labor-normalization-to-shipbuilder-earnings-rerating.md)
- [코스피 저PER → 8,500 상방 시나리오](../rel/low-kospi-per-to-kospi-8500-upside-scenario.md)
- [악재 둔감화·실적장세 → 코스피 랠리 지속](../rel/risk-noise-desensitization-to-fundamental-led-kospi-rally.md)
- [빅테크 CAPEX 전환 → 한국 반도체 매출](../rel/bigtech-capex-to-korea-semiconductor-revenue.md)
- [AI 에이전트·CPU → DDR5 수요 폭증](../rel/ai-agent-cpu-to-general-dram-demand.md)
- [AI 효용 체감 → 한국 반도체 400조 실적 확신](../rel/ai-enterprise-efficacy-to-korea-400t-earnings-conviction.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Yeom_SeungHwan`** | 염승환 이사 | 2026년 **코스피 상방**과 **조선업 주도주** 서사를 제시한 발화 주체. |

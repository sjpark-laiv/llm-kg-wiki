---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 마이크론

<a id="summary"></a>

## 개요

**신규 케파**가 **시장에 의미 있게 반영**되는 시점이 **2027년 하반기** 경이라는 **공급 시차** 논증에 등장한다 *(15:30)*. **투자 선호**에서는 **SK하이닉스·삼성전자** 대비 **열위**로 거론된다 *(44:14)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [증설 시차 → 2027 공급 부족](../rel/memory-fab-lag-to-under-supply-through-2027.md)
- [이익 전망 vs 주가 → 목표가](../rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Micron`** | 마이크론 | **미국 메모리** 기업. 요약에서 **증설 타임라인**·**상대 선호** 비교에 사용. |

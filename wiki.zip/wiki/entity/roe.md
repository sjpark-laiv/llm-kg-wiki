---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# ROE(자기자본이익률)

<a id="summary"></a>

## 개요

과거 코스피 **6,000** 시절 **ROE**는 **13~14%** 수준이었으나, 현재는 **20~25%**대로 **비약적 향상**이 관측된다는 요약이 있다 *(01:31)*. **두 자릿수를 넘어 20%대**에 진입한 것은 기업 **효율성·수익성**이 다른 단계로 들어갔다는 해석과 연결된다 *(02:30 맥락)*.

**맥락 구분:** 본 파일의 수치·`ROE_Korea_LargeCap_Context`는 **강관우 대표 요약**의 **시장·대형주** 서술에 가깝다. **메모리 대형주**에 한해 **ROE 50~90%** 등 **다른 범위**를 쓰는 요약은 [메모리 대형주 ROE·PER 괴리](memory-equity-high-roe-low-per.md)와 [고ROE·저PER → 리레이팅](../rel/high-roe-low-per-cycle-frame-to-growth-rerating.md)을 본다(동일 지표라도 **표본·화자가 다름**).

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [ROE 상승 → PER·PBR 멀티플 재평가 근거](../rel/roe-to-valuation-multiples-per-pbr.md)
- [이익 강화 vs 저평가 → 한국 비중 논리](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)
- [고ROE·저PER(메모리)·사이클틀 → 성장 리레이팅](../rel/high-roe-low-per-cycle-frame-to-growth-rerating.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`ROE_Korea_LargeCap_Context`** | ROE(자기자본이익률) | **이익률·자본 효율** 지표. 요약에서는 **과거 vs 현재** 비교의 핵심 숫자로 사용. |

---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 과학기술정보통신부 (MSIT)

<a id="msit-korea"></a>

## 개요

대한민국 과학기술·정보통신 정부 부처. [미토스(Mythos)](mythos-ai-agent.md) 사태 이후 통신 3사 및 주요 플랫폼사 CISO(최고정보보호책임자) 대상 긴급 현안점검회의를 개최.

## 관련 인과관계 (교차 링크)

- [미토스 등장 → 금융당국 규제 대응](../rel/mythos-to-regulatory-response.md)

## 관련 문서

- [미토스](mythos-ai-agent.md)
- [금융감독원](fss-korea.md)

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 지정학·중국 조선소 배제(미·중·안보)

<a id="summary"></a>

## 개요

**중국 해군력** 급성장에 **대응**해야 하나 **미·중 갈등**으로 **중국에 배를 맡길 수 없다**는 **안보·공급망** 논리가 제시된다 *(01:46)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [미 해운·IMO·지정학 → 한국 조선](../rel/us-maritime-imo-geopolitics-to-korea-shipbuilding-resurgence.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Geopolitics_China_Shipyard_Exclusion`** | 중국 조선 배제 | **안보**와 **갈등**이 **조선 수주·유지보수**의 **지정학적 제약**을 만든다는 프레임. |

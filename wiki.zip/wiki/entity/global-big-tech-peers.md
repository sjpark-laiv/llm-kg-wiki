---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 글로벌 빅테크 — M7(애플·구글·메타·아마존·엔비디아·MS·테슬라)

<a id="summary"></a>

## 개요

**삼성전자·SK하이닉스**의 **이익 규모**를 **애플·구글·메타** 등 **글로벌 빅테크**와 **비교**하는 서술이 있다 *(09:58 요약)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)
- [빅테크 CAPEX 전환 → 한국 반도체 매출](../rel/bigtech-capex-to-korea-semiconductor-revenue.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Global_BigTech_Peers`** | 글로벌 빅테크 동종 | **초대형 플랫폼·하드웨어** 기업군. 요약에서 **한국 메모리 기업 이익 스케일**의 **외부 벤치마크**. |

---
wiki_created: 2026-04-23
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# 아마존 (Amazon)

<a id="amazon"></a>

## 개요

[앤스로픽(Anthropic)](anthropic.md)의 최대 투자자이자 컴퓨팅 칩·데이터 센터 인프라 제공자. [염승환](yeom-seunghwan.md) 이사가 빅테크의 AI 투자 확대 사례로 언급. [24:50]

[글로벌 빅테크(M7)](global-big-tech-peers.md)의 일원으로, 자사주 매입 대신 **AI 인프라 투자**로 자금을 전환하는 기업의 대표 사례.

## 관련 인과관계 (교차 링크)

- [빅테크 CAPEX 전환 → 한국 반도체 매출](../rel/bigtech-capex-to-korea-semiconductor-revenue.md)

## 관련 문서

- [앤스로픽](anthropic.md) · [클로드](claude-ai-model.md)
- [글로벌 빅테크(M7)](global-big-tech-peers.md)
- [AI 인프라 CAPEX](ai-infrastructure-capex-cycle.md)

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 국내 메모리 섹터 이익 전망 급상향

<a id="summary"></a>

## 개요

**반도체 가격 폭등**과 결합해 **이익 전망치**가 **6개월** 만에 **5배 이상** 상향됐다는 서술이 있다. 규모로는 **기존 60~70조 원**대에서 **현재 300조 원 이상**으로 거론된다 *(03:13)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [DRAM 마진·가격 → 이익 전망 급상향](../rel/dram-margin-and-prices-to-earnings-forecast-surge.md)
- [증설 시차 → 공급 부족 지속](../rel/memory-fab-lag-to-under-supply-through-2027.md)
- [고ROE·저PER → 성장 리레이팅](../rel/high-roe-low-per-cycle-frame-to-growth-rerating.md)
- [이익 전망 vs 주가 → 목표가](../rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Korea_Memory_Earnings_Forecast_Surge`** | 메모리 이익 전망 급등 | **시장 컨센서스/전망치**의 **급격한 상향**을 가리키는 요약 노드. |

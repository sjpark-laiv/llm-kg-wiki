---
wiki_created: 2026-04-23
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# 엔비디아 (NVIDIA)

<a id="nvidia"></a>

## 개요

AI 학습용 GPU 독점 공급사. [염승환](yeom-seunghwan.md) 이사의 서술에서 AI 인프라 투자의 핵심 수혜자이자, **학습 단계** GPU 독점 기업으로 언급된다. 다만 [AI 에이전트 단계](ai-agent-paradigm.md)에서는 CPU 역할 확대로 상대적 비중이 변화할 수 있음이 시사된다.

## 관련 인과관계 (교차 링크)

- [빅테크 CAPEX 전환 → 한국 반도체 매출](../rel/bigtech-capex-to-korea-semiconductor-revenue.md)
- [AI 특이점·인프라 → 장기 섹터](../rel/ai-singularity-infra-to-productive-long-cycle-sectors.md)

## 관련 문서

- [AI 인프라 CAPEX](ai-infrastructure-capex-cycle.md)
- [HBM](hbm-memory-product.md)
- [AI 에이전트 패러다임](ai-agent-paradigm.md)

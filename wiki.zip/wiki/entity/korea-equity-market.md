---
wiki_created: 2026-04-19
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준(강관우·이선엽 등)
---

# 한국 주식시장

<a id="summary"></a>

## 개요

**금리 환경**을 고려하면 **미국보다 한국**이 **주식 투자 상대 매력**이 높다는 논지, 그리고 **자산배분**에서 **한국 비중을 높여야** 한다는 결론형 서술이 있다 *(20:00)*. **반도체 사이클 연장**, **세계 최정상급 이익** 대비 **저평가** 등이 **긍정 전망**의 근거로 묶인다 *(25:56)*.

**이선엽 대표 요약 맥락:** **인구·연금·자본 이동**을 통해 **증권·자본시장** 비중이 커질 수 있다는 **구조 전환** 서사가 **한국 증시** 전망과 맞닿아 있다 *(03:02)*. 추가 요약에서는 **AI·메모리 가격·방산·전쟁 리스크·펀드 비중 매도** 등이 **구조적 강세**와 연결된다 *(00:16)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [한·미 일드 갭 → 한국 상대 매력](../rel/korea-yield-gap-to-relative-equity-attractiveness.md)
- [이익·저평가 괴리 → 한국 비중 논리](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)
- [외국인 기계적 매도 → 국내 수급·머니무브](../rel/foreign-mechanical-selling-to-domestic-bid-strength.md)
- [ROE → 멀티플 재평가](../rel/roe-to-valuation-multiples-per-pbr.md)
- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)
- [인구·연금·자금이동 → 증권·자본시장](../rel/korea-demographics-pension-flows-to-securities-industry-shift.md)
- [AI·메모리 가격 → 실적 vs 주가·증시](../rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md)
- [실전 방산 → 글로벌 수요](../rel/combat-proven-defense-to-korea-export-demand.md)
- [전쟁 리스크 → 조정·반등](../rel/war-risk-to-necessary-correction-and-rebound-korea-equity.md)
- [펀드 비중 매도 vs 장기 유입](../rel/foreign-fund-weight-cap-selling-to-flow-noise-and-inflows.md)
- [코스피 저PER → 8,500 상방 시나리오](../rel/low-kospi-per-to-kospi-8500-upside-scenario.md)
- [악재 둔감화·실적장세 → 코스피 랠리 지속](../rel/risk-noise-desensitization-to-fundamental-led-kospi-rally.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Korea_Equity_Market`** | 한국 주식시장 | **한국 상장주식** 자산군. 요약의 **비중 확대·긍정 전망**이 수렴하는 **타깃 시장**. |

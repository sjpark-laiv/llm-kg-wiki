---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(이선엽 대표, 복수 영상 요약)
---

# 이선엽 대표

<a id="summary"></a>

## 개요

영상 요약에서 **이선엽** 대표는 **2026년 증시**와 **AI·조선·금융 구조**를 중심으로 **긍정적 전망**을 제시하되, **사모 대출(Private Credit)** 과 **고금리**가 **단기 변동성**을 만들 수 있음을 경고한다 *(10:42)*.

별도 요약에서는 **AI·메모리 가격·실적 vs 주가**, **한국 방산 글로벌 수요**, **전쟁 리스크와 조정·반등**, **펀드 비중 규정에 따른 외국인 매도 vs 장기 유입** 등을 **한국 증시 구조 강세**와 연결한다 *(00:16)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [통합: AI·방산·전쟁·수급 (2026 한국 증시)](../lee-sunyeop-2026-korea-equity-ai-defense-war-flow-causality.md)
- [통합 RCA·Impact 메모](../lee-sunyeop-2026-outlook-ai-shipping-finance-private-credit-causality.md)
- [AI 특이점·인프라 → 장기 섹터](../rel/ai-singularity-infra-to-productive-long-cycle-sectors.md)
- [미 해운·IMO·지정학 → 한국 조선](../rel/us-maritime-imo-geopolitics-to-korea-shipbuilding-resurgence.md)
- [인구·연금·자금이동 → 증권·자본시장](../rel/korea-demographics-pension-flows-to-securities-industry-shift.md)
- [사모대출·금리 → 단기 변동성](../rel/private-credit-yields-to-near-term-volatility-low-crisis-transmission.md)
- [사모대출 조정 → 은행 중심 재편](../rel/private-credit-workout-to-bank-centric-loan-market.md)
- [AI·메모리 가격 → 실적 vs 주가·증시](../rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md)
- [실전 방산 → 글로벌 수요](../rel/combat-proven-defense-to-korea-export-demand.md)
- [전쟁 리스크 → 조정·반등](../rel/war-risk-to-necessary-correction-and-rebound-korea-equity.md)
- [펀드 비중 매도 vs 장기 유입](../rel/foreign-fund-weight-cap-selling-to-flow-noise-and-inflows.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Lee_SunYeop`** | 이선엽 대표 | Person. 본 요약의 **발화자**. |

---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 금융감독원 (FSS)

<a id="fss-korea"></a>

## 개요

대한민국 금융감독 기관. [미토스(Mythos)](mythos-ai-agent.md) 사태 이후 금융기관 보안 실무자를 긴급 소집하여 [EDR](edr-endpoint-security.md) 등 로컬 PC 설치형 보안 프로그램 점검을 지시. 로컬 PC 외부 프로그램 설치 최소화 규제 기조를 주도한다.

## 관련 인과관계 (교차 링크)

- [미토스 등장 → 금융당국 규제 대응](../rel/mythos-to-regulatory-response.md)
- [망분리 규제 완화 → 소프트캠프 실적 성장](../rel/network-separation-deregulation-to-softcamp-growth.md)

## 관련 문서

- [미토스](mythos-ai-agent.md)
- [EDR](edr-endpoint-security.md)
- [망분리 규제 완화](network-separation-deregulation-korea.md)

---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 미국 군함 건조·MRO의 한국 아웃소싱 압력

<a id="summary"></a>

## 개요

미국의 군함 건조 역량 부족, 인력 부족, 높은 인건비, 미-중 경쟁이 결합되며 한국 조선사에 **군함 건조·MRO 발주**가 확대될 수 있다는 가설을 담는다.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [미 군함 인프라 부족 → 한국 조선·MRO 발주](../rel/us-naval-capacity-gap-to-korea-shipbuilding-mro-orders.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`US_Naval_Shipbuilding_MRO_Outsourcing_Korea`** | 미 군함 건조·MRO 한국 발주 | 미국의 제약이 커질수록 한국 조선사의 **군함·유지보수 시장** 접근이 확대되는 구조 변수. |

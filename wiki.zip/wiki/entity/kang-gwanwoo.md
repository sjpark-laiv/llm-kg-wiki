---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 강관우 대표

<a id="summary"></a>

## 개요

영상 요약 기준으로 **강관우** 대표는 **코스피**가 다시 **6,000선** 부근에 온 현재가 과거와 **근본적으로 다르다**고 보고, **한국 시장**에 대해 **긍정적 전망**을 유지해야 한다고 설명한다. 단기 **전쟁·금리 불확실성**에 휘둘리기보다 **강화된 기업 이익**과 **낮은 가격** 사이 **괴리**를 활용한 투자가 유효하다는 취지의 전망을 제시한다 *(요약·32:46, 25:56 근처)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [이익·저평가 괴리 → 한국 비중 확대 논리](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)
- [한·미 일드 갭 → 한국 상대 매력](../rel/korea-yield-gap-to-relative-equity-attractiveness.md)
- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Kang_GwanWoo`** | 강관우 대표 | Person. 본 영상 요약의 **발화자·해석 주체**. |

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(강관우·김장열·이선엽 등)
---

# SK하이닉스

<a id="summary"></a>

## 개요

요약에서 **SK하이닉스**는 **삼성전자**와 함께 **메모리 반도체** 기업의 **이익 규모**가 글로벌 **빅테크**와 견줄 만하거나 **TSMC** 추정치보다 높게 거론되는 맥락에서 등장한다 *(09:58 요약)*.

**김장열 본부장 요약 맥락:** **최선호주(Top Pick)** 로 거론되며, **보수 시나리오**에서도 **목표주가 180만 원 이상**이 제시된다 *(43:44)*, *(27:32)*.

**이선엽 대표 요약 맥락(추가):** **메모리 가격 급등·AI 수요** 축 — [AI·메모리 가격 → 실적 vs 주가](../rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md).

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)
- [이익·저평가 괴리 → 한국 비중 논리](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)
- [이익 전망 vs 주가 → 목표가·선호](../rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md)
- [고ROE·저PER → 성장 리레이팅](../rel/high-roe-low-per-cycle-frame-to-growth-rerating.md)
- [AI·메모리 가격 → 실적 vs 주가·증시](../rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`SK_Hynix`** | SK하이닉스 | **한국 메모리 반도체** 대표 기업. 요약의 **글로벌 이익 비교**에서 **쌍두마차** 축. |

---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 조선 수주잔고·마진 정상화

<a id="summary"></a>

## 개요

조선업은 기대감만이 아니라 **수주잔고**와 **실적**이 동반되고, 과거 인력 병목에 따른 마진 훼손이 완화되며 이익 정상화 국면에 진입한다는 관점을 나타낸다.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [공급 부족·인력 정상화 → 조선 실적·재평가](../rel/ship-supply-shortage-and-labor-normalization-to-shipbuilder-earnings-rerating.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Shipbuilding_OrderBacklog_Margin_Normalization`** | 조선 수주잔고·마진 정상화 | 공급 부족과 생산성 개선이 함께 작동해 **조선 이익률 회복**을 설명하는 개념 변수. |

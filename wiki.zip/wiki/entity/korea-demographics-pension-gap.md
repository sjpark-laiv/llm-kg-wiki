---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 한국 인구 구조·국민연금 갭

<a id="summary"></a>

## 개요

**저출산·고령화**로 **국민연금만으로는 노후 대비가 불가능**해졌다는 전제가 제시된다 *(03:33)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [인구·연금·자금이동 → 증권·자본시장](../rel/korea-demographics-pension-flows-to-securities-industry-shift.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Korea_Demographics_Pension_Gap`** | 연금 갭 | **공적 연금**만으로는 **대체율·지속성**이 부족하다는 **구조 문제** 서술. |

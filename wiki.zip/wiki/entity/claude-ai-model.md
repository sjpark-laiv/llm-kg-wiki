---
wiki_created: 2026-04-23
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# 클로드 (Claude)

<a id="claude-ai-model"></a>

## 개요

[앤스로픽(Anthropic)](anthropic.md)의 AI 모델. [염승환](yeom-seunghwan.md) 이사에 따르면 **금융 리서치 및 사실 관계 파악**에서 인간을 압도하는 성능을 보여주며, 기업들이 AI 투자를 포기할 수 없게 만드는 근거로 언급됨. [22:40]

[아마존](amazon-aws.md)이 앤스로픽에 대규모 투자를 유치한 사례가 함께 언급됨. [22:30]

## 관련 인과관계 (교차 링크)

- [AI 기업 효용 체감 → 한국 반도체 400조 실적 확신](../rel/ai-enterprise-efficacy-to-korea-400t-earnings-conviction.md)

## 관련 문서

- [앤스로픽](anthropic.md) · [아마존](amazon-aws.md)
- [오픈AI](openai.md)

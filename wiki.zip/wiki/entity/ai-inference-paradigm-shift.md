---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# AI 패러다임(학습 → 추론)

<a id="summary"></a>

## 개요

**작년까지**는 AI **학습** 단계였으나, 이제는 **생성형 AI의 추론** 단계로 **진입**했다는 서술이 있다 *(07:50)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [AI 추론 → KV 캐시 수요](../rel/ai-inference-paradigm-to-kv-cache-demand.md)
- [KV·추론 → DDR5 혼용·긴장](../rel/kv-cache-inference-to-ddr5-mix-and-tightening.md)
- [AI 에이전트·CPU → DDR5 수요 폭증](../rel/ai-agent-cpu-to-general-dram-demand.md) — 다음 단계: [AI 에이전트 패러다임](ai-agent-paradigm.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`AI_Inference_Paradigm`** | 추론 중심 국면 | **워크로드·메모리 요구**가 **학습 대비 질적으로 달라진다**는 프레임. |

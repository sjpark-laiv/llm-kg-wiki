---
wiki_created: 2026-04-19
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 코스피 지수

<a id="summary"></a>

## 개요

요약에 따르면 **코스피**가 **6,000선**에 다시 도달한 국면이 **과거 6,000 시절**과 **펀더멘털(예: ROE)** 면에서 동일하지 않다는 논지의 **무대(지수 레벨)** 로 등장한다 *(01:31 전후 맥락)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [ROE 상승 → 멀티플 재평가 근거](../rel/roe-to-valuation-multiples-per-pbr.md)
- [이익·저평가 괴리 → 한국 비중 논리](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)
- [코스피 저PER → 8,500 상방 시나리오](../rel/low-kospi-per-to-kospi-8500-upside-scenario.md)
- [악재 둔감화·실적장세 → 코스피 랠리 지속](../rel/risk-noise-desensitization-to-fundamental-led-kospi-rally.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`KOSPI_Index`** | 코스피 지수 | **한국 대표 주가지수**. 영상 요약에서 **6,000 부근** 국면 비교의 기준점. |

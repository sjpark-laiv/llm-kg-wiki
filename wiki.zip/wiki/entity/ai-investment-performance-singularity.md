---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# AI 투자의 ‘특이점’(성능·효율 스케일링)

<a id="summary"></a>

## 개요

**AI**에 투입되는 **천문학적 비용**이 단순 **소비**가 아니라, 투자할수록 **성능과 효율**이 **기하급수적으로** 좋아지는 **특이점**에 도달하고 있다는 서술이 있다 *(04:44)*. 이는 **닷컴 버블**과 구별되는 **실체** 논거로 쓰인다 *(02:23)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [AI 특이점·인프라 → 장기 섹터](../rel/ai-singularity-infra-to-productive-long-cycle-sectors.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`AI_Investment_Performance_Singularity`** | AI 특이점 프레임 | **CAPEX→성능/효율**의 **강한 비선형**을 전제로 한 **낙관 서사**. |

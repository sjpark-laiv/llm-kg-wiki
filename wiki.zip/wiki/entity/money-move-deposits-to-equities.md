---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(강관우·이선엽 등)
---

# 머니무브(예금→주식)

<a id="summary"></a>

## 개요

**은행 예금**에서 **주식**으로의 **자금 이동(머니무브)** 가 **본격화**된다는 서술이 **수급 기반** 강화와 함께 제시된다 *(13:58)*.

**이선엽 대표 요약 맥락:** **부동산→주식** 등 **비생산→생산적 자본시장** 이동이 **증권·자본시장** 재편과 연결된다는 서술이 있다 *(03:02)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [외국인 기계적 매도 → 국내 수급·머니무브](../rel/foreign-mechanical-selling-to-domestic-bid-strength.md)
- [인구·연금·자금이동 → 증권·자본시장](../rel/korea-demographics-pension-flows-to-securities-industry-shift.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Money_Move_Deposits_to_Equities`** | 머니무브 | **저축·예금**에서 **위험자산(주식)** 으로의 **재배치**(요약 주장). |

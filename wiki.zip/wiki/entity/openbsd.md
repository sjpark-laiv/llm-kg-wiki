---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# OpenBSD

<a id="openbsd"></a>

## 개요

보안에 특화된 오픈소스 운영체제. 27년간 높은 보안성을 유지해왔으나, [미토스(Mythos)](mythos-ai-agent.md)가 단 몇 분 만에 취약점을 찾아낸 사례로 AI 해킹 도구의 위력을 보여주는 상징이 되었다.

## 관련 인과관계 (교차 링크)

- [미토스 등장 → 기존 보안체계 위기](../rel/mythos-to-legacy-security-crisis.md)

## 관련 문서

- [미토스](mythos-ai-agent.md)
- [EDR](edr-endpoint-security.md)

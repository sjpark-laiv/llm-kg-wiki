---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 증권·자본시장 위상 상승(은행 중심 탈피)

<a id="summary"></a>

## 개요

**은행 중심**에서 **증권·자본시장** 중심으로 **금융 산업 구조**가 **재편**될 것이라는 전망이 제시된다 *(03:02)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [인구·연금·자금이동 → 증권·자본시장](../rel/korea-demographics-pension-flows-to-securities-industry-shift.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Korea_Securities_Capital_Markets_Ascendance`** | 증권·자본시장 | **브로커리지·운용·IB** 등 **시장 중개·형성** 기능의 **상대적 비중 상승** 서술. |

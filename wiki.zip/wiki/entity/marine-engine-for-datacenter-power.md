---
wiki_created: 2026-04-21
wiki_updated: 2026-04-21
content_as_of: 영상 요약 메모 기준
---

# 데이터센터 전력용 선박 엔진 수요

<a id="summary"></a>

## 개요

AI 데이터센터 확장으로 전력 부족이 부각되면서, 가스터빈 등 **선박 엔진**을 비상 전력·대체 전원으로 활용하는 수요가 증가할 수 있다는 서사가 제시된다.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [AI 전력 부족 → 선박 엔진 수요 → 조선사 이익](../rel/ai-datacenter-power-gap-to-marine-engine-demand-in-shipbuilders.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Marine_Engine_for_Datacenter_Power`** | 데이터센터 전력용 선박 엔진 | AI 전력 부족 구간에서 **선박 엔진 기반 전원 대안** 수요를 나타내는 개념. |

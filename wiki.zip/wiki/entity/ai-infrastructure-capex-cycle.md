---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# AI 인프라 광범위 투자(GPU·메모리·DC·전력)

<a id="summary"></a>

## 개요

**엔비디아(GPU)**, **메모리**, **데이터센터**, **전력 기기**까지 **광범위한 인프라 투자**가 동반된다는 서술이 있다 *(05:14)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [AI 특이점·인프라 → 장기 섹터](../rel/ai-singularity-infra-to-productive-long-cycle-sectors.md)
- [빅테크 CAPEX 전환 → 한국 반도체 매출](../rel/bigtech-capex-to-korea-semiconductor-revenue.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`AI_Infrastructure_Capex_Cycle`** | AI 인프라 CAPEX | **반도체·전력·부동산(데이터센터)** 등 **복합 공급망 투자** 묶음. |

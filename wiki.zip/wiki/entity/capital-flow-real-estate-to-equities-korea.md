---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 부동산→주식 자금 이동(비생산→생산적 자본시장)

<a id="summary"></a>

## 개요

**비생산적인 부동산 자금**이 **생산적인 자본시장(주식)** 으로 **이동**하면서 **증권업** 위상이 높아지고 **산업 구조**가 **재편**된다는 서술이 있다 *(03:02)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [인구·연금·자금이동 → 증권·자본시장](../rel/korea-demographics-pension-flows-to-securities-industry-shift.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Capital_Flow_RealEstate_To_Equities_Korea`** | 부동산→주식 | **자산군 간 재배치**가 **증시 유동성·밸류**에 미친다는 **거시 수급** 서술. |

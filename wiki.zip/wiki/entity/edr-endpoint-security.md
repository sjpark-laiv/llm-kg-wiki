---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# EDR (Endpoint Detection and Response)

<a id="edr"></a>

## 개요

로컬 PC(엔드포인트)에 설치되어 위협을 탐지하고 대응하는 보안 소프트웨어 범주. [미토스(Mythos)](mythos-ai-agent.md) 등장으로 로컬 설치형 보안의 **구조적 한계**가 드러났다.

## 한계

- [미토스](mythos-ai-agent.md)가 [OpenBSD](openbsd.md) 취약점을 분 단위로 발견 → 로컬 설치 보안 자체가 공격 대상
- [금융감독원](fss-korea.md)이 EDR 등 로컬 PC 설치 보안 프로그램의 긴급 점검 지시

## 관련 인과관계 (교차 링크)

- [미토스 등장 → 기존 보안체계 위기](../rel/mythos-to-legacy-security-crisis.md)

## 관련 문서

- [RBI](rbi-remote-browser-isolation.md) — EDR 한계를 극복하는 대안
- [미토스](mythos-ai-agent.md)
- [실드게이트](shieldgate.md)

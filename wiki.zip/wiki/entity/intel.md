---
wiki_created: 2026-04-23
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# 인텔 (Intel)

<a id="intel"></a>

## 개요

CPU 제조 기업. [AI 에이전트 시대](ai-agent-paradigm.md)에 CPU 역할이 비약적으로 중요해지면서 **재평가** 가능성이 언급됨. [28:15] GPU([엔비디아](nvidia.md)) 중심이던 AI 하드웨어 수혜가 CPU·범용 메모리 쪽으로 확장되는 서사에서 등장한다.

## 관련 인과관계 (교차 링크)

- [AI 에이전트·CPU 수요 → 범용 메모리(DDR5) 수요 폭증](../rel/ai-agent-cpu-to-general-dram-demand.md)

## 관련 문서

- [AI 에이전트 패러다임](ai-agent-paradigm.md)
- [엔비디아](nvidia.md) · [DDR5 범용 DRAM](ddr5-general-purpose-dram.md)

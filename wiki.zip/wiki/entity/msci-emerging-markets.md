---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# MSCI 이머징 마켓

<a id="summary"></a>

## 개요

최근 **외국인 대규모 매도**가 한국 기업 **펀더멘털** 문제라기보다 **MSCI 이머징 마켓** 내 **한국 비중이 과도하게 커진** 결과로 **기계적 비중 조절** 성격이 강하다는 해석이 제시된다 *(17:36, 17:44)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [외국인 기계적 매도 → 국내 수급·머니무브](../rel/foreign-mechanical-selling-to-domestic-bid-strength.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`MSCI_EmergingMarkets_Index`** | MSCI 이머징 마켓 | **신흥국 지수** 벤치마크. 요약에서는 **비중 상한·리밸런싱** 논리의 **상위 구조**. |

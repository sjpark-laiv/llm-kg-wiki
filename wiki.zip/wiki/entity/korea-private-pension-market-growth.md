---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 퇴직·사적 연금 시장 확대

<a id="summary"></a>

## 개요

위 **연금 갭**에 따라 **퇴직연금(사적 연금)** 시장이 **커지고** 있다는 서술이 있다 *(03:33)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [인구·연금·자금이동 → 증권·자본시장](../rel/korea-demographics-pension-flows-to-securities-industry-shift.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Korea_Private_Pension_Market_Growth`** | 사적 연금 시장 | **DC/IRP** 등 **개인·기업 연금 적립**이 **증시 자금**으로 연결될 수 있는 **제도 수요** 축. |

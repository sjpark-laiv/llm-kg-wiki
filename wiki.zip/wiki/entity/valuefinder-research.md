---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 밸류파인더 (ValueFinder)

<a id="valuefinder"></a>

## 개요

독립 리서치 기관. 대표: [이충헌](lee-chung-hun.md). [소프트캠프(258790)](softcamp.md)에 대해 [실드게이트(SHIELD Gate)](shieldgate.md)의 원천 차단 기술력과 [망분리 규제 완화](network-separation-deregulation-korea.md) 기조에 따른 구조적 성장을 전망했다 (2026-04-20 리포트, 프라임경제 보도).

## 관련 문서

- [이충헌 대표](lee-chung-hun.md)
- [소프트캠프](softcamp.md) · [실드게이트](shieldgate.md)

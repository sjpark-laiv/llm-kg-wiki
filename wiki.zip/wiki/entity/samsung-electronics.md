---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(강관우·김장열·이선엽 등)
---

# 삼성전자

<a id="summary"></a>

## 개요

요약에 따르면 **삼성전자**의 **영업이익**이 시장 **예상치를 크게 상회**하는 **약 57조 원** 수준이 거론되며, **이익 체력 강화** 근거로 인용된다 *(01:42)*. 또한 글로벌 **빅테크**·**TSMC** 대비 **이익 규모** 비교 맥락에서 반복 등장한다 *(03:55~09:58 요약)*.

**김장열 본부장 요약 맥락:** **범용 DRAM** 강점으로 **추론·KV** 수요 확대 시 **혼용·재고·가격** 논점에 등장하고, **파운드리**는 **수율·테슬라·오픈AI 수주**로 **내년 흑자** 기대·**시총 옵션** 서술과 연결된다. **목표주가** **25~29만 원**(보수 시나리오)이 제시된다 *(11:13)*, *(29:13)*, *(20:23)*.

**이선엽 대표 요약 맥락(추가):** **AI·메모리 가격 급등**·**실적 전망이 주가보다 빠름**·**내년 글로벌 최대 이익 기업** 가능성 등 — [AI·메모리 가격 → 실적 vs 주가](../rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md).

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [메모리 이익 뉴 노멀 → 밸류 업사이드](../rel/memory-earnings-new-normal-to-equity-valuation-upside.md)
- [이익·저평가 괴리 → 한국 비중 논리](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)
- [KV·추론 → DDR5 혼용·긴장](../rel/kv-cache-inference-to-ddr5-mix-and-tightening.md)
- [이익 전망 vs 주가 → 목표가·선호](../rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md)
- [삼성 파운드리 → 시총 업사이드](../rel/samsung-foundry-profit-orders-to-mcap-upside.md)
- [AI·메모리 가격 → 실적 vs 주가·증시](../rel/ai-memory-pricing-surge-to-earnings-outrun-price-korea-equity.md)
- [빅테크 CAPEX 전환 → 한국 반도체 매출](../rel/bigtech-capex-to-korea-semiconductor-revenue.md)
- [AI 에이전트·CPU → DDR5 수요 폭증](../rel/ai-agent-cpu-to-general-dram-demand.md)
- [AI 효용 체감 → 한국 반도체 400조 실적 확신](../rel/ai-enterprise-efficacy-to-korea-400t-earnings-conviction.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Samsung_Electronics`** | 삼성전자 | **한국 대형 메모리·파운드리** 기업. **범용 DRAM·파운드리 옵션** 등 **복수 레버**가 요약마다 강조됨. |

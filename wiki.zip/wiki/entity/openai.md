---
wiki_created: 2026-04-23
content_as_of: 영상 요약 메모 기준(염승환 이사)
---

# 오픈AI (OpenAI)

<a id="openai"></a>

## 개요

챗GPT 개발사. 샘 알트먼(Sam Altman)이 **30GW 컴퓨팅 수요** 목표를 언급, AI 인프라 투자의 규모감을 상징하는 사례로 [염승환](yeom-seunghwan.md) 이사가 인용. [24:10]

## 관련 인과관계 (교차 링크)

- [빅테크 CAPEX 전환 → 한국 반도체 매출](../rel/bigtech-capex-to-korea-semiconductor-revenue.md)
- [AI 기업 효용 체감 → 한국 반도체 400조 실적 확신](../rel/ai-enterprise-efficacy-to-korea-400t-earnings-conviction.md)

## 관련 문서

- [글로벌 빅테크(M7)](global-big-tech-peers.md) · [아마존](amazon-aws.md)
- [AI 인프라 CAPEX](ai-infrastructure-capex-cycle.md)

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 미국 401k·퇴직연금의 주식 비중 상향(선행 사례)

<a id="summary"></a>

## 개요

**1980년대 미국**이 **퇴직연금의 주식 비중**을 높이며 **증시 장기 호황**을 이끈 **모델**을 **한국**도 **따라가고** 있다는 비유가 제시된다 *(03:50)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [인구·연금·자금이동 → 증권·자본시장](../rel/korea-demographics-pension-flows-to-securities-industry-shift.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`US_401k_Equity_Shift_Precedent`** | 401k 선행 | **제도 변화→주식 수요→장기 랠리**의 **역사적 유비**. |

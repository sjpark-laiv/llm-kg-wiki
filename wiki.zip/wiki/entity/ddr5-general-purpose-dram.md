---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 범용 DDR5 DRAM

<a id="summary"></a>

## 개요

**일반 디램(범용 DRAM)** 을 **대량 혼용**하게 되었고, 그 결과 **삼성전자**가 강점을 가진 **일반 DRAM**의 **재고 소진**과 **가격 급등**으로 이어졌다는 서술이 있다 *(08:50)*, *(11:13)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [KV·추론 → DDR5 혼용·긴장](../rel/kv-cache-inference-to-ddr5-mix-and-tightening.md)
- [AI 에이전트·CPU → DDR5 수요 폭증](../rel/ai-agent-cpu-to-general-dram-demand.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`DDR5_GeneralPurpose_DRAM`** | 범용 DDR5 | **추론 워크로드**에서 **HBM과 병행**되는 **대용량·저단가** 메모리 축. |

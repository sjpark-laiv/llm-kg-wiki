---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# 미국 주식시장

<a id="summary"></a>

## 개요

**미국 시장**은 **일드 갭**이 **좁아** **주식 투자 매력**이 상대적으로 **낮다**는 취지의 비교가 등장한다 *(19:44)*. **미국 vs 한국** 중 하나를 고르라면 **한국**을 택한다는 강조와 연결된다 *(32:46 요약)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [한·미 일드 갭 → 한국 상대 매력](../rel/korea-yield-gap-to-relative-equity-attractiveness.md)
- [이익·저평가 괴리 → 한국 비중 논리](../rel/earnings-valuation-gap-to-korea-overweight-thesis.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`US_Equity_Market`** | 미국 주식시장 | **미국 주식** 자산군. 요약에서 **금리·일드 갭** 맥락의 **비교 축**. |

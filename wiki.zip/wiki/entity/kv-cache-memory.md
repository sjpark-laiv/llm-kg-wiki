---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# KV 캐시 메모리

<a id="summary"></a>

## 개요

**추론** 과정에서 순간 기억을 저장하는 **키-밸류(KV) 캐시 메모리**가 **기하급수적으로** 필요하며, 용량이 **80GB에서 1TB까지** **8배 이상** 급증한다는 서술이 있다 *(07:50)*, *(09:41)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [AI 추론 → KV 캐시 수요](../rel/ai-inference-paradigm-to-kv-cache-demand.md)
- [KV·추론 → DDR5 혼용·긴장](../rel/kv-cache-inference-to-ddr5-mix-and-tightening.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`KV_Cache_Memory`** | KV 캐시 | **추론 시퀀스**에서의 **중간 상태 저장**에 대응하는 **메모리 요구** 묶음. |

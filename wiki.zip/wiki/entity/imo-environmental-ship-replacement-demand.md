---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# IMO 환경 규제·친환경 선박 교체 수요

<a id="summary"></a>

## 개요

**국제해사기구(IMO)** 의 **환경 규제**로 **노후 선박**을 **친환경 선**으로 **교체**해야 하는 **수요가 폭증**한다는 서술이 있다 *(01:32)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [미 해운·IMO·지정학 → 한국 조선](../rel/us-maritime-imo-geopolitics-to-korea-shipbuilding-resurgence.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`IMO_Environmental_Ship_Replacement_Demand`** | IMO 교체 사이클 | **규제 준수**를 위한 **선박 갈아타기** 수요. |

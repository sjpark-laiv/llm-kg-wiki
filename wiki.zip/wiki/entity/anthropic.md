---
wiki_created: 2026-04-23
content_as_of: 2026-04-20
---

# 앤스로픽 (Anthropic)

<a id="anthropic"></a>

## 개요

미국 AI 안전 연구 기업. AI 보안 에이전트 **[미토스(Mythos)](mythos-ai-agent.md)**를 공개하여 전 세계 보안 업계에 충격을 주었다.

## 주요 제품·기술

- **[미토스(Mythos)](mythos-ai-agent.md)**: AI 기반 보안 취약점 자동 탐지·공격 경로 자율 설계 에이전트

## 관련 인과관계 (교차 링크)

- [미토스 등장 → 기존 보안체계 위기](../rel/mythos-to-legacy-security-crisis.md)
- [미토스 등장 → 실드게이트 수요 급증](../rel/mythos-to-shieldgate-demand.md)
- [미토스 등장 → 금융당국 규제 대응](../rel/mythos-to-regulatory-response.md)

## 관련 문서

- [미토스 AI 에이전트](mythos-ai-agent.md)
- [소프트캠프](softcamp.md) — 미토스 대응 솔루션 보유 기업
- [실드게이트](shieldgate.md)

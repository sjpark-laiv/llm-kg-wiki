---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준
---

# HBM(고대역폭 메모리)

<a id="summary"></a>

## 개요

**비싼 HBM만**으로는 **모든 추론 수요**를 **감당하기 어렵다**는 전제가 제시되며, **저렴한 일반 DRAM**을 **대량 혼용**하는 논리와 연결된다 *(08:50)*.

---

<a id="relations"></a>

## 관련 인과관계 (교차 링크)

- [KV·추론 → DDR5 혼용·긴장](../rel/kv-cache-inference-to-ddr5-mix-and-tightening.md)

---

<a id="entities"></a>

## Entity 정의 (분석용)

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`HBM_Product`** | HBM | **고가·고대역** 메모리 제품군. **추론 워크로드**에서 **용량·비용 한계** 논점과 결합. |

---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(김장열 본부장 발화 요지)
---

# 반도체 업황 본질 변화·추론·DRAM·공급 (김장열 본부장 영상 요약, RCA·Impact)

**목적:** **김장열** 본부장 발화 요약에서 **메모리 업황**이 과거와 어떻게 달라졌는지, **추론 AI**가 **KV 캐시·범용 DRAM** 수요로 어떻게 전이되는지, **공급 지연**·**밸류 재평가**·**목표주가** 논리를 **RCA·Impact**용 근거로 구조화한다. 개체·세부 인과는 [`wiki/entity/`](entity/)·[`wiki/rel/`](rel/)를 본다.

**발화자:** [김장열 본부장](entity/kim-jangyeol.md)

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) | 개체 문서 |
|-----------|-----------|---------------|-----------|
| **`Kim_JangYeol`** | 김장열 본부장 | Person. 본 요약의 **해석·전망 주체**. | [kim-jangyeol.md](entity/kim-jangyeol.md) |
| **`DRAM_Margin_SoftwareLike`** | DRAM 마진(소프트웨어급) | **DRAM 마진 ~80%** 등 **이전 사이클과 다른 이익률** 서술. | [dram-margin-software-like-level.md](entity/dram-margin-software-like-level.md) |
| **`Korea_Memory_Earnings_Forecast_Surge`** | 국내 메모리 이익 전망 급상향 | **6개월** 만 **5배+** 상향, **60~70조→300조+** 등 **전망치 스케일** 서술. | [korea-memory-sector-earnings-forecast-surge.md](entity/korea-memory-sector-earnings-forecast-surge.md) |
| **`AI_Inference_Paradigm`** | AI 추론 패러다임 | **학습→추론** 단계 전환 서술. | [ai-inference-paradigm-shift.md](entity/ai-inference-paradigm-shift.md) |
| **`KV_Cache_Memory`** | KV 캐시 메모리 | 추론 과정 **순간 기억 저장**에 필요한 **키-밸류 캐시** 용량 폭증. | [kv-cache-memory.md](entity/kv-cache-memory.md) |
| **`Memory_Fab_Capacity_Lag_2027`** | 메모리 증설·가동 시차(2027) | **평택 5·용인·마이크론** 등 **의미 있게 풀리는 시점 ~2027 하반기** 서술. | [memory-fab-capacity-lag-2027.md](entity/memory-fab-capacity-lag-2027.md) |
| **`HBM_Product`** | HBM | **고가** 메모리. 추론에서 **단독으로 전량 커버 어려움** 서술과 연결. | [hbm-memory-product.md](entity/hbm-memory-product.md) |
| **`DDR5_GeneralPurpose_DRAM`** | 범용 DDR5 DRAM | **저가 DRAM 대량 혼용**으로 수요·가격 급등 서술. | [ddr5-general-purpose-dram.md](entity/ddr5-general-purpose-dram.md) |
| **`Memory_Equity_HighROE_LowPER`** | 메모리주 ROE·PER 괴리 | **ROE 50~90%** vs **PER 4~6배**, **사이클 프레임** 논의. | [memory-equity-high-roe-low-per.md](entity/memory-equity-high-roe-low-per.md) |
| **`Samsung_Electronics`** | 삼성전자 | **범용 DRAM 강점·파운드리** 등 **다층 논점**. | [samsung-electronics.md](entity/samsung-electronics.md) |
| **`SK_Hynix`** | SK하이닉스 | **Top Pick**·목표가 서술. | [sk-hynix.md](entity/sk-hynix.md) |
| **`Samsung_Foundry_Division`** | 삼성전자 파운드리 | **수율·수주(테슬라·오픈AI)** 로 **내년 흑자** 기대. | [samsung-foundry-division.md](entity/samsung-foundry-division.md) |
| **`Micron`** | 마이크론 | **신규 케파** **2027 하반기** 의미 시점 서술. | [micron.md](entity/micron.md) |
| **`Sandisk`** | 샌디스크 | **선호순위** 비교에서 열위 서술. | [sandisk.md](entity/sandisk.md) |
| **`Korea_SME_Parts_Sector`** | 국내 소부장 섹터 | **실적 시즌 차익 실현** 가능성 **주의** 서술. | [korea-sme-parts-sector.md](entity/korea-sme-parts-sector.md) |

---

<a id="causality-map"></a>

## 2. Causality map

| 경로 | 인과 기제 | 태그 |
|------|------------|------|
| **마진·가격** | DRAM **고마진+가격** → **이익 전망 급상향** | `RCA`+`Evidence` |
| **AI 단계** | **학습→추론** → **KV 캐시** 용량 **기하급수** | `RCA`+`Impact` |
| **메모리 믹스** | HBM만으론 부족 → **범용 DRAM 혼용** → **DDR5 재고·가격** | `Impact`+`Evidence` |
| **공급** | **증설 리드타임** + **2027 가동** → **수요 초과 지속** | `RCA` |
| **밸류** | **고ROE·저PER** + **사이클→성장** 인식 → **리레이팅** | `Impact` |
| **목표가** | **이익 전망 상향** 대비 **주가 상승 2배** → **저평가·목표가** | `Evidence` |
| **파운드리** | **수율·수주** → **흑자** → **시총 추가** | `Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `DRAM_Margin_SoftwareLike` | `amplifies_with_prices` | `Korea_Memory_Earnings_Forecast_Surge` | `margin_price_to_eps_revision` |
| `AI_Inference_Paradigm` | `requires` | `KV_Cache_Memory` | `inference_workload` |
| `KV_Cache_Memory` | `pulls` | `DDR5_GeneralPurpose_DRAM` | `hbm_capacity_binding` |
| `HBM_Product` | `complements_with` | `DDR5_GeneralPurpose_DRAM` | `cost_mix_inference` |
| `Memory_Fab_Capacity_Lag_2027` | `sustains` | `Korea_Memory_Earnings_Forecast_Surge` | `supply_inelasticity` |
| `Memory_Equity_HighROE_LowPER` | `rerates_when` | `Korea_Memory_Earnings_Forecast_Surge` | `cycle_to_growth_reframe` |
| `Samsung_Foundry_Division` | `adds` | `Samsung_Electronics` | `foundry_mcap_option` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis — “업황이 달라진 근원은?”

- **이익률 레짐:** **DRAM 마진 ~80%**로 **하드웨어 제조**가 아닌 **고수익 SW급** 서술 *(02:10)*.
- **수요 엔진:** **추론** 단계에서 **KV 캐시**가 **80GB→1TB** 등 **용량 급증** *(07:50)*, *(09:41)*.
- **공급 탄력:** **증설·가동 최소 1년+**, **의미 있게 풀림 ~2027 하반기** *(14:13)*, *(15:30)*.

---

<a id="impact"></a>

## 4. Impact — “시장·종목에 미치는 영향”

- **DDR5·범용 DRAM:** 추론 부하에서 **HBM+범용 DRAM** **혼용** → **재고 소진·가격 급등** *(08:50)*, *(11:13)*.
- **밸류:** **ROE 50~90%** vs **PER 4~6배** → **사이클→성장** 재인식 시 **대규모 리레이팅** *(16:20)*, *(18:27)*.
- **목표가:** **삼성전자 25~29만 원**, **SK하이닉스 180만 원+** (보수 시나리오 포함) *(18:45)*, *(20:23)*, *(27:32)*.
- **파운드리 옵션:** **흑자 전환·수주** 시 **시총 50~100조** 추가 상승 여력 *(29:13)*, *(31:38)*.
- **우선순위:** **SK하이닉스 Top Pick**, **삼성전자** 추격, **마이크론·샌디스크**보다 **한국 2사** 선호 *(43:44)*, *(44:14)*.
- **리스크:** **소부장** **차익 실현** 가능 vs **대형 메모리** **내년까지 방향성 확고** — **“지금 팔면 안 된다”** *(26:20)*, *(48:07)*.

---

<a id="evidence-data"></a>

## 5. Evidence 표

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| DRAM 마진 | **~80%** (SW급 비유) | *(02:10)* |
| 이익 전망 | **6개월** **5배+** 상향, **60~70조→300조+** | *(03:13)* |
| KV 용량 | **80GB→1TB** (8배+) | *(07:50)*, *(09:41)* |
| 공급 | **2027 하반기** 의미 증설 | *(14:13)*, *(15:30)* |
| DDR5 | **범용 DRAM** **혼용·재고·가격** | *(08:50)*, *(11:13)* |
| ROE·PER | **ROE 50~90%**, **PER 4~6배** | *(16:20)* |
| 리레이팅 | **사이클→성장** 전환 | *(18:27)* |
| 결론 톤 | **“지금 사도 늦지 않았다”** | *(요약·18:45 근처)* |

---

<a id="logic-framework"></a>

## 6. 논리 프레임워크 (Mermaid)

```mermaid
flowchart LR
  M[DRAM 고마진·가격] --> E[이익 전망 급상향]
  A[추론 패러다임] --> K[KV 캐시 폭증]
  K --> D[DDR5 범용 수요]
  H[HBM 한계] --> D
  F[증설 시차·2027] --> U[공급 부족 지속]
  U --> E
  R[고ROE·저PER] --> V[리레이팅 잠재]
  E --> V
```

---

<a id="related-graph"></a>

## 7. 관련 인과 문서 (`wiki/rel/`)

- [DRAM 마진·가격 → 이익 전망 급상향](rel/dram-margin-and-prices-to-earnings-forecast-surge.md)
- [AI 추론 패러다임 → KV 캐시 수요](rel/ai-inference-paradigm-to-kv-cache-demand.md)
- [증설 시차 → 2027까지 공급 부족](rel/memory-fab-lag-to-under-supply-through-2027.md)
- [KV·추론 부하 → DDR5 혼용·긴장](rel/kv-cache-inference-to-ddr5-mix-and-tightening.md)
- [고ROE·저PER·사이클틀 → 성장 리레이팅](rel/high-roe-low-per-cycle-frame-to-growth-rerating.md)
- [이익 전망 vs 주가 → 한국 메모리 목표가](rel/earnings-forecast-upgrade-vs-price-to-memory-targets.md)
- [삼성 파운드리 흑자·수주 → 시총 업사이드](rel/samsung-foundry-profit-orders-to-mcap-upside.md)

---

<a id="related-docs"></a>

## 8. 관련 문서 (Named entity·기존 위키)

- [메모리 이익 뉴 노멀 (강관우 요약)](entity/memory-semiconductor-earnings-new-normal.md) — **서로 다른 화자·근거**이므로 병행 시 **출처 구분** 필요.
- [메모리 이익 뉴 노멀 → 밸류 업사이드](rel/memory-earnings-new-normal-to-equity-valuation-upside.md)

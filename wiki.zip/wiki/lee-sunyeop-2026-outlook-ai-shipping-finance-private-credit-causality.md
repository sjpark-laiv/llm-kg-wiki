---
wiki_created: 2026-04-19
wiki_updated: 2026-04-19
content_as_of: 영상 요약 메모 기준(이선엽 대표 발화 요지)
---

# 2026년 증시·AI·조선·금융구조·사모대출 (이선엽 대표 영상 요약, RCA·Impact)

**목적:** **이선엽** 대표 발화 요약에서 **AI 투자의 실체성**, **조선(미·IMO·지정학)**, **인구·연금·자본시장 재편**, **사모 대출(Private Credit) 리스크**를 **RCA·Impact**용으로 구조화한다. 세부 개체·인과는 [`wiki/entity/`](entity/)·[`wiki/rel/`](rel/)를 본다.

**발화자:** [이선엽 대표](entity/lee-sunyeop.md)

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) | 개체 문서 |
|-----------|-----------|---------------|-----------|
| **`Lee_SunYeop`** | 이선엽 대표 | Person. 본 요약의 **발화·전망 주체**. | [lee-sunyeop.md](entity/lee-sunyeop.md) |
| **`AI_Investment_Performance_Singularity`** | AI 투자 특이점 | 투입 증가에 따라 **성능·효율**이 **기하급수적으로** 개선된다는 **프레임** *(04:44)*. | [ai-investment-performance-singularity.md](entity/ai-investment-performance-singularity.md) |
| **`AI_Infrastructure_Capex_Cycle`** | AI 인프라 광범위 투자 | **GPU(엔비디아)·메모리·데이터센터·전력 기기** 등 **동반 케이펙스** 서술 *(05:14)*. | [ai-infrastructure-capex-cycle.md](entity/ai-infrastructure-capex-cycle.md) |
| **`US_Marine_Shipbuilding_Capacity_Constraint`** | 미국 선박 건조·수리 부족 | 에너지 **수출** 대비 **선박 인프라** 부족 *(01:11)*. | [us-marine-shipbuilding-capacity-constraint.md](entity/us-marine-shipbuilding-capacity-constraint.md) |
| **`Geopolitics_China_Shipyard_Exclusion`** | 미·중 갈등·조선 안보 | **중국 해군력** 대응과 **중국 조선소 배제** 논리 *(01:46)*. | [geopolitics-china-shipyard-exclusion.md](entity/geopolitics-china-shipyard-exclusion.md) |
| **`IMO_Environmental_Ship_Replacement_Demand`** | IMO 친환경 선박 교체 수요 | **노후선→친환경선** 교체 **수요 급증** *(01:32)*. | [imo-environmental-ship-replacement-demand.md](entity/imo-environmental-ship-replacement-demand.md) |
| **`Korea_Shipbuilding_Structural_Resurgence`** | 한국 조선업 재도약 | **미국이 신뢰할 파트너**로 **한국 조선** 선택 구조 *(01:53)*. | [korea-shipbuilding-structural-resurgence.md](entity/korea-shipbuilding-structural-resurgence.md) |
| **`Korea_Demographics_Pension_Gap`** | 저출산·고령화 연금 갭 | **국민연금만으로 노후 불가** 서술 *(03:33)*. | [korea-demographics-pension-gap.md](entity/korea-demographics-pension-gap.md) |
| **`Korea_Private_Pension_Market_Growth`** | 퇴직·사적 연금 시장 | **사적 연금** 시장 확대 *(03:33)*. | [korea-private-pension-market-growth.md](entity/korea-private-pension-market-growth.md) |
| **`US_401k_Equity_Shift_Precedent`** | 미국 401k 주식비중 상향(선행) | **1980년대** 미국 **퇴직연금 주식 비중** 상향·**증시 장기 호황** 모델 *(03:50)*. | [us-401k-equity-shift-precedent.md](entity/us-401k-equity-shift-precedent.md) |
| **`Korea_Securities_Capital_Markets_Ascendance`** | 증권·자본시장 위상 상승 | **은행 중심→증권/자본시장** 재편 전망 *(03:02)*. | [korea-securities-capital-markets-ascendance.md](entity/korea-securities-capital-markets-ascendance.md) |
| **`Capital_Flow_RealEstate_To_Equities_Korea`** | 부동산→주식 자금 이동 | **비생산적 부동산→생산적 자본시장** 이동 *(03:02)*. | [capital-flow-real-estate-to-equities-korea.md](entity/capital-flow-real-estate-to-equities-korea.md) |
| **`Private_Credit_Collateral_Stress`** | 사모 대출 담보·적정성 이슈 | **비상장 SW** 등 **담보 적정성** 문제 제기 *(06:21)*. | [private-credit-collateral-stress.md](entity/private-credit-collateral-stress.md) |
| **`US_Treasury_10Y_Yield_Stress_Threshold`** | 미 10년 국채 금리(4.5%+) | **4.5% 이상** 시 **리스크 발현** 가능성 *(07:03)*. | [us-treasury-10y-yield-stress-threshold.md](entity/us-treasury-10y-yield-stress-threshold.md) |

---

<a id="causality-map"></a>

## 2. Causality map

| 경로 | 인과 기제 | 태그 |
|------|------------|------|
| **AI** | **특이점형 수익** + **광범위 인프라** → **실체 강세** | `RCA`+`Impact` |
| **조선** | **미 해운 인프라 부족** + **IMO** + **지정학** → **한국 조선** | `RCA`+`Evidence` |
| **금융** | **연금 갭** + **사적연금** + **401k 선행** + **자금 이동** → **증권/자본시장** | `Impact` |
| **사모대출** | **담보·금리** → **단기 변동성** | `Evidence` |
| **사모대출** | **레버리지 낮음** → **서브프라임급 전이 낮음** | `RCA` |
| **사모대출** | **부실 정리** → **은행 중심 재편** | `Impact` |

### 2.1 Edge 표

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `AI_Investment_Performance_Singularity` | `supports` | `Productive_AI_Capex_Bull_Case` | `scaling_law_narrative` |
| `AI_Infrastructure_Capex_Cycle` | `feeds` | `Productive_AI_Capex_Bull_Case` | `supply_chain_depth` |
| `US_Marine_Shipbuilding_Capacity_Constraint` | `combines_with` | `Korea_Shipbuilding_Structural_Resurgence` | `trusted_partner` |
| `IMO_Environmental_Ship_Replacement_Demand` | `combines_with` | `Korea_Shipbuilding_Structural_Resurgence` | `replacement_cycle` |
| `Geopolitics_China_Shipyard_Exclusion` | `combines_with` | `Korea_Shipbuilding_Structural_Resurgence` | `security_supply_chain` |
| `Korea_Demographics_Pension_Gap` | `drives` | `Korea_Private_Pension_Market_Growth` | `retirement_funding_gap` |
| `US_401k_Equity_Shift_Precedent` | `templates` | `Korea_Securities_Capital_Markets_Ascendance` | `policy_market_parallel` |
| `Capital_Flow_RealEstate_To_Equities_Korea` | `reweights` | `Korea_Securities_Capital_Markets_Ascendance` | `capital_allocation_shift` |
| `Private_Credit_Collateral_Stress` | `amplified_by` | `US_Treasury_10Y_Yield_Stress_Threshold` | `rate_stress` |

> 노트: `Productive_AI_Capex_Bull_Case`는 **관계 문서 내부 요약 노드**(장기 우상향: 반도체·전기전자·전력/에너지).

---

<a id="root-cause"></a>

## 3. RCA — “긍정 전망의 근원은?”

- **AI:** **천문학적 비용**이 **소비**가 아니라 **성능·효율**에 **비선형**으로 붙는 **특이점** 인식 *(04:44)* + **GPU·메모리·DC·전력**까지 **케이펙스 폭** *(05:14)*.
- **조선:** **미국 해운/조선 용량 부족** *(01:11)* + **IMO 규제** *(01:32)* + **미·중·안보**로 **중국 조선 배제** *(01:46)*.
- **금융:** **저출산·고령화**로 **국민연금 한계** *(03:33)* → **사적 연금** + **미국 401k 사례** *(03:50)* → **부동산→주식** *(03:02)*.

---

<a id="impact"></a>

## 4. Impact — “시장·산업에 미치는 영향”

- **AI:** **닷컴 버블과 다른 실체 강세** → **반도체·메모리 효율화 관련 전기전자·전력/에너지** **장기 우상향** *(02:23)*.
- **조선:** **한국 조선** **재도약** *(01:53)*.
- **금융:** **증권/자본시장** 위상 상승·**산업 구조 재편** *(03:02)*.
- **사모대출:** **단기 충격** 가능하나 **금융위기 전이 가능성 낮음** *(08:00)* → **은행 중심 대출 시장 재편** 계기 *(08:33)*.
- **운용 주의:** **경기 개선 신호**가 나올 때 **금리 급등**에 따른 **변동성** 경계 *(10:42)*.

---

<a id="evidence-data"></a>

## 5. Evidence 표

| 관측 | 내용 | 타임코드 |
|------|------|-----------|
| 미 해운 | **에너지 수출** 대비 **선박 건조·수리 능력 부족** | *(01:11)* |
| IMO | **친환경선 교체** 수요 **폭증** | *(01:32)* |
| 안보 | **중국 해군**·**미·중**으로 **중국 조선 불가** | *(01:46)* |
| AI 특이점 | 투입↑ **성능·효율** **기하급수** | *(04:44)* |
| AI 인프라 | **GPU·메모리·DC·전력** | *(05:14)* |
| 연금 | **국민연금만으로 노후 불가** | *(03:33)* |
| 선행 | **1980s 미국 401k** | *(03:50)* |
| 사모대출 | **비상장 SW** 등 **담보 적정성** | *(06:21)* |
| 금리 | **美 10년 4.5%+** 리스크 | *(07:03)* |
| 전이 | **서브프라임 대비 레버리지 낮음** | *(08:00)* |

---

<a id="logic-framework"></a>

## 6. 논리 프레임워크 (Mermaid)

```mermaid
flowchart TB
  subgraph AI["AI"]
    S[특이점형 스케일링] --> I[광범위 인프라 CAPEX]
    I --> L[반도체·전력 장기 우상향 서술]
  end
  subgraph SH["조선"]
    U[미 해운 용량 부족] --> K[한국 조선 파트너]
    M[IMO 교체] --> K
    G[지정학·중국 배제] --> K
  end
  subgraph FI["금융"]
    D[인구·연금 갭] --> P[사적 연금]
    Q[401k 선행 사례] --> C[증권·자본시장 위상]
    R[부동산→주식] --> C
  end
  subgraph PC["사모대출"]
    X[담보 이슈] --> V[단기 변동성]
    Y[10Y 4.5%+] --> V
    V -.-> Z[은행 중심 재편 계기]
  end
```

---

<a id="related-graph"></a>

## 7. 관련 인과 문서 (`wiki/rel/`)

- [AI 특이점·인프라 → 실체 강세·장기 섹터](rel/ai-singularity-infra-to-productive-long-cycle-sectors.md)
- [미 해운·IMO·지정학 → 한국 조선 재도약](rel/us-maritime-imo-geopolitics-to-korea-shipbuilding-resurgence.md)
- [인구·연금·401k·자금이동 → 증권·자본시장 재편](rel/korea-demographics-pension-flows-to-securities-industry-shift.md)
- [사모대출·금리 → 단기 충격·낮은 체계적 전이](rel/private-credit-yields-to-near-term-volatility-low-crisis-transmission.md)
- [사모대출 조정 → 은행 중심 대출 재편](rel/private-credit-workout-to-bank-centric-loan-market.md)

---

<a id="related-docs"></a>

## 8. 관련 문서

- [한국 주식시장](entity/korea-equity-market.md) · [머니무브](entity/money-move-deposits-to-equities.md) — **자금 이동** 주제와 맥락 연결 가능(다른 화자·근거와 구분).
- [김장열 본부장 · 반도체](kim-jangyeol-semiconductor-inference-dram-upcycle-causality.md) — **AI·반도체** 축은 **별도 근거**로 병행.
- [이선엽 · AI·방산·전쟁·수급 (별도 요약)](lee-sunyeop-2026-korea-equity-ai-defense-war-flow-causality.md) — 동일 화자의 **다른 영상 요약** 축.

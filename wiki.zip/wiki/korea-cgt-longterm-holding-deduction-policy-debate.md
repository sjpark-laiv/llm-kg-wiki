---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
content_as_of: 2026-04-18
---

# 양도세 장기보유특별공제(장특) 폐지 논쟁 — 이재명 대통령 SNS·국민의힘 주장 대비 (정책 메모)

**목적:** **장기보유특별공제(장특)** **폐지**를 둘러싼 **여야·대통령 발화**를 **주장 구조·정책 옵션·기대효과(서술)** 관점에서 **RCA·Impact** 추론용으로 정리함. 본문은 **언론·SNS 인용 메모**의 **재구성**이며, **법령·세제의 최종 확정 해석**이 아님.

**병행:** 주택 시장 **관망·세제 불확실성**은 [한국 주택·양극화·관망 (채상욱)](chae-sangwook-housing-polarization-causality.md), **정책·시장 하방** 프레임은 [한국 주택·정책 하방 (이현철)](korea-housing-policy-bear-causality-lee-video.md)과 **연결**해 읽는다.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Lee_JaeMyung_President`** | 이재명 대통령 | 본 메모에서 **정부측 논리**를 전개한 발화 주체 Person. |
| **`Jung_JeonSik_PPP_Policy_Chair`** | 정점식 (국민의힘 정책위의장) | **원내대책회의** 등에서 **장특 폐지**를 **“실거주 1주택 세금 폭탄”**으로 **프레이밍**했다는 **야당 주장** 인용 축 Person. |
| **`People_Power_Party_Claim_TaxBomb_1Home`** | 국민의힘 주장(세금 폭탄) | **1주택자 장특 폐지**가 **실거주 국민에게 세금 폭탄**이라는 **야당 측 서술**(메모). |
| **`President_Rebuttal_FalseAgitation`** | 대통령 반박(거짓 선동) | 야당 주장을 **“논리모순이자 명백한 거짓 선동”** 등으로 **반박**한 **정부측 레토릭**. |
| **`CGT_LongTerm_Holding_Special_Deduction`** | 양도세 장기보유특별공제(장특) | **거주 여부와 무관**하게 **장기 보유**만으로 **양도세를 대폭 경감**하는 제도라는 **대통령 측 정의** 서술. |
| **`Policy_Distinction_NotResidenceBased`** | 장특 ≠ 거주 연계 | 장특은 **거주와 분리**되며, **장기 거주에 따른 경감**은 **별도 제도**가 있다는 **대통령 측 설명**. |
| **`Policy_Phased_Abolition_LTHSD_Example`** | 점진적 폐지(안 예시) | **6개월 시행유예 → 다음 6개월 절반 폐지 → 1년 후 전부 폐지** 식 **단계 폐지** 예시. |
| **`Policy_Statutory_Lock_NonRevival_LTHSD`** | 법률로 부활 방지 | **시행령이 아닌 법 개정**으로 **장특 부활 불가**를 **명시**해 **정권 교체**에도 **임의 복원 어렵게** 하겠다는 **의지** 서술. |
| **`Legitimate_OneHome_RealUse_CarveOut`** | 정당한 실거주 등 예외 | **실거주 1주택**, **직장 등으로 일시 비거주한 실주거용 1주택** 등은 **투자·투기용 강화**에서 **제외**한다는 **대통령 측 서술**. |
| **`Speculative_RE_Holding_Cost_Normalization`** | 투기용 보유 부담 정상화 | **선진국 수준**으로 **보유 부담**을 높이면 **버틸수록 손실** 구조 → **가격 정상화** 기대 서술. |
| **`Concern_Listing_LockIn_Market`** | 매물 잠김 우려 | 장특 폐지가 **매도·매물**을 **억누를** 수 있다는 **시장 측 지적** 축. |
| **`Strategic_Wait_For_Policy_Reversal`** | 정책 역전 기대 | 정권 교체 시 **장특 부활** 가능성을 **전제로 한** **보유·관망** 심리(분석용). |
| **`Outcome_Aspirational_Price_Normalization`** | 가격 정상화(기대 서술) | 보유비용 정상화 → **과도한 집값** **정상화**라는 **대통령 측 기대 경로**. |

---

<a id="causality-map"></a>

## 2. Causality Map

| 경로 | 기제 | 세부 | 태그 |
|------|------|------|------|
| **논쟁** | 야당 프레임 | **1주택 실거주 = 장특 폐지 피해** | `RCA` |
| **반박** | 정부 프레임 | 장특은 **거주 무관·장기만** 경감 → **실거주 보호**와 **동일시 불가** | `RCA` |
| **정책** | 점진 폐지 | **매물 잠김** 우려에 **유예·단계** | `Impact` |
| **정책** | 법률 잠금 | **부활 불가** **명문화** | `Impact` |
| **세제** | 투기 부담 | **실거주 외** **보유비용** 상향 | `Impact` |
| **시장** | 가격 서사 | 보유비용 정상화 → **가격 정상화** (서술적 기대) | `Impact` |

### 2.1 Edge 표 (`source | edge | target | mechanism_id`)

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|----------|----------------|
| `People_Power_Party_Claim_TaxBomb_1Home` | `countered_by` | `President_Rebuttal_FalseAgitation` | `political_rebuttal` |
| `CGT_LongTerm_Holding_Special_Deduction` | `defined_as` | `Policy_Distinction_NotResidenceBased` | `legal_characterization` |
| `Policy_Distinction_NotResidenceBased` | `undermines_framing` | `People_Power_Party_Claim_TaxBomb_1Home` | `frame_clash` |
| `Policy_Phased_Abolition_LTHSD_Example` | `mitigates` | `Concern_Listing_LockIn_Market` | `transition_window` |
| `Policy_Statutory_Lock_NonRevival_LTHSD` | `reduces` | `Strategic_Wait_For_Policy_Reversal` | `credibility_commitment` |
| `Legitimate_OneHome_RealUse_CarveOut` | `narrows` | `Speculative_RE_Holding_Cost_Normalization` | `targeting` |
| `Speculative_RE_Holding_Cost_Normalization` | `intended_to_support` | `Outcome_Aspirational_Price_Normalization` | `holding_tax_story` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis (`RCA`) — “대통령 측이 야당 주장을 어떻게 깨는가?”

- **제도 정의:** 장특은 **거주와 무관**하게 **보유 기간**만으로 **양도세를 크게 깎는** 제도이고, **장기 거주 경감**은 **별도**라는 **구분** — 이를 통해 **“실거주 1주택 세금 폭탄”** 프레임을 **논리적으로 배제**한다는 서술.
- **규범 논지:** **거주하지 않을** **투자 목적** 주택 **처분 이득**에 **장기 보유만으로** **대폭 경감**할 **당위**가 없다는 **도덕·재분배** 프레이밍.
- **비교 논지:** **근로소득** 고액 구간 **세부담**과 **대비**해 **세제 우선순위** 문제를 **제기**(연 **10억 초과** 시 **세금 비중** 언급 — **수치는 발화 메모**).

---

<a id="impact"></a>

## 4. Impact Analysis (`Impact`) — “정책으로 무엇을 하겠다는가?”

- **전환 설계:** **점진·단계 폐지**(예: **6개월 유예 → 6개월 절반 → 1년 후 전폐**)로 **매물 잠김** 우려에 **대응**한다는 서술.
- **제도 고정:** **법률**에 **부활 불가**를 **명시**해 **정권 교체** 후 **임의 복원**을 어렵게 하겠다는 **커밋** 서술.
- **과세 대상:** **실거주·일시 비거주 실주거** 등 **정당 보유**는 **제외**, **투자·투기**용 **보유 부담**을 **선진국 수준**으로 **강화**한다는 서술.
- **시장 서술:** 보유 부담이 **정상화**되면 **과도한 집값**이 **정상화**될 수밖에 없다는 **기대 경로**(서술).

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크

```text
IF CGT_LongTerm_Holding_Special_Deduction is Policy_Distinction_NotResidenceBased
THEN framing People_Power_Party_Claim_TaxBomb_1Home as pure "실거주 보호" issue is contested END
IF Policy_Phased_Abolition_LTHSD_Example THEN mitigate Concern_Listing_LockIn_Market END
IF Policy_Statutory_Lock_NonRevival_LTHSD THEN reduce Strategic_Wait_For_Policy_Reversal END
IF Legitimate_OneHome_RealUse_CarveOut THEN Speculative_RE_Holding_Cost_Normalization targets non_primary_use END
```

```mermaid
flowchart TB
  PPP[People_Power_Party_Claim_TaxBomb_1Home] --> DEB[Political_debate]
  DEF[Policy_Distinction_NotResidenceBased] --> REB[President_Rebuttal_FalseAgitation]
  REB --> DEB
  PH[Policy_Phased_Abolition_LTHSD_Example] --> MKT[Listing_transition]
  LAW[Policy_Statutory_Lock_NonRevival_LTHSD] --> CRED[Credibility_commitment]
  SPEC[Speculative_RE_Holding_Cost_Normalization] --> PRICE[Outcome_Aspirational_Price_Normalization]
```

---

<a id="evidence-data"></a>

## 6. Evidence — 출처·일자(메모)

| 항목 | 내용 |
|------|------|
| **매체** | 대통령 **X(옛 트위터)** 게시, **언론 보도** 인용(메모). |
| **일자** | **18일** 발화·게시(메모); `content_as_of`는 **2026-04-18**로 **저장소 메모 일관** 처리. |
| **인용 상대** | **정점식** 정책위의장 **전날** 원내대책회의 발언 소개. |

---

<a id="summary"></a>

## 7. 결론(메타)

메모는 **① 장특의 법적 성격(거주 무관)**을 앞세운 **프레임 전쟁**, **② 점진 폐지·법적 잠금**으로 **전환 비용·기대**를 관리하려는 **정책 설계**, **③ 실거주 예외 + 투기 부담**으로 **과세 대상을 좁히는** **서술**을 한 덩어로 묶는다. 시장·세법 **실무**는 **입법안·조문**이 나와야 **정합** 검증이 가능하다.

---

## Named entity 링크 (문서 간)

| 개체 | 유형 | 연결 |
|------|------|------|
| 이재명 | Person | 이 문서 |
| 정점식 | Person | 이 문서 |
| 장특공제 | Policy / tax | 이 문서 |
| 부동산 관망·세제 | Cross-ref | [chae-sangwook-housing-polarization-causality.md](chae-sangwook-housing-polarization-causality.md) |

---

## 관련 문서

- [한국 주택·양극화·관망 (채상욱 영상)](chae-sangwook-housing-polarization-causality.md): **보유세·세제 불확실·관망** 시장 서사.
- [한국 주택·정책 하방 (이현철 영상)](korea-housing-policy-bear-causality-lee-video.md): **정책 레버**와 시장 **하방** 논의.
- [유가·에너지·물가 전망 (메모)](macro-energy-inflation-outlook.md): 거시·자산 **허브**.

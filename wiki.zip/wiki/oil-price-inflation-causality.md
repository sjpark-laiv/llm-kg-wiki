---
wiki_created: 2026-04-18
wiki_updated: 2026-04-18
---

# 유가(Oil_Price) ↔ 물가(Price_Level) 인과 구조 (RCA·영향 분석용)

**목적:** 에이전트·분석 도구가 **root cause analysis(근원 분석)**와 **impact analysis(영향 분석)**를 할 때, 두 엔티티 **`Oil_Price`(유가)**와 **`Price_Level`(물가)** 사이의 **전달 기제(transmission mechanism)**를 근거 데이터로 참조할 수 있도록 구조화한 위키입니다.

한국·미국 등 **국면별 수치**는 [거시 전망 메모](macro-energy-inflation-outlook.md)와 병행하세요.

---

<a id="entities"></a>

## 1. Entity 정의

| Entity ID | 한글·설명 | 정의(분석용) |
|-----------|-----------|---------------|
| **`Oil_Price`** | 유가 | 원유(Crude Oil) **거래 가격**. 생산·운송·제조의 핵심 **기초 에너지** 가격 축. |
| **`Price_Level`** | 물가 | 재화·서비스의 **종합 가격 수준**. 지표 예: **CPI**, **PPI**, **근원 CPI(Core CPI)** 등. |

**추론 규칙(태그):** 본 문서의 절·표는 `RCA`(왜 오르는가), `Impact`(무엇이 변하는가), `Evidence`(검증 가능한 데이터 포인트) 레이블을 병기합니다.

---

<a id="causality-map"></a>

## 2. Causality Map — `Oil_Price` ↑ → `Price_Level` ↑

유가 상승이 물가(인플레이션)로 이어지는 경로는 전달 기제를 **세 갈래**로 나누어 기술합니다.

| 경로 구분 | 인과 기제 (Causal Mechanism) | 주요 변수 (Parameters) | 분석 태그 |
|-----------|------------------------------|-------------------------|-----------|
| **직접(Direct)** | 석유류·에너지 품목 가격의 **즉시** 반영 | 휘발유, 경유, 등유, 난방유, 전기·가스 요금(연동 구간) | `Impact` · 에너지 CPI |
| **간접(Indirect)** | 생산 **원가** 상승 → 판매가 **전가** | 물류비, 플라스틱 등 석유화학 **원자재**, 공장 **유틸리티** | `RCA`+`Impact` · PPI→소비자가 |
| **2차(Second-round)** | **기대 인플레**·임금·서비스 요금 상호작용 | 인플레 기대, 임금 인상, 서비스 요금 선제 인상 | `Impact` · 임금-물가 상호작용 |

### 2.1 그래프 엣지 (추론용 요약 표)

아래는 위키 그래프·룰 엔진에 넣기 쉬운 **방향 그래프** 표현입니다. `→`는 “상승 압력·전가” 의미의 **인과 방향**입니다.

| `source` | `edge` | `target` | `mechanism_id` |
|----------|--------|------------|----------------|
| `Oil_Price` | `affects` | `Energy_CPI_Component` | `direct` |
| `Oil_Price` | `increases` | `Production_Cost` | `indirect` |
| `Production_Cost` | `transmits_to` | `PPI` | `indirect` |
| `PPI` | `feeds` | `Core_CPI` / `CPI` | `indirect` |
| `Oil_Price` | `increases` | `Logistics_Cost` | `indirect` |
| `Logistics_Cost` | `affects` | `Food_Retail_Price` | `indirect` |
| `Oil_Price` | `triggers` | `Inflation_Expectation` | `second_round` |
| `Inflation_Expectation` | `amplifies` | `Price_Level` | `second_round` |

---

<a id="root-cause"></a>

## 3. Root Cause Analysis — “왜 유가가 물가를 자극하는가?” (`RCA`)

근원은 **단일 품목 비싸짐**이 아니라 **공급망·가격결정 규칙·원료 다용도**의 결합으로 정리합니다.

- **에너지 의존성 (Energy dependency):** 현대 산업·유통은 **이동**을 전제로 하며, 이동에는 **연료**가 필수 → 유가가 **공급망 전체**의 공통 비용 축.
- **원가 가산 가격결정 (Cost-plus / markup):** 기업은 이윤·마진 유지를 위해 상승한 에너지·물류 비용을 **최종 소비자 가격**에 **전가(transmit)**.
- **범용 원자재성 (Petrochemical ubiquity):** 석유는 연료 외에 **플라스틱·섬유·비료** 등의 원료 → 다수 공산품의 **뿌리 비용(root cost)**.
- **(보강)** 거시 맥락에서의 **수입 물가**·**환율** 채널은 [3고·수입 물가 논의](macro-energy-inflation-outlook.md#three-highs)와 연결해 분석합니다.

---

<a id="impact"></a>

## 4. Impact Analysis — “무엇이 변하는가?” (`Impact`)

유가 상승 **시나리오** 가정 시, 영향 분석 체크리스트입니다.

### A. 공급 측면 (Supply-side)

- **물류비:** 육상·해상·항공 운임 상승 → **신선식품·공산품** 납품가·소매가 상승.
- **제조 원가:** 공장 **에너지(유틸리티)** 비용 상승 → **영업이익률** 압박 또는 **판매가 인상**.
- **농업·원자재:** 비료 등 **석유 유도체** 가격 → **곡물·식료품** 물가 상승.

### B. 수요·심리 측면 (Demand-side)

- **실질 소득:** 가처분소득 중 **에너지 지출 비중** 증가 → 타 재화 소비 위축 (**스태그플레이션** 위험과 연계해 논의).
- **기대 인플레이션:** “유가가 오르면 다른 것도 오른다”는 **선제적 가격 인상**·협상 행동 → **서비스 요금·임금** 압력.

---

<a id="logic-framework"></a>

## 5. 논리 프레임워크 (에이전트용)

텍스트 규칙(의사코드):

```text
IF Oil_Price increases THEN
  Direct:   Energy_components_of_CPI tend_up
  Indirect: Production_Cost increases
            -> PPI tends_up -> pass_through -> CPI / Core_CPI tend_up
            Logistics_Cost increases -> Service_prices / retail_prices tend_up
  Second:   Inflation_expectation increases -> preemptive_price_wages -> Price_Level amplifies
END
```

**Mermaid (선택 시각화):**

```mermaid
flowchart TB
  O[Oil_Price]
  O --> E[Energy CPI components]
  O --> PC[Production cost]
  PC --> PPI[PPI]
  PPI --> C[CPI / Core CPI]
  O --> L[Logistics cost]
  L --> S[Service / retail prices]
  O --> X[Inflation expectations]
  X --> PL[Price_Level]
  C --> PL
  S --> PL
  E --> PL
```

---

<a id="evidence-data"></a>

## 6. Evidence 데이터 포인트 (`Evidence`)

추론·검증 시 참고할 수 있는 **관측·지표** 예시입니다 (국가·시기별로 계수는 다름).

| 데이터 포인트 | 설명 | 분석 용도 |
|----------------|------|-----------|
| **산업별 에너지 집약도** | 매출 대비 에너지 비용 비중 | `Impact` — 어느 섹터가 유가 충격에 민감한가 |
| **전기료–유가 시차 상관** | 연료비 연동·조정 **시차**(통상 **3~6개월** 언급이 많음) | `Evidence` — 전가 속도 |
| **유가 결제 통화(달러)** | 유가 **상승**과 본국 **환율(대 달러) 악화**가 겹치면 수입 에너지·원자재 비용이 **비선형**으로 증가 | `RCA`+`Impact` — [고환율·고유가](macro-energy-inflation-outlook.md#three-highs) 복합 |

---

<a id="summary"></a>

## 7. 결론(메타 인과 문장)

유가는 경제에 **‘보편 세금’**에 가깝게 작용한다는 비유가 흔합니다. **생산 비용 상승(Push)** → **물류·원가 전가(Transmit)** → **물가 상승 기대 자극(Trigger)** 순으로 **`Price_Level`** 전체를 밀어 올리는 **연쇄**로 모델링합니다.

---

## Named entity 링크 (문서 간)

| 개체(Entity) | 유형 | 연결 |
|--------------|------|------|
| Oil_Price, 유가 | Price / Macro | 이 문서 [§1–2](#entities), [거시 메모 §1–2](macro-energy-inflation-outlook.md#oil-energy-outlook) |
| Price_Level, 물가, CPI, PPI | Index / Macro | 이 문서 [§2–6](#causality-map), [거시 메모 §2](macro-energy-inflation-outlook.md#three-highs) |
| Inflation_Expectation | Concept | [§2](#causality-map), [§4.B](#impact) |
| Logistics_Cost, Production_Cost | Cost driver | [§3–4](#root-cause) |

---

## 관련 문서

- [유가·에너지·물가 전망과 투자 시사점](macro-energy-inflation-outlook.md): 한국은행·3고·수입 물가 등 **국면 메모**.
- [한국 스태그플레이션 리스크 (영상 근거)](korea-stagflation-risk-causality.md): `Oil_Price`·미 연준·관세가 **한국 CPI·성장**으로 수렴하는 **국면별 확장** 인과.
- [국내 증시·선행지수·섹터 로테이션 (영상)](korea-kospi-leading-indicator-causality.md): **원가·금리·성장**이 기업 이익·코스피로 전달되는 논의와 **병행**할 때 참고.
- [글로벌 거시·부동산 ‘일시 조정 후 반등’ (홍춘욱 영상)](hong-chunwook-macro-rebound-causality-video.md): **유가·환율→CPI→한은** 경로의 **다른 결론(일시 위축 후 반등)** 서사.
- [한국 증시·미국 제조 ODM·AI (채상욱 영상)](chae-sangwook-korea-us-odm-ai-kospi-causality.md): **유가(전쟁) 선반영·금리 바닥**을 전제로 한 **증시 낙관** 서사 — `Oil_Price` 해석의 **대위 가설**.
